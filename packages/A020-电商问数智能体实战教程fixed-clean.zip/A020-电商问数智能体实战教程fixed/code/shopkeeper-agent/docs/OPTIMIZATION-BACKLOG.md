# 性能优化 Backlog（已记录，**暂不实施**）

> **状态：已记录，等"先把项目读懂"再动手。** 2026-10-20 实测定位，本轮**没有改动任何应用代码**。
> **开工条件**：走完 §5 的项目理解路线后，从 P0 开始，每项按 §4 的方法做前后对比。
> 关联：`docker/fixed-backend-report.md`（部署侧方法论）、`docker/README.md`（部署说明）、
> `docker/bootstrap.sh`（从零重跑）、`ux-examples-catalog.md`（10 题实测基线）。

---

## 1. 实测基线（2026-10-20，真实 Docker 栈，单次问数，14.4s）

问题：`统计 2025 年第一季度各大区的 GMV，并按 GMV 从高到低排序`

| 步骤 | 耗时 | 占比 | 性质 | 用到 LLM？ |
|---|---|---|---|---|
| **召回字段取值** | **7.0s** | 49% | **N+1 串行 ES 检索** | 是（关键词扩展） |
| 过滤表信息 | 2.7s | 19% | LLM 往返 | 是 |
| 生成SQL | 2.5s | 17% | LLM 往返 | 是 |
| 过滤指标信息 | 1.4s | 10% | LLM 往返 | 是 |
| 召回指标信息 | 0.5s | 3% | Qdrant 向量检索 | 是（关键词扩展） |
| 召回字段信息 | 0.3s | 2% | Qdrant 向量检索 | 是（关键词扩展） |
| 合并 / 附加上下文 / 校验 / 执行 | ≈0.0s | <1% | 本地计算 + MySQL | 否（校验用 EXPLAIN） |

**单次问数的外部调用计数**：`ES 检索 14–21 次`（随 LLM 给出的关键词个数波动）· `向量化 17–19 条` · `LLM 约 7 次` · `MySQL 1 次`

**同一个问题连跑两次的结果**（用 `docs/hotpath_probe.py --repeat 2` 实测）：

| | 端到端 | 召回字段信息 | 召回字段取值 | 过滤表信息 | 生成SQL | ES 检索 | 结果 |
|---|---|---|---|---|---|---|---|
| 第 1 次 | **11.25s** | 1.82s | 4.52s | 1.08s | 2.09s | 14 次 | 5 行，一致 |
| 第 2 次 | **24.14s** | 6.27s | 7.64s | 6.00s | 2.05s | 21 次 | 5 行，一致 |

**同一问题、同样结果，耗时差 2 倍**——而且慢的那次"召回字段信息"和"过滤表信息"都慢了 4–5 倍。
这说明：**LLM 往返的耗时是主要方差来源**，优化前后的对比必须看多次中位数，不能看单次。

三个召回节点是**并行**的（时间线上同时 0.0s 启动），**慢点在节点内部的串行循环**。

---

## 2. 优化项（按性价比排序）

### P0-1 · ES 检索批量化 —— `recall_value` 的 16 次串行检索

- **现状**：`app/agent/nodes/recall_value.py:53` 对每个关键词各发一次 ES `match` 查询，串行 await。
- **改法**：改用 ES 原生 `_msearch`（一次请求带多个 query），或至少 `asyncio.gather` 并发。
  ES 路由统计里 `/{index}/_msearch` 已有 4097 次记录，这条路可用。
- **涉及**：`app/agent/nodes/recall_value.py`、`app/repositories/es/value_es_repository.py`
- **预计收益**：召回字段取值 7.0s → 约 2–3s（**端到端省 4–5s**）
- **风险**：低。批量后需保持 `min_score=0.6` 过滤与 `ValueInfo.id` 去重语义不变（现有去重逻辑在节点里，天然兼容）
- **验收**：ES `/{index}/_search` 计数从 16 → 1；节点耗时下降；10 题基线 p50 不退化

### P0-2 · 关键词停用词过滤 —— 16 次里有 8 次是白跑的

- **现状**：`extract_keywords` 用 jieba 抽出的关键词里含"统计""排序"这类无检索意义的词，
  照样被送去 ES 逐个检索。
- **改法**：在 `recall_*` 三个节点进循环前过滤停用词/词长过短的词。
- **涉及**：`app/agent/nodes/recall_column.py:53`、`recall_metric.py:53`、`recall_value.py:53`
- **预计收益**：检索次数可能 16 → 8，端到端再省 1–3s
- **风险**：低。需注意"销量""金额"这类词不能误杀——过滤表应以实测召回率为准
- **验收**：同题召回命中率不下降（对比改造前后 `retrieved_*_infos` 集合）

### P1-1 · 向量化批量化 —— 19 条向量 19 次往返

- **现状**：`recall_*` 里 `embedding_client.aembed_query(keyword)` 逐个调用。
  注意 `app/services/meta_knowledge_service.py:140` 建索引时**已经**是批量（`aembed_documents`，batch=20），
  查询时反而没用上。
- **改法**：改用 `aembed_documents` 批量。
- **涉及**：`app/agent/nodes/recall_column.py` / `recall_metric.py` / `recall_value.py`
- **预计收益**：0.5–1s（TEI 侧 `te_request_count{method="batch"}` 会明显上升，`single` 归零）
- **风险**：低。但 `aembed_documents` 语义上是"文档"，用"查询"批需确认服务端行为一致

### P1-2 · 合并两个过滤节点的一次 LLM 往返

- **现状**：`filter_metric`（1.4s）+ `filter_table`（2.7s）是两次独立 LLM 调用。
- **改法**：合并成一次调用同时输出"相关指标"和"相关表"两份 JSON。
- **涉及**：`app/agent/nodes/filter_metric.py`、`filter_table.py`、`prompts/filter_*.prompt`、`app/agent/graph.py`
- **预计收益**：端到端省 1.5–2s
- **风险**：**中**。改了图的结构与两个提示词，输出格式要重新验证；过滤效果可能变化
- **验收**：10 题基线的召回集合逐题对比，不能有字段漏召回

### P2-1 · SSE 事件补 `elapsed_ms`（可观测性，不是性能）

- **现状**：`app/services/query_service.py:66` 把节点 `writer({...})` 的内容原样序列化，
  progress 事件只有 `{type, step, status}`，**没有耗时**——前端看不到"哪一步慢"，运维只能人工比对 api 日志时间戳。
- **改法**：节点里写入耗时字段（如 `writer({"type":"progress","step":...,"status":...,"elapsed_ms":...})`），
  前端 `StepRail`/`MessageBubble` 可直接显示每步耗时。
- **涉及**：`app/agent/nodes/*.py`（加埋点）、`app/services/query_service.py`（透传）、前端 `src/types/agent.ts` + `StepRail.tsx`
- **价值**：**这是后面所有优化的"眼睛"**——建议排在 P0 之前或与 P0-1 一起做，否则改完无法定位
- **风险**：低（纯增量字段，向后兼容）

---

## 3. 明确**不是**瓶颈（别去优化）

| 组件 | 实测 | 结论 |
|---|---|---|
| Qdrant 向量检索 | 0.3–0.5s | 快。它 1024 维 / Cosine，98+8 个点，量太小，别动 |
| MySQL 执行 SQL | 0.01s | 快。115 条订单的聚合，别动 |
| `validate_sql`（EXPLAIN） | 0.0s | 快 |
| `merge_retrieved_info` / `add_extra_context` | 0.0s | 纯内存/本地 |
| 三个召回节点的**并行** | 已并行 | 已经是并行了，别重复优化 |

**真正的大头是 LLM 往返（约 7 次，占 ~45% 时间）和 N+1 的 ES 检索（49% 的单步耗时）。**
优化方向是"少调 LLM / 少发 HTTP"，不是"换更快的检索引擎"。

---

## 4. 怎么"确认"（而不是靠感觉）

### 4.1 现成的探针脚本

```bash
python3 docs/hotpath_probe.py                      # 默认问题，跑 1 次
python3 docs/hotpath_probe.py --repeat 5           # 跑 5 次，看抖动
python3 docs/hotpath_probe.py --query "按会员等级统计 2025 年第一季度的订单数和销售额"
```

输出：端到端耗时、每步耗时、ES 检索次数、向量化条数、SSE 帧数。**优化前后各跑一次，数字对比。**

### 4.2 手工计数器（不依赖脚本）

```bash
# ES：按路由的请求计数
curl -s 'http://127.0.0.1:9200/_nodes/stats/http' \
  | jq '.nodes[].http.routes|to_entries[]|select(.key|endswith("_search"))'
# TEI：向量化请求数 / 队列
curl -s http://127.0.0.1:8081/metrics | grep -E 'te_request_count|te_embed_count|te_queue_size'
# Qdrant：telemetry
curl -s http://127.0.0.1:6333/telemetry
# 容器资源与重启
docker stats --no-stream
docker inspect shopkeeper-api --format '{{.RestartCount}}'
```

### 4.3 回归基线

`ux-examples-catalog.md` 的 10 道题已有每题耗时（7.7s–47.2s），**注意 #7 的 47.2s 是异常值**
（召回降级路径，走的是"查不到 → 全 null"的分支），要单独看。
基线文件：`/tmp/ux-human-video/catalog.json`（含每题 elapsed / 步骤 / 结果行）。

**判定标准**：
- 端到端 p50 下降 ≥ 20% 且 10 题**结果行逐行不变**（不只是数量不变）
- ES 检索次数、TEI 向量化次数按预期下降
- 10 题里**没有新增**非成功态（空数组 / 全 null / error_message 行）

### 4.4 别被 LLM 抖动骗了

**同一个问题实测跑出 11.25s 和 24.14s（差 2 倍），结果却完全一致**（见 §1 的两次对照）。
所以：
- **必须 `--repeat 5` 以上看 p50/p95，不要用单次对比**
- 优化前后用**同一批问题、同一问法**对比
- 注意 ES 检索次数本身也在变（14~21），因为关键词个数由 LLM 给——**这本身就是要先修的方差源**（P0-2）

---

## 5. 先把项目读懂（推荐路线）

> 先看 **`docs/MODULE-DEPENDENCIES.md`**（依赖图 + 6 条分层契约 + 耦合热点），
> 能省掉"这个模块到底依赖谁"的翻找时间；再用
> `python3 docs/module_graph.py` 随时复查契约有没有被破坏。

动手优化之前，按这个顺序读一遍，每步回答对应问题：

| 步 | 读什么 | 要回答的问题 |
|---|---|---|
| 1 | `main.py` → `app/api/routers/query_router.py` → `app/services/query_service.py` | 请求怎么进来、context 怎么组装、SSE 怎么封装 |
| 2 | `app/agent/graph.py` | 11 个节点怎么连、哪些是并行、哪条是条件边 |
| 3 | `app/agent/state.py` | `DataAgentState` 有哪些字段，谁写谁读 |
| 4 | `app/agent/nodes/*.py`（12 个） | 每个节点干什么、用不用 LLM、读什么仓储 |
| 5 | `prompts/*.prompt`（7 个） | 每个提示词要求什么、约束在哪 |
| 6 | `app/repositories/{qdrant,es,mysql}/` | 索引怎么存的、查询怎么发的（**P0 优化就在这层**） |
| 7 | `app/clients/*_manager.py`（4 个） | 客户端怎么初始化、连接怎么管 |
| 8 | `conf/app_config.yaml` + `app/conf/app_config.py` | 配置怎么读、`${oc.env:...}` 怎么解析 |
| 9 | `conf/meta_config.yaml` + `app/scripts/build_meta_knowledge.py` + `app/services/meta_knowledge_service.py` | **元数据从哪来**（人工维护的字段/指标/别名/口径）→ 索引怎么建 |
| 10 | `docker/mysql/{meta,dw}.sql` | 表结构、种子数据、日期列设计（`date_id` 是 int） |
| 11 | `app/entities/*`、`app/models/*` | 领域模型 vs ORM 模型的分工 |
| 12 | 前端 `../shopkeeper-agent-frontend/src/`（`App.tsx` + `components/` + `lib/`） | SSE 怎么消费、步骤条/结果表怎么渲染（**静默失败在这里被放大**） |
| 13 | `docker/HANDOFF.md` / `docker/README.md` / `docker/fixed-backend-report.md` | 部署侧：怎么从零跑起来、踩过哪些坑 |

**读的时候顺手确认这三件事**（都会影响优化方案）：

1. `recall_*` 三个节点的**关键词集合**分别从哪来、是否有交集（决定能不能合并请求）
2. `filter_metric` / `filter_table` 的输出**被下游谁消费**（决定 P1-2 合并的接口形状）
3. 前端**怎么消费 progress 事件**（决定 P2-1 加 `elapsed_ms` 的改法）

---

## 6. 已知但不在本次优化范围内的问题

| 问题 | 位置 | 说明 |
|---|---|---|
| `validate_sql` 失败时也写 `status:"success"` | `app/agent/nodes/validate_sql.py:33 / 39` | 「校验SQL」永远绿勾，用户看不出发生过自我修正 |
| 失败被包成 `result.data` 的一行 `error_message` | 后端生成 SQL 的降级路径 | 前端一律按"成功"渲染 → 静默失败（详见 `ux-examples-catalog.md` §3.2） |
| `ORDER BY` 会随问法丢失 | LLM 生成环节 | 英文问法实测丢了排序 → "前 5 名"会取错 |
| 列别名随 LLM 心情 | 同上 | 同一语义给 `大区` / `地区` / `region_name` |
| 同一问题每次 SQL 文本不同 | `temperature=0` 仍如此 | 差异来自提示词约束不足，不是采样随机性 |

以上都是**正确性**问题而非性能问题，另立任务处理（修在提示词与校验层，不是靠调温度）。
