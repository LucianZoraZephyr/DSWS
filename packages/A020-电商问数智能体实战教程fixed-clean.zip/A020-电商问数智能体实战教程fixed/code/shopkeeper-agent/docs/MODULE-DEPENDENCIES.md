# 模块依赖图与依赖契约

> 目的：看清"哪些模块互相依赖"，并**机器校验**分层边界没被破坏。
> 生成方式：`python3 docs/module_graph.py --write`（纯标准库 AST 解析，零依赖）
> 产物：`docs/module-graph.svg` / `.png` / `.dot` / `.mmd`
> 当前状态：**64 个内部模块 / 173 条内部依赖 / 0 个循环 / 6 条契约全部通过**

---

## 1. 怎么画、怎么复查

```bash
cd code/shopkeeper-agent

# 看报告（含契约检查结果）
python3 docs/module_graph.py

# 重新生成图
python3 docs/module_graph.py --write
dot -Tsvg docs/module-graph.dot -o docs/module-graph.svg      # 需要 graphviz
dot -Tpng -Gdpi=72 docs/module-graph.dot -o docs/module-graph.png

# 机器可读
python3 docs/module_graph.py --json
```

**已接进 pre-commit**（`.pre-commit-config.yaml` 的 `module-contracts` 钩子）：
改了 `app/**` 就自动跑，**有循环依赖或违反分层就拦截提交**。

```bash
pre-commit install && pre-commit run module-contracts
```

> 想用社区标准工具也可以：`uvx import-linter`（能写 YAML 契约、断言式检查）、
> `uvx pydeps app --show-deps`（经典依赖图）。本项目自带的这个多做了两件事：
> **区分「仅类型注解引用」与「运行期依赖」**，以及**内置分层契约**。

---

## 1.5 「64 个内部模块」是怎么来的

**计数规则**（`module_graph.py` 的 `module_name()`）：把项目根当成包的根，
`app/agent/nodes/generate_sql.py` → `app.agent.nodes.generate_sql`；
`__init__.py` 代表它所在的**包**（`app/agent/nodes/__init__.py` → `app.agent.nodes`）。

```
64 = main.py（1） + app/**/*.py（63）
   其中 12 个是 __init__.py 组成的「包」 → 真正的功能模块 51 个 + main.py
```

| 目录 | 模块数 | 目录 | 模块数 |
|---|---|---|---|
| `app/agent/nodes/` | **13** | `app/repositories/mysql/meta/mappers/` | 4 |
| `app/agent/` | 5 | `app/api/` | 3 |
| `app/entities/` | 5 | `app/repositories/qdrant/` | 3 |
| `app/models/` | 5 | `app/api/routers/`、`app/api/schemas/` | 2 各 |
| `app/clients/` | 4 | `app/conf/`、`app/core/`、`app/prompt/` | 2 各 |
| `app/repositories/es/`、`app/repositories/mysql/dw/`、`.../mysql/meta/` | 2 各 | `app/services/` | 2 |
| `app/repositories/`、`app/repositories/mysql/`、`app/scripts/` | 1 各 | `main.py` | 1 |

**为什么"13 个节点"和"12 个包"**：`app/agent/nodes/` 下有 12 个节点文件 + 1 个 `__init__.py` = 13。

---

## 1.6 查任意一个模块：在哪、跟谁绑着

```bash
# 列出全部 64 个模块及其文件位置（按层分组）
python3 docs/module_graph.py --list

# 查单个模块：位置 / 它依赖谁 / 谁依赖它 / 契约判定
python3 docs/module_graph.py --explain generate_sql
python3 docs/module_graph.py --explain app.agent.context
```

支持模糊匹配（写后缀即可），输出示例（`app.agent.context`）：

```
模块  app.agent.context
位置  app/agent/context.py   （36 行）
层    agent
它依赖（出边 5 个）：全部是 app.repositories.* 的 type-only 引用
谁依赖它（入边 14 个）：11 个节点 + graph + query_service（节点那 11 条是 type-only）
第三方依赖：langchain_huggingface, typing
```

**从这张表能直接读出本项目的核心架构**：`app/agent/context.py` 是**依赖注入中心**——
它把 5 个仓储的**类型**声明在 `DataAgentContext` 里，11 个节点只 import 这个 context
（且都只是类型标注），运行时实例由 `query_service` 注入。所以：

- 节点与仓储之间**没有运行期依赖**（图上全是虚线）
- 换存储实现只需要改 `query_service` 组装 context 的那一处
- `app.agent.context` 的 fan-in=14 是全项目最高，说明它是"人人必经"的中心

---

```
entry    main
   ↓
api      app.api.*                     （FastAPI 路由、schema、依赖注入）
   ↓
services app.services.*                （query_service 编排图；meta_knowledge_service 建索引）
   ↓
agent    app.agent.*                    （graph + 11 个节点 + state + context + llm）
   ↓
support  app.prompt.* app.conf.* app.entities.* app.core.*
   ↓
repo     app.repositories.*             （qdrant / es / mysql）
   ↓
client   app.clients.*                  （embedding / es / mysql / qdrant 客户端）
```

| 层 | 模块数 | 说明 |
|---|---|---|
| entry | 1 | `main.py` |
| api | 7 | 路由、请求 schema、lifespan、dependencies |
| services | 2 | `query_service`（运行时编排）、`meta_knowledge_service`（建索引） |
| agent | 18 | graph / state / context / llm / 12 个节点 |
| support | 11 | 提示词加载、配置、领域实体、日志 |
| repo | 15 | Qdrant 2 个、ES 1 个、MySQL（meta/dw + mapper） |
| client | 4 | embedding / es / mysql / qdrant 客户端管理器 |
| data | 6 | ORM 模型（`app/models`）+ 建库脚本（`app/scripts`） |

**依赖只允许自上而下**，`docs/module_graph.py` 的 6 条契约就是这么定义的。

---

## 3. 依赖契约（可执行断言）

| 编号 | 规则 | 状态 |
|---|---|---|
| **C1** | agent 节点不得在**运行期**直接 import 仓储/客户端（必须走 `runtime.context` 注入） | ✔ 通过 |
| **C2** | api 层不得直接 import agent 内部（应经 services 中转） | ✔ 通过 |
| **C3** | 仓储层不得反向依赖 agent / services / api | ✔ 通过 |
| **C4** | 领域实体（`app.entities`）不得依赖 ORM / 仓储 | ✔ 通过 |
| **C5** | core 不得依赖上层模块（读 conf 配置、同包引用除外） | ✔ 通过 |
| **C6** | 同一层节点之间不得互相 import（避免横向耦合） | ✔ 通过 |
| — | **无循环依赖** | ✔ 通过 |

### 这套分层里最值钱的一条：C1

**11 个 agent 节点里，只有 1 个 import 了仓储，而且只是用于类型标注**：

```python
# app/agent/nodes/validate_sql.py:13
from app.repositories.mysql.dw.dw_mysql_repository import DWMySQLRepository
#                        ↑ 仅用于第 28 行的类型标注
# 第 28 行：dw_mysql_repository: DWMySQLRepository = runtime.context["dw_mysql_repository"]
#                                        ↑ 实例来自 context，不是 import 来的
```

所有节点的仓储实例都是通过 LangGraph 的 `runtime.context`（`app/agent/context.py` 的
`DataAgentContext`）**注入**的——所以：

- 节点**不 import 任何仓储/客户端** → 换存储实现不用改节点
- `app.agent.context` 的 fan-in = 14（被 11 个节点 + graph + services 依赖），是**依赖注入的中心**
- 依赖方向是干净的：节点 → (context) → 仓储，而不是节点 → 仓储

**唯一的小瑕疵**：`validate_sql.py` 那条 type-only import 会让"节点不碰仓储"这条约定在**源码层面**不成立
（运行期无耦合）。建议改成：

```python
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from app.repositories.mysql.dw.dw_mysql_repository import DWMySQLRepository
```

`docs/module_graph.py` 会把它作为**提示**列出（不算违规），改完提示会消失。

---

## 4. 耦合热点（改代码前先看这里）

**fan-out 最高（谁依赖得多）**

| 数 | 模块 | 说明 |
|---|---|---|
| 23 | `app.agent.graph` | 图的组装，依赖 11 个节点 + state + context + llm，**改图最先看它** |
| 12 | `app.services.meta_knowledge_service` | 建索引逻辑最重（embedding 批量 + Qdrant + ES） |
| 10 | `app.api.dependencies` | 依赖注入装配 |
| 10 | `app.repositories.mysql.meta.meta_mysql_repository` | 元数据 CRUD 最重 |
| 10 | `app.scripts.build_meta_knowledge` | 建库脚本，扇出大但只离线跑一次 |
| 8 | `app.services.query_service` | 运行时编排：组装 context + `graph.astream` + SSE 封装 |

**fan-in 最高（谁被依赖得多）**

| 数 | 模块 | 说明 |
|---|---|---|
| 14 | `app.agent.state` | 全链路共享状态（`DataAgentState`） |
| 14 | `app.agent.context` | **依赖注入中心**，11 个节点都从这里取仓储 |
| 13 | `app.core.log` | 日志（几乎每个模块都 import） |
| 8 | `app.conf.app_config` | 全局配置（`${oc.env:...}`） |
| 7 | `app.agent.llm` | LLM 实例（7 个节点共用一个） |
| 7 | `app.prompt.prompt_loader` | 提示词加载（7 个提示词） |
| 7 | `app.entities.*` | 领域实体 |

**读代码的顺序建议**（配合 `docs/OPTIMIZATION-BACKLOG.md` §5）：
`main` → `api` → `services.query_service` → `agent.graph` → `agent.context`（依赖注入中心）→
`agent.state` → 各个 node → `repositories` → `clients`。

---

## 5. 第三方依赖（27 个）

| 类别 | 包 |
|---|---|
| Web | `fastapi` `starlette` `uvicorn`(运行时) `pydantic` |
| Agent | `langchain` `langchain_core` `langchain_huggingface` `langgraph` |
| 存储 | `qdrant_client` `elasticsearch` `sqlalchemy` `pymysql`*(经 asyncmy) |
| 配置/日志 | `omegaconf` `loguru` `python-dotenv` `pyyaml` |
| NLP | `jieba`（关键词抽取） |
| 其它 | `argparse` `asyncio` `contextlib` `contextvars` `dataclasses` `datetime` `json` `pathlib` `random` `sys` `typing` `uuid` |

**值得注意**：核心链路只依赖 `langgraph` + `qdrant_client` + `elasticsearch` + `sqlalchemy` 四家，
其余都是标准库或轻量工具——**没有向量数据库/检索框架的深度绑定**，换栈成本可控。

---

## 6. 相关文档

- `docs/OPTIMIZATION-BACKLOG.md` —— 性能热点实测与优化清单（**刻意未实施**），其 §5 是项目阅读路线
- `docker/fixed-backend-report.md` —— 部署侧方法论（10 类问题怎么定位怎么修）
- `docker/README.md` —— 部署与从零重跑（`docker/bootstrap.sh`）
