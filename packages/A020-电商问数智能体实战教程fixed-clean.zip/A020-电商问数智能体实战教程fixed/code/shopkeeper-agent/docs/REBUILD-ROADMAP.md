# 从零渐进重建路线图

> **目标**：把当前系统拆成 8 个可独立验收、可随时停下的阶段。每个阶段都满足三条：
> ① 能从零跑起来；② 有可演示的产物；③ 有机器可判定的验收命令。
>
> **依据**：5 份审计（`audit-prompts.md` / `audit-frontend-contract.md` / `audit-silent-failure.md` /
> `audit-metadata-schema.md` / `audit-sql-validation.md`）+ 模块/接口计数（`module_counter.py` /
> `interface_count.py`）+ 冷启动脚本（`docker/bootstrap.sh`）+ 性能探针（`docs/hotpath_probe.py`）。

---

## 0. 一句话结论

**不要按"目录/分层"切，要按"契约"切。**

第一个阶段不是装数据库，而是把 3 个契约钉死：**SSE 事件契约、schema 契约、SQL 只读契约**。
因为审计发现的 30+ 条缺陷收敛到 3 个根因，全部是同一句话：

> **契约只写在提示词、YAML 和文档里，没有一行代码强制它。**

按层切（先数据库、再检索、再 LLM、最后前端）会把这三个根因**固化进每一层**，最后只能在提示词里打补丁——
这正是当前系统的现状。

---

## 1. 为什么不能按层切

| 切法 | 阶段顺序 | 结果 |
|---|---|---|
| **按层切**（教程常见） | 基础设施 → 元数据 → 检索 → LLM → 前端 | 每层都在"猜"上一层的契约；到前端才发现步骤对不上；到联调才发现失败没有通道；到上线才发现 SQL 能写库 |
| **按契约切**（本方案） | 契约+骨架 → schema → 构建 → 检索 → 生成 → 安全 → 失败 → 前端 → 性能 | 每层交付时契约已被测试锁死；后面的阶段只能"填实现"，不能改契约 |

当前系统的实证：12 个节点里 `correct_sql` 是条件节点，前端却硬编码 12 个节点并默认 `pending`
（`StepRail.tsx:18-31` / `:63-64`）——这就是"按层切、契约最后对"的典型代价。

---

## 2. 三条根因 → 三条设计约束

| 根因 | 证据 | 重建约束 |
|---|---|---|
| **A. 契约只在提示词/元数据里，代码零强制** | "只能查询"只写在 `generate_sql.prompt`；`validate_sql` 的 `EXPLAIN` 对 UPDATE/DELETE 一律放行；多语句第二句照常执行（实测） | **约束 1**：每个契约必须有代码级守卫（schema 校验 / 策略文件 / 测试），提示词只是"建议"，不是"保证" |
| **B. 失败没有可表达的通道** | LLM 编造 `SELECT '无法生成SQL…' AS error_message` 当数据行；用户取消被写成 `done`；`type:"error"` 事件在成功路径上结构性不可达 | **约束 2**：失败是一等公民——错误码、`error` 事件、步骤 `error` 状态、UI 红框、失败用例，五件套缺一不可 |
| **C. 元数据与数仓不同源** | AOV 三种口径 2427.47 / 448.81 / 5.41；`dim_region` 无 city 列；时间/枚举值域零声明；功能清单写"6 表 138 行"，实际 5 表 115 行 | **约束 3**：schema 单一事实源——DDL → 契约文件 → 生成 meta/提示词视图，**禁止手写第二份** |

---

## 3. 切分五原则

1. **每个阶段一个可停点**：停下来就是一个能演示的产品，不是半成品。
2. **契约先行**：阶段的第一件产物是契约文件 + 契约测试，最后一件才是实现。
3. **依赖是 DAG，不是链**：S1∥S2 可并行、S3∥S4 可并行、S5∥S6 可并行——为多 subagent 并行实现留出前沿。
4. **负向夹具**：把旧系统的错误行为录成 fixture，新系统必须"与它不同"。旧系统不是参考实现，是**反例库**。
5. **验收命令化**：每个阶段一个 `make stageN`，退出码即结论；不接受"看起来对了"。

---

## 4. 八阶段总表

| 阶段 | 交付物 | 钉死的契约 | 验收命令 | 依赖 | 成本 | 对应审计 |
|---|---|---|---|---|---|---|
| **S0 骨架** | 假 SSE + 真步骤条 | SSE 事件 schema、步骤目录（唯一源） | `make stage0` | — | S | F1–F13、D3/D4 |
| **S1 Schema** | 三方对账 + 契约表 | 表/列/类型/**粒度/口径/值域** | `make stage1` | S0 | M | C1–C8 |
| **S2 构建** | `build_meta_knowledge` 幂等管线 | 三个存储的产物版本 + `--verify` | `make stage2` | S1 | M | C 系列 |
| **S3 检索** | 4 个 recall 节点（无 LLM） | 召回上下文的结构（LLM 看到的 YAML） | `make stage3` | S2 | L | R 系列、FP 系列 |
| **S4 生成** | `generate_sql` + 7 提示词 | 提示词槽位 + 输出 JSON schema | `make stage4` | S3 | L | R1–R10 |
| **S5 安全** | AST 校验 + 只读执行 | SQL 策略（单语句/只读/白名单/超时） | `make stage5` | S4 | M | D1/D2/D6/D7 |
| **S6 失败** | 校正闭环 + 错误通道 | 错误码表 + UI 状态机 | `make stage6` | S5 | M | D2/D5/D8/D9、FP1–FP10 |
| **S7 前端** | 契约驱动 UI | 事件类型联合 + 类型保真 | `make stage7` | S0+S6 | M | F1–F13、B1–B4 |
| **S8 性能** | 批量召回 + 耗时 | P50/P95 预算 | `make stage8` | S7 | S | OPTIMIZATION-BACKLOG |

> 成本：S ≈ 1–2 人日，M ≈ 2–3 人日，L ≈ 3–5 人日；总计约 **25 人日**。
> 串行 5 周；按 DAG 并行（S1∥S2 的准备、S3∥S4、S5∥S6）约 **3 周**。

---

## 5. 阶段详述

### S0 · 骨架：先让"假系统"端到端跑起来

**目标**：不接 LLM、不接数据库、不接检索，用假数据跑通 `前端 → SSE → 步骤条`。

**交付物**
- `contracts/sse.schema.json`：三种事件
  - `progress { step, status: running|success|error, duration_ms }`
  - `result { columns: [{name,type}], rows }`
  - `error { code, message, step }`
- `contracts/steps.yaml`：12 个步骤 + `conditional: true` 标记（`correct_sql`）
- 后端 `GET /api/steps` 下发步骤目录；`POST /api/query` 返回**假流**（按 steps.yaml 顺序发 progress）
- 前端从 `/api/steps` 渲染步骤条，**删除硬编码的 12 节点**

**不做什么**：不装 MySQL/ES/Qdrant，不调 LLM，不做真实 SQL。

**验收**
```bash
make stage0
# 1) curl -N POST /api/query 能收到 >= 12 条 data: 行
# 2) 事件全部通过 sse.schema.json 校验
# 3) Playwright 截图：12 个节点按顺序点亮
```

**负向夹具**：旧系统 `correct_sql` 永远 `pending`（D4）；新系统必须能显示"跳过"或"未触发"，而不是灰块。

**Demo**：一个 15 秒录屏——提问，步骤条依次亮起，结果表格出现（假数据）。

---

### S1 · Schema：把"表结构"变成可校验的契约

**目标**：让 DDL、元数据库、`meta_config.yaml`、功能清单**四方对账**，并补上 DDL 表达不了的三样东西。

**交付物**
- `contracts/schema.contract.yaml`：每张表声明
  - `grain`（粒度，如 `dim_region: 省/大区，无 city`）
  - `measures`（口径，如 `order_quantity: 件数，≠ 订单数`；`order_amount: 整单金额，不含退款/运费`）
  - `value_domain`（值域，如 `date_id ∈ [20250101, 20250331]`、区域枚举）
- `docs/schema_contract.py`：`--check` 三方 diff（DDL ↔ meta.column_info ↔ meta_config）
- 自动生成 `docs/SCHEMA-CONTRACT.md`（人读版）

**不做什么**：不建 ES/Qdrant，不写检索，不调 LLM。

**验收**
```bash
make stage1
# 1) schema_contract.py --check 退出码 0
# 2) 三个已知矛盾全部被检出（AOV 三义 / 无 city / order_quantity 口径）
# 3) 功能清单的"6 表 138 行"漂移被检出
```

**负向夹具**：旧 `conf/meta_config.yaml:172-176` 的 AOV 自相矛盾必须让检查**红**；修复后必须**绿**。

**Demo**：`--check` 先红后绿的两屏对比；生成的契约表里 AOV 一行写明唯一口径。

---

### S2 · 构建：一条命令从零重建三个存储

**目标**：`meta_config` → meta DB → ES 索引 → Qdrant collection → 向量，全链路幂等。

**交付物**
- `build_meta_knowledge` CLI：`--fresh` / `--verify` / `--dry-run`
- 产物清单 + 版本号（写入 meta 库一张 `build_manifest` 表：时间、配置 hash、各存储计数）
- 幂等测试：连跑两次，第二次零写入

**不做什么**：不做召回，不做 LLM。

**验收**
```bash
make stage2
# 1) docker compose down -v 后 --fresh 一次成功
# 2) --verify 打印三存储计数并与 manifest 一致
# 3) 再跑一次不带 --fresh 的构建 → 零写入（幂等）
```

**Demo**：删卷 → 一条命令 → `--verify` 全绿（当前 `bootstrap.sh --fresh` 已能做到 221 秒，直接复用）。

---

### S3 · 检索：先证明"喂给 LLM 的上下文是对的"

**目标**：4 个 recall 节点 + merge/filter/add_extra_context，**不调 LLM**，纯函数化。

**交付物**
- 每个节点：`state -> state` 片段，可单测
- **批量召回**：`recall_value` 用 ES `_msearch` 一次查完（当前是 N+1：14–21 次 ES / 17–19 次 embedding，占 49% 耗时）
- 20 题黄金集：问题 → 期望召回的表/列/指标/值（recall@k / precision）
- CLI：`python -m app.scripts.recall "华北销售额"` 打印**LLM 将看到的 YAML**

**不做什么**：不生成 SQL，不执行 SQL。

**验收**
```bash
make stage3
# 1) pytest tests/recall：20 题黄金集全过
# 2) 单题 ES 往返 <= 2 次（旧系统 14–21 次）
# 3) 打印的 YAML 与契约文件一致（无截断、无丢字段）
```

**负向夹具**：旧系统 `examples` 截断到 10 条且无 ORDER BY（审计 C 系列）——新系统必须完整或显式声明截断策略。

**Demo**：同一问题，打印"检索到的上下文"——这是整个系统最该被看见的中间产物。

---

### S4 · 生成：提示词是"带 schema 的模板"，不是自由文本

**目标**：`generate_sql` 产出**可被机器判定**的 SQL 或拒答。

**交付物**
- 7 个提示词：每个声明**输入槽位** + **输出 JSON schema**（`{sql}` 或 `{refusal:{code,reason}}`）
- 槽位校验真实生效（旧系统 `input_variables` 是死代码：`PromptTemplate` 自动探测覆盖声明）
- 三条硬规则进提示词 + 测试：**排名必带 ORDER BY**、**越界必拒答**、**禁止常量/NULL 投影**
- 10 题基线（复用 `ux-examples-catalog.md`）

**不做什么**：不执行 SQL（只到"生成 + 静态校验"）。

**验收**
```bash
make stage4
# 1) 10/10 生成合法 SQL（EXPLAIN 通过）
# 2) 语义断言：单语句 / 只读 / 列存在 / 无常量投影 / 排名有 ORDER BY
# 3) 越界题返回 refusal JSON，而不是空数组
# 4) 槽位缺失时模板直接报错（不再静默）
```

**负向夹具**：旧系统 10 题里 #5 空结果 / #6 `error_message` 行 / #7 全 NULL 三道坏题——新系统必须分别给出"空结果""拒答""显式 NULL 说明"，而不是伪装成功。

**Demo**：`make baseline` 表格：问题 / SQL / 判定（pass / refusal）。

---

### S5 · 安全：把"只读"从提示词搬进代码

**目标**：SQL 在执行前经过**AST 级**策略校验；数据库账号本身只读。

**交付物**
- `validate_sql` 用 `sqlglot` 解析：单语句、仅 SELECT、表/列白名单、禁 DDL/DML/INTO/LOAD、去注释、自动加 LIMIT
- 只读 DB 账号（`GRANT SELECT`）+ 语句超时（`max_execution_time`）
- 注入语料：多语句、`SELECT 1; DROP`、`UPDATE`、`UNION` 外带、注释绕过、`INTO OUTFILE`

**不做什么**：不做自动校正（S6 才做）。

**验收**
```bash
make stage5
# 1) 注入语料 100% 拒绝，返回 error.code = SQL_REJECTED
# 2) 旧系统能跑通的 UPDATE / 多语句，新系统全部拒绝
# 3) 正常 10 题零误杀
```

**负向夹具**：`audit-sql-validation.md` 的 D6 实测（EXPLAIN 放行 UPDATE、多语句第二句执行）必须原样复现为失败用例。

**Demo**：同一段恶意 SQL，旧系统执行、新系统拒绝——两屏对比。

---

### S6 · 失败：让每一种失败都有名字、有 UI、有测试

**目标**：校正闭环 + 错误通道端到端打通。

**交付物**
- `correct_sql`：最多 1 次重试、**校正后重新校验**、保留原始 SQL、清空旧 `error`
- 错误码表：`SQL_REJECTED` / `SQL_SYNTAX` / `SQL_UNKNOWN_COLUMN` / `EMPTY_RESULT` / `LLM_REFUSAL` / `TIMEOUT` / `CANCELLED`
- SSE `error` 事件真正可达；前端：失败步骤红叉 + 红框 + 可复制错误
- 取消 → `cancelled`（不是 `done`）

**不做什么**：不加新功能，只补失败路径。

**验收**
```bash
make stage6
# 1) 6 类失败各一个 Playwright 用例，UI 状态互不相同
# 2) 校正后 SQL 必须再次过 S5 策略
# 3) 取消请求：状态 = cancelled，步骤条停止推进
```

**负向夹具**：旧系统"取消被计为完成"（`App.tsx:149`）、"伪 SQL 当数据行"——新系统必须红框 + 错误码。

**Demo**：5 种失败态录屏（复用 `ux-demo-failed.mp4` 的剧本）。

---

### S7 · 前端：从契约生成，不从记忆硬编码

**目标**：13 条前端缺陷逐条闭环。

**交付物**
- 事件类型联合（zod / TS 生成自 `contracts/sse.schema.json`）
- 数字/字符串类型保真（Decimal 不再变字符串）
- 空数组 → 显式"无数据"；全 null 列 → 显式标注
- 步骤目录来自 API；`conditional` 步骤显示"未触发"
- 去掉固定 820×780 画布，响应式

**不做什么**：不改后端契约（除非契约本身有 bug）。

**验收**
```bash
make stage7
# 1) 13 条 F 缺陷各一个 Playwright 用例
# 2) tsc --noEmit 零错误
# 3) 用录制好的 SSE fixture 回放，UI 与真实流一致
```

**Demo**：重录三支视频（正常 / 示例 / 失败），与旧版逐帧对比。

---

### S8 · 性能：先有基线，再谈优化

**目标**：把 `OPTIMIZATION-BACKLOG.md` 的 P0 落地，且不改变任何功能语义。

**交付物**
- `progress.duration_ms` 真实耗时（每步）
- `recall_value` 批量 + 必要缓存
- 同一问题 P50 < 3s（旧 11.25s）；ES ≤ 4 次/query（旧 14–21）；embedding ≤ 6 次（旧 17–19）

**不做什么**：不引入新组件，不改契约。

**验收**
```bash
make stage8
# hotpath_probe.py --repeat 5：P50/P95 达标
# 功能回归：stage3/4/5/6/7 全绿
```

**Demo**：前后对比表 + 火焰图/耗时条。

---

## 6. 依赖图与里程碑

```mermaid
graph LR
  S0[S0 骨架] --> S1[S1 Schema]
  S1 --> S2[S2 构建]
  S2 --> S3[S3 检索]
  S2 --> S4[S4 生成]
  S3 --> S4
  S4 --> S5[S5 安全]
  S5 --> S6[S6 失败]
  S0 --> S7[S7 前端]
  S6 --> S7
  S7 --> S8[S8 性能]
```

**五个可停点（每个都是一个能演示的产品）**

| 里程碑 | 含阶段 | 停在这里能演示什么 |
|---|---|---|
| **M1 骨架** | S0 | 前端步骤条 + 假 SSE 全链路 |
| **M2 数据** | S1–S2 | 一条命令从零建库；schema 契约全绿 |
| **M3 问答** | S3–S4 | 真问题 → 真 SQL（只生成不执行） |
| **M4 可信** | S5–S6 | 恶意 SQL 被拒；6 类失败有 UI |
| **M5 产品** | S7–S8 | 13 条前端缺陷闭环；P50 < 3s |

> 如果目标是**课程章节**：S0–S8 直接映射 8 章，每章末尾的 Demo 就是课程验收。
> 教学上也可把 S1 提前到 S0 之前（先讲数仓），但工程上不推荐——契约会晚一步。

---

## 7. 现有资产怎么复用（不浪费这轮审计）

| 资产 | 在重建中的角色 |
|---|---|
| `audit-*.md`（5 份） | **验收用例库**：D/F/B/C/R/FP 每条编号 → 一个测试 |
| `docker/bootstrap.sh --fresh` | S2 的 `make stage2` 底座（已实测 221 秒） |
| `docs/hotpath_probe.py` | S8 的基线/回归工具 |
| `docs/module_graph.py` / `module_counter.py` | 结构守卫：阶段结束时模块数/环/契约不退化 |
| `docs/interface_count.py` | 契约守卫：11 族 / 36 条不许悄悄少 |
| `ux-examples-catalog.md` + 10 题真实 SQL | S4 的黄金集与快照 |
| `ux-demo-failed.mp4` 剧本 | S6 的 UI 验收剧本 |
| 旧系统本身 | **反例库**：行为录成 fixture，新系统必须与它不同 |

**关键做法**：不要"修旧系统"，而是**新建 `rebuild/` 目录**，旧系统冻结为 `legacy/`。
每个契约测试跑两遍：`legacy` 期望失败、`rebuild` 期望通过——这叫**差分验收**，能证明"重建确实修好了"，而不是"换了个写法"。

---

## 8. "从零"的最终证明：`make from-zero`

```bash
make from-zero
# 1) docker compose down -v          # 清空所有卷
# 2) docker compose up -d            # 起 7 个容器
# 3) build_meta_knowledge --fresh    # 建 meta/ES/Qdrant
# 4) pytest -m stage0..stage8        # 全部验收
# 5) 录制三支视频                     # 产物
# 退出码 0 + 总耗时打印
```

**这是"能渐进式从零搭建"的唯一硬证明**：不是文档说能，而是一条命令在空机器上跑通。

---

## 9. 三个必须先定的决策

| # | 决策 | 选项 | 建议 |
|---|---|---|---|
| 1 | **重建位置** | ① 新建 `rebuild/`，旧系统冻结为 `legacy/` ② 原地重构 | **①**：差分验收需要旧系统当反例；原地改会丢掉对照 |
| 2 | **目标深度** | ① 教学可讲（S0–S7） ② 生产可用（+S8 + 只读账号 + 审计日志） | **②**：S5 的只读账号是安全底线，不能省 |
| 3 | **范围边界** | 是否包含多轮对话 / 权限 / 多数据源 | **暂不**：当前 API 是单轮 `{query}`，加进来会把 S0 契约撑爆 |

---

## 10. 下一步（按 ask-matt 的主流程）

1. **`/grill-with-docs`**：把上面 3 个决策问定，产出 `GLOSSARY.md`（步骤/契约/错误码的统一叫法）+ 1 篇 ADR（为什么契约先行）。
2. **`/to-spec`**：把本路线图收敛成一份可执行 spec（每阶段的输入/输出/验收）。
3. **`/to-tickets`**：每个阶段拆成 tracer-bullet 工单，声明 blocking edges（S0 → S1 → S2 → …）。
4. **`/implement`**：逐票实现，票间 `/clear`；或 **`/implement-spec`** 按 DAG 并行跑 S3∥S4、S5∥S6。
5. 每完成一个里程碑，跑一次 `make from-zero` + 重录 Demo——**可停点必须是可演示的**。
