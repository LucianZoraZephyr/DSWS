#!/usr/bin/env python3
"""interface_count.py —— 数"对外暴露协议的黑盒单元"（Parnas 意义上的模块）

与 module_counter.py 的区别：
  module_counter.py  数的是"内部文件按职责怎么聚簇"
  interface_count.py 数的是"哪些契约对外暴露"——即黑盒的**接口面**

自动抽取的协议来源：
  A. HTTP 端点（FastAPI 路由）        B. 请求/响应模型（Pydantic）
  C. SSE 事件类型（前端 TS 与后端对齐） D. 提示词模板（LLM 契约）
  E. 配置文件（运行时配置 / 元数据）    F. SQL DDL（表结构）
  G. 领域实体（跨模块数据结构）         H. 外部系统适配器（我们调用的对端）

用法：python3 docs/interface_count.py [--json]
"""
from __future__ import annotations

import argparse
import ast
import json
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BE = ROOT.parent / "shopkeeper-agent-frontend"


def read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return ""


def find_http_endpoints() -> list[dict]:
    out = []
    for p in sorted((ROOT / "app" / "api" / "routers").rglob("*.py")):
        src = read(p)
        for m in re.finditer(r'@(\w+)\.(get|post|put|delete|patch)\(\s*"([^"]+)"', src):
            out.append({"method": m.group(2).upper(), "path": m.group(3),
                        "file": str(p.relative_to(ROOT))})
    return out


def find_pydantic_models() -> list[dict]:
    out = []
    for p in sorted((ROOT / "app").rglob("*.py")):
        try:
            tree = ast.parse(read(p))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                bases = {ast.unparse(b) for b in node.bases}
                if any("BaseModel" in b for b in bases):
                    fields = [n.target.id for n in node.body
                              if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)]
                    out.append({"model": node.name, "fields": fields,
                                "file": str(p.relative_to(ROOT))})
    return out


def find_sse_events() -> list[dict]:
    """前端声明的 SSE 事件类型（与后端 query_service 的事件格式对齐）。"""
    p = BE / "src" / "types" / "agent.ts"
    src = read(p)
    out = []
    for m in re.finditer(r'export type (\w+Event)\s*=\s*\{[^}]*type:\s*"(\w+)"', src, re.S):
        out.append({"type": m.group(2), "alias": m.group(1), "file": "frontend/src/types/agent.ts"})
    for m in re.finditer(r'type:\s*"(\w+)"', src):
        t = m.group(1)
        if t not in {o["type"] for o in out}:
            out.append({"type": t, "alias": "-", "file": "frontend/src/types/agent.ts"})
    return out


def find_prompts() -> list[dict]:
    out = []
    for p in sorted((ROOT / "prompts").glob("*.prompt")):
        ph = sorted(set(re.findall(r"\{([a-z_]+)\}", read(p))))
        out.append({"prompt": p.name, "placeholders": ph})
    return out


def find_configs() -> list[dict]:
    out = []
    for name in ("app_config.yaml", "meta_config.yaml"):
        p = ROOT / "conf" / name
        if not p.exists():
            continue
        keys = []
        for line in read(p).splitlines():
            if line and not line.startswith((" ", "#", "-")) and ":" in line:
                keys.append(line.split(":")[0].strip())
        out.append({"config": name, "sections": keys})
    return out


def find_sql_tables() -> list[dict]:
    out = []
    for p in sorted((ROOT / "docker" / "mysql").glob("*.sql")):
        src = read(p)
        for m in re.finditer(r"CREATE TABLE(?: IF NOT EXISTS)?\s+`?(\w+)`?\s*\((.*?)\)\s*(?:ENGINE|;)",
                             src, re.S | re.I):
            cols = re.findall(r"^\s*`?(\w+)`?\s+\w", m.group(2), re.M)
            out.append({"db": p.stem, "table": m.group(1), "columns": cols})
    return out


def find_entities() -> list[dict]:
    out = []
    for p in sorted((ROOT / "app" / "entities").glob("*.py")):
        try:
            tree = ast.parse(read(p))
        except SyntaxError:
            continue
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                fields = [n.target.id for n in node.body
                          if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)]
                out.append({"entity": node.name, "fields": fields})
    return out


def find_adapters() -> list[dict]:
    out = []
    for p in sorted((ROOT / "app" / "clients").glob("*.py")):
        name = p.stem.replace("_client_manager", "")
        target = {"embedding": "TEI (/embed, bge-large-zh-v1.5)",
                  "es": "Elasticsearch (_search)",
                  "mysql": "MySQL (SQL)",
                  "qdrant": "Qdrant (/points/search)"}.get(name, name)
        out.append({"adapter": name, "target_system": target,
                    "file": str(p.relative_to(ROOT))})
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="统计对外暴露协议的黑盒单元")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    data = {
        "http_endpoints": find_http_endpoints(),
        "request_models": find_pydantic_models(),
        "sse_events": find_sse_events(),
        "prompts": find_prompts(),
        "configs": find_configs(),
        "sql_tables": find_sql_tables(),
        "entities": find_entities(),
        "adapters": find_adapters(),
    }

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    print("=" * 88)
    print("对外暴露的协议清单（黑盒的接口面）")
    print("=" * 88)

    print("\n【A】HTTP 端点")
    for e in data["http_endpoints"]:
        print(f"  {e['method']:<6}{e['path']:<16} {e['file']}")

    print("\n【B】请求模型")
    for m in data["request_models"]:
        print(f"  {m['model']:<16}{{{', '.join(m['fields'])}}}")

    print("\n【C】SSE 事件类型（前端 TS 声明）")
    for e in data["sse_events"]:
        print(f"  type=\"{e['type']}\"  ({e['alias']})  {e['file']}")

    print("\n【D】提示词协议（代码 ↔ LLM）")
    for p in data["prompts"]:
        print(f"  {p['prompt']:<40}{'{' + ', '.join(p['placeholders']) + '}'}")

    print("\n【E】配置协议")
    for c in data["configs"]:
        print(f"  {c['config']:<20}{c['sections']}")

    print("\n【F】数据协议（SQL DDL）")
    by_db = defaultdict(list)
    for t in data["sql_tables"]:
        by_db[t["db"]].append(t)
    for db, ts in by_db.items():
        print(f"  {db} 库：{len(ts)} 张表 → " + ", ".join(f"{t['table']}({len(t['columns'])}列)" for t in ts))

    print("\n【G】领域实体（跨模块数据契约）")
    for e in data["entities"]:
        print(f"  {e['entity']:<16}{{{', '.join(e['fields'])}}}")

    print("\n【H】外部系统适配器（我们调用的对端协议）")
    for a in data["adapters"]:
        print(f"  {a['adapter']:<12}→ {a['target_system']}")

    # -------- 归并成"黑盒" --------
    black_boxes = []
    black_boxes.append(("问数 API（HTTP + SSE + 请求体）",
                        1 + len(data["request_models"]) + len(data["sse_events"]),
                        "应用被调用的唯一入口"))
    black_boxes.append(("建库 CLI", 1, "build_meta_knowledge -c <conf>"))
    black_boxes.append(("提示词契约", len(data["prompts"]), "每个 .prompt 是一个独立契约"))
    black_boxes.append(("运行时配置", 1, "conf/app_config.yaml"))
    black_boxes.append(("元数据配置", 1, "conf/meta_config.yaml"))
    black_boxes.append(("dw 数仓表结构", sum(1 for t in data["sql_tables"] if t["db"] == "dw"), "5 张表"))
    black_boxes.append(("meta 元数据库表结构", sum(1 for t in data["sql_tables"] if t["db"] == "meta"), "4 张表"))
    black_boxes.append(("ES 索引 schema", 1, "value_index 文档结构（ValueInfo）"))
    black_boxes.append(("Qdrant collection schema", 2, "column_info_collection / metric_info_collection"))
    black_boxes.append(("领域实体协议", len(data["entities"]), "5 个实体 = 同一套元数据模型"))
    black_boxes.append(("外部系统适配器协议", len(data["adapters"]), "TEI / ES / MySQL / Qdrant"))

    print("\n" + "=" * 88)
    print("归并后的黑盒（按协议族）")
    print("=" * 88)
    print(f"{'#':<4}{'黑盒':<36}{'含契约数':<10}说明")
    for i, (name, n, note) in enumerate(black_boxes, 1):
        print(f"{i:<4}{name:<36}{n:<10}{note}")
    total_contracts = sum(n for _, n, _ in black_boxes)
    print(f"\n  ⇒ 黑盒（协议族）: {len(black_boxes)} 个")
    print(f"  ⇒ 独立契约条目: {total_contracts} 个")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
