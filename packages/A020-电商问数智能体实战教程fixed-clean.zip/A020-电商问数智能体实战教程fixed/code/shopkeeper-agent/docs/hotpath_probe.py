#!/usr/bin/env python3
"""hotpath_probe.py —— 问数链路的性能探针（只读观测，不改任何东西）

用途：定位"一次问数到底慢在哪"，以及优化前后的前后对比。

    python3 docs/hotpath_probe.py
    python3 docs/hotpath_probe.py --repeat 5
    python3 docs/hotpath_probe.py --query "按会员等级统计 2025 年第一季度的订单数和销售额"
    python3 docs/hotpath_probe.py --json          # 机器可读

依赖：只用到标准库 + urllib。要求栈已在运行（docker compose up -d）。

观测口径：
  - 端到端耗时 / 每个节点的耗时（从 SSE progress 事件的时间戳还原）
  - ES 检索次数（_nodes/stats/http 的 routes 计数，按路径后缀 _search）
  - TEI 向量化条数与请求数（/metrics 的 te_embed_count / te_request_count）
  - SSE 帧数（判断是否流式而非一次性返回）
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
import urllib.error
import urllib.request

API = "http://127.0.0.1:8000/api/query"
ES_STATS = "http://127.0.0.1:9200/_nodes/stats/http"
TEI_METRICS = "http://127.0.0.1:8081/metrics"
DEFAULT_QUERY = "统计 2025 年第一季度各大区的 GMV，并按 GMV 从高到低排序"


def _get(url: str, timeout: float = 10.0):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def tei_counters() -> tuple[float, float, float]:
    """返回 (single 请求数, batch 请求数, 向量条数)；TEI 不可达时返回全 0。"""
    try:
        raw = _get(TEI_METRICS)
    except Exception:
        return 0.0, 0.0, 0.0
    single = batch = embed = 0.0
    for line in raw.splitlines():
        if line.startswith("te_request_count"):
            v = float(line.rsplit(" ", 1)[1])
            if 'method="single"' in line:
                single = v
            elif 'method="batch"' in line:
                batch = v
        elif line.startswith("te_embed_count "):
            embed = float(line.rsplit(" ", 1)[1])
    return single, batch, embed


def es_search_count() -> float:
    """ES 按路由统计的 _search 请求数；不可达时返回 0。"""
    try:
        d = json.loads(_get(ES_STATS))
    except Exception:
        return 0.0
    total = 0.0
    for node in d.get("nodes", {}).values():
        for route, stat in (node.get("http", {}).get("routes") or {}).items():
            if route.endswith("_search"):
                total += stat.get("requests", {}).get("count", 0)
    return total


def run_once(query: str, timeout: float = 180.0) -> dict:
    s0, b0, e0 = tei_counters()
    es0 = es_search_count()

    req = urllib.request.Request(
        API,
        data=json.dumps({"query": query}).encode(),
        headers={"Content-Type": "application/json"},
    )
    t0 = time.time()
    frames: list[tuple[float, dict]] = []
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        buf = b""
        while True:
            chunk = resp.read1(4096)
            if not chunk:
                break
            buf += chunk
            while b"\n\n" in buf:
                part, buf = buf.split(b"\n\n", 1)
                for ln in part.split(b"\n"):
                    if ln.startswith(b"data:"):
                        try:
                            frames.append((time.time() - t0, json.loads(ln[5:].strip())))
                        except json.JSONDecodeError:
                            pass
    elapsed = time.time() - t0

    # 由 progress 事件还原每步耗时
    steps: list[dict] = []
    prev = 0.0
    for ts, ev in frames:
        if ev.get("type") == "progress" and ev.get("status") == "success":
            steps.append({"step": ev.get("step"), "seconds": round(ts - prev, 2),
                          "at": round(ts, 2)})
            prev = ts
    result = next((ev for _, ev in frames if ev.get("type") == "result"), None)

    return {
        "query": query,
        "elapsed": round(elapsed, 2),
        "frames": len(frames),
        "steps": steps,
        "es_searches": int(es_search_count() - es0),
        "tei_single": int(tei_counters()[0] - s0),
        "tei_batch": int(tei_counters()[1] - b0),
        "tei_vectors": int(tei_counters()[2] - e0),
        "result": result.get("data") if isinstance(result, dict) else None,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="问数链路性能探针")
    ap.add_argument("--query", default=DEFAULT_QUERY, help="要问的问题")
    ap.add_argument("--repeat", type=int, default=1, help="重复次数（看抖动）")
    ap.add_argument("--timeout", type=float, default=180.0)
    ap.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    args = ap.parse_args()

    runs = []
    for i in range(max(1, args.repeat)):
        try:
            runs.append(run_once(args.query, args.timeout))
        except (urllib.error.URLError, TimeoutError) as e:
            print(f"✘ 第 {i+1} 次失败：{e}", file=sys.stderr)
            print("   栈是否在运行？先执行 cd docker && ./bootstrap.sh", file=sys.stderr)
            return 2
        if not args.json and len(runs) < args.repeat:
            time.sleep(1)

    if args.json:
        print(json.dumps(runs, ensure_ascii=False, indent=2))
        return 0

    print(f"问题：{args.query}")
    for i, r in enumerate(runs, 1):
        print(f"\n── 第 {i}/{len(runs)} 次 ──────────────────────────────")
        print(f"  端到端 {r['elapsed']}s   SSE 帧 {r['frames']}   "
              f"ES 检索 {r['es_searches']} 次   "
              f"向量化 {r['tei_vectors']} 条（single {r['tei_single']} / batch {r['tei_batch']}）")
        for s in r["steps"]:
            bar = "█" * max(1, int(s["seconds"] * 3))
            print(f"    {s['seconds']:6.2f}s {bar} {s['step']}")
        if r["result"] is not None:
            print(f"    结果 {len(r['result'])} 行："
                  f"{' | '.join(str(v) for row in r['result'][:3] for v in row.values())}")

    if len(runs) > 1:
        es = [r["elapsed"] for r in runs]
        print(f"\n  端到端  min {min(es):.1f}s  p50 {statistics.median(es):.1f}s  max {max(es):.1f}s"
              f"   （LLM 本身抖动就有 ±3s，多跑几次再看中位数）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
