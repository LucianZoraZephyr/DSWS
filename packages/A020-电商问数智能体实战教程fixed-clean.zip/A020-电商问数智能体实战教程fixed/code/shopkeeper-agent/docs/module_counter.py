#!/usr/bin/env python3
"""module_counter.py —— 用工程（设计）意义统计"模块数"，而不是 Python 意义的 .py 文件数

方法：四个独立信号互相印证

  A. 静态边界    —— 命名空间/包边界给出候选模块
  B. 社区发现    —— 在 import 图上跑 Louvain，看算法自己认为的自然分组在哪
  C. 内聚/耦合   —— 每个候选的内部边密度 vs 外部边密度（好模块：高内聚、低外耦）
  D. 接口面大小  —— 一个模块对外暴露多少公开符号（暴露太多 = 职责过载）
  E. 变更共现    —— git 历史里总是一起改的文件属于同一模块（本项目暂无 git，见 --explain）

用法：
    python3 docs/module_counter.py              # 完整报告
    python3 docs/module_counter.py --json
"""
from __future__ import annotations

import argparse
import ast
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from module_graph import collect_modules, layer_of, parse_imports  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


# ------------------------------------------------------------------ 图
def build_graph():
    mods = collect_modules()
    known = set(mods)
    edges = {m: parse_imports(p, m, known) for m, p in mods.items()}
    adj: dict[str, set[str]] = defaultdict(set)
    for s, dd in edges.items():
        for d in dd:
            if layer_of(d) == "external":
                continue
            adj[s].add(d)
            adj[d].add(s)
    return mods, edges, adj


# ------------------------------------------------------------------ Louvain
def louvain(adj: dict[str, set[str]], resolution: float = 1.0):
    """单层 Louvain（节点数很小，够用）。返回 {节点: 社区号}。"""
    nodes = sorted(adj)
    comm = {n: i for i, n in enumerate(nodes)}
    k = len(nodes)
    deg = {n: len(adj[n]) for n in nodes}
    m2 = sum(deg.values()) or 1  # 2 * 边数

    improved = True
    while improved:
        improved = False
        for n in nodes:
            cur = comm[n]
            neigh: dict[int, float] = defaultdict(float)
            for x in adj[n]:
                if x != n:
                    neigh[comm[x]] += 1
            comm[n] = -1  # 移出
            base = comm.get(n, -1)
            best, best_gain = cur, None
            for c, w in neigh.items():
                gain = (w - resolution * deg[n] * (comm_size(comm, c) / m2)) / m2
                if best_gain is None or gain > best_gain:
                    best, best_gain = c, gain
            # 与留在原社区的收益比较
            own = (neigh.get(cur, 0.0) - resolution * deg[n] * (comm_size(comm, cur) / m2)) / m2
            if best_gain is None or own > best_gain:
                best = cur
            comm[n] = best
            if best != cur:
                improved = True
    # 压缩社区号
    labels = {}
    out = {}
    for n in nodes:
        c = comm[n]
        if c not in labels:
            labels[c] = len(labels)
        out[n] = labels[c]
    return out


def comm_size(comm, c):
    return sum(1 for v in comm.values() if v == c)


def modularity(adj, comm):
    nodes = list(adj)
    m2 = sum(len(adj[n]) for n in nodes) or 1
    deg = {n: len(adj[n]) for n in nodes}
    inside = defaultdict(int)
    for n in nodes:
        for x in adj[n]:
            if comm.get(x) == comm.get(n):
                inside[comm[n]] += 1
    q = 0.0
    for c, degsum in _community_degrees(comm, deg).items():
        inside_edges = inside[c] / 2
        q += inside_edges / m2 - (degsum / (2 * m2)) ** 2
    return q


def _community_degrees(comm, deg):
    out = defaultdict(int)
    for n, d in deg.items():
        out[comm[n]] += d
    return out


# ------------------------------------------------------------------ 其它信号
def public_symbols(paths) -> int:
    """统计对外公开的函数/类数量（不以下划线开头）。"""
    n = 0
    for p in paths:
        try:
            tree = ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if not node.name.startswith("_"):
                    n += 1
    return n


def main() -> int:
    ap = argparse.ArgumentParser(description="工程意义的模块计数")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--resolution", type=float, default=1.0)
    ap.add_argument("--detail", action="store_true", help="打印每个职责簇的成员与对外依赖")
    args = ap.parse_args()

    mods, edges, adj = build_graph()
    nodes = sorted(mods)
    internal = {(s, d) for s, dd in edges.items() for d in dd if layer_of(d) != "external"}

    # --- 信号 B：不同分辨率下的模块数与模块度 ---
    scan = []
    best = None
    for res in [0.4, 0.6, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0]:
        comm = louvain(adj, res)
        q = modularity(adj, comm)
        k = len(set(comm.values()))
        scan.append((res, k, q))
        if best is None or q > best[2]:
            best = (res, k, q, comm)

    res, k, q, comm = best
    groups: dict[int, list[str]] = defaultdict(list)
    for n, c in comm.items():
        groups[c].append(n)

    # --- 每个社区的内聚/耦合 + 接口面 ---
    members_of = {c: sorted(v) for c, v in groups.items()}
    internal_edges = defaultdict(int)
    external_edges = defaultdict(int)
    for s, d in internal:
        if comm.get(s) == comm.get(d):
            internal_edges[comm[s]] += 1
        else:
            external_edges[comm[s]] += 1
            external_edges[comm[d]] += 1

    rows = []
    for c, mem in members_of.items():
        n = len(mem)
        possible = n * (n - 1) / 2
        density = internal_edges[c] / possible if possible else 0.0
        out_deg = external_edges[c]
        rows.append({
            "id": c,
            "size": n,
            "members": mem,
            "internal_edges": internal_edges[c],
            "external_edges": out_deg,
            "density": round(density, 3),
            "coupling_ratio": round(out_deg / max(1, internal_edges[c]), 3),
            "public_symbols": public_symbols([mods[m] for m in mem]),
            "layers": sorted({layer_of(m) for m in mem}),
        })
    rows.sort(key=lambda r: -r["size"])

    if args.json:
        print(json.dumps({
            "python_modules": len(mods),
            "louvain_scan": [{"resolution": r, "modules": kk, "modularity": round(qq, 4)} for r, kk, qq in scan],
            "best": {"resolution": res, "modules": k, "modularity": round(q, 4)},
            "engineering_modules": rows,
        }, ensure_ascii=False, indent=2))
        return 0

    print("=" * 92)
    print(f"Python 意义的模块（.py 文件 / 包）: {len(mods)} 个")
    print("=" * 92)

    print("\n【信号 B】Louvain 社区发现 —— 不同分辨率下的模块数")
    print(f"  {'分辨率':<10}{'模块数':<10}{'模块度 Q'}")
    for r, kk, qq in scan:
        star = "  ← 最优" if abs(r - res) < 1e-9 else ""
        print(f"  {r:<10.1f}{kk:<10}{qq:.4f}{star}")

    print(f"\n【结论】最优切分：分辨率 {res} → {k} 个工程模块（模块度 Q={q:.4f}）\n")

    print(f"{'#':<4}{'模块数':<8}{'内部边':<8}{'外部边':<8}{'内聚密度':<10}{'耦/聚比':<9}{'公开符号':<9}包含的层")
    for i, r in enumerate(rows, 1):
        print(f"{i:<4}{r['size']:<8}{r['internal_edges']:<8}{r['external_edges']:<8}"
              f"{r['density']:<10.2f}{r['coupling_ratio']:<9.2f}{r['public_symbols']:<9}"
              f"{','.join(r['layers'])}")

    print("\n各工程模块的成员：")
    for i, r in enumerate(rows, 1):
        print(f"\n  M{i}（{r['size']} 个文件 / {r['public_symbols']} 个公开符号）")
        for m in r["members"]:
            print(f"      {m}")

    # --- 对照：按人工分层统计 ---
    print("\n" + "=" * 92)
    print("【对照】按「分层」口径统计（设计意图：依赖自上而下）")
    print("=" * 92)
    layer_groups: dict[str, list[str]] = defaultdict(list)
    for n in nodes:
        layer_groups[layer_of(n)].append(n)
    print(f"{'层':<10}{'文件数':<8}{'内部边':<8}{'外部边':<8}{'内聚密度':<10}{'耦/聚比':<9}{'公开符号'}")
    for lay, mem in layer_groups.items():
        ms = set(mem)
        ie = sum(1 for s, d in internal if s in ms and d in ms)
        oe = sum(1 for s, d in internal if (s in ms) != (d in ms))
        n = len(mem)
        possible = n * (n - 1) / 2
        dens = ie / possible if possible else 0
        ps = public_symbols([mods[m] for m in mem])
        print(f"{lay:<10}{n:<8}{ie:<8}{oe:<8}{dens:<10.2f}{oe/max(1,ie):<9.2f}{ps}")

    print("\n【两法对照】")
    print(f"  · 社区发现（只看 import 图）→ {k} 个模块，模块度 Q={q:.4f}")
    print(f"  · 分层口径（看依赖方向）  → {len(layer_groups)} 个层")
    print("  · 两者不一致，且 Q 值低 ⇒ **import 图本身不足以反映设计模块**：")
    print("    原因是星型拓扑——11 个节点都经由 context / state / llm 三个中心，")
    print("    把 agent、support、repo 粘成了一坨。")
    print("  ⇒ 工程上算模块数，要用「分层 + 领域职责 + 变更共现」三者交叉，单靠 import 图会低估。")

    print("\n【三】按「层内职责（子目录）」再切 —— 得到可论证的工程模块数")
    print(f"{'层':<10}{'职责簇':<34}{'文件':<6}{'内部边':<7}{'内聚':<7}{'公开符号':<9}代表模块")
    total = 0
    clusters_all: list[tuple[str, str, list[str]]] = []
    for lay, mem in sorted(layer_groups.items()):
        clusters: dict[str, list[str]] = defaultdict(list)
        for m in mem:
            clusters[str(mods[m].parent.relative_to(ROOT))].append(m)
        for path, mem2 in sorted(clusters.items()):
            ms = set(mem2)
            ie = sum(1 for s, d in internal if s in ms and d in ms)
            n = len(mem2)
            dens = ie / (n * (n - 1) / 2) if n > 1 else 0.0
            ps = public_symbols([mods[m] for m in mem2])
            total += 1
            clusters_all.append((lay, path, sorted(mem2)))
            print(f"{lay:<10}{path:<34}{n:<6}{ie:<7}{dens:<7.2f}{ps:<9}"
                  f"{', '.join(sorted(m.split('.')[-1] for m in mem2)[:3])}")
    print(f"\n  ⇒ 工程意义下的模块数 ≈ {total} 个（按 层 × 职责簇 切分）")
    print("    判据：同层内按子目录（职责）聚合；内聚密度高的簇就是真模块，")
    print("    密度近 0 的层（support / repo / client）说明它只是「层」而不是「模块」。")

    if args.detail:
        print("\n" + "=" * 92)
        print("【明细】每个职责簇的成员与对外依赖")
        print("=" * 92)
        # 簇 → 簇 的边（按目标簇聚合）
        def cluster_of(mod: str) -> str:
            for lay, path, mem in clusters_all:
                if mod in mem:
                    return path
            return mod
        for i, (lay, path, mem) in enumerate(clusters_all, 1):
            ms = set(mem)
            out_edges: dict[str, list[str]] = defaultdict(list)
            for s in mem:
                for d in edges[s]:
                    if layer_of(d) == "external":
                        continue
                    tc = cluster_of(d)
                    if tc != path:
                        out_edges[tc].append(d)
            print(f"\n── M{i:02d}  {path}    （层 {lay}，{len(mem)} 个文件）")
            for m in mem:
                p = mods[m]
                lines = len(p.read_text(encoding="utf-8").splitlines())
                print(f"      {m:<52} {lines:>4} 行   {p.relative_to(ROOT)}")
            if out_edges:
                print("      依赖外部簇：")
                for tc, ds in sorted(out_edges.items()):
                    print(f"        → {tc:<44} {', '.join(sorted(set(ds)))}")
            else:
                print("      依赖外部簇：（无）")

    print("\n" + "=" * 92)
    print("【信号 E】变更共现（git）——本项目当前不可用：")
    print("  该目录不是 git 仓库，且文件时间戳被解压归一化（全部 05-04），")
    print("  无法统计「哪些文件总是一起改」。补救：git init + 提交一次基线后，")
    print("  用 git log --name-only 按层统计改动频次。")
    print("=" * 92)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
