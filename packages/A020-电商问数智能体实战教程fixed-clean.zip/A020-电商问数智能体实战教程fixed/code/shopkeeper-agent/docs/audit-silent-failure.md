# 静默失败链路审计报告（后端 → SSE → 前端渲染）

> **范围**：`code/shopkeeper-agent/app/**` → `app/services/query_service.py`（SSE） → `code/shopkeeper-agent-frontend/src/**`（渲染）。
> **日期**：2026-10-20。**性质**：**纯只读审计**，未修改任何源码或配置；唯一新增文件是本文件。
> **证据口径**：每条结论标注 `文件:行号` + 原文引用；无法从原文确证的标「推断」并给验证方法。
> **路径约定**：后端路径相对 `code/shopkeeper-agent/`；前端路径相对 `code/shopkeeper-agent-frontend/`（记为 `fe:`）。

---

## 0. 前提修正（先说清楚，否则后面全错）

任务书的前提是「**后端把异常包成 `result.data` 里的一行 `error_message`**」。**代码原文不支持这句话**，必须先纠正：

```
$ grep -rn "error_message" --include=*.py --include=*.prompt --include=*.yaml --include=*.sql .
（零命中，exit=1）
```

后端**没有任何一行代码**会构造 `error_message` 键、也没有任何一行会把异常包成数据行。真实机制是：

> **是 LLM 自己编了一条伪 SQL**（`SELECT '无法生成SQL：…' AS error_message;`），
> 这条伪 SQL **语法完全合法**，能过 `EXPLAIN`，于是被**真实执行**，
> MySQL 返回 1 行 1 列 —— 这一行就长得像"一条错误数据"。

`ux-examples-catalog.md:44` 记录的实测 SQL 原文佐证了这一点：
`SELECT '无法生成SQL：未提供可用数据表信息，且查询内容不明确' AS error_message;`
`ux-examples-catalog.md:53` 也明确写着：「#6 与 #7 的 SQL 是 LLM **自己编的伪 SQL**……后端 grep 不到 `error_message` 字样。」

**这条修正改变了修复方向的排序**：既然伪 SQL 是**一次成功的数据库执行**，
那么"后端把异常改成 `type:error`"这条路**没有现成的异常可捕获**——
必须**新增语义判据**（见 §5 方案 ① / ④）。

另一处措辞修正：`docker/fixed-backend-report.md:623` 与 `ux-examples-catalog.md:300` 说的
「流程图 11 个节点全绿勾」是准确的 —— `fe:src/components/StepRail.tsx:18-31` 定义了 **12** 个节点，
其中「校正SQL」未触发 → `statusFor()` 返回 `pending`（灰圈），其余 **11** 个被后端写成 `success`（绿勾）。

---

## 1. 逐跳链路表（17 跳）

| # | 代码位置 | 这一跳做了什么 | 错误信息在这里如何被吞掉 |
|---|---|---|---|
| 1 | `app/agent/nodes/generate_sql.py:46` `output_parser = StrOutputParser()`<br>`:49-62` `chain.ainvoke(...)` | LLM 产出的**任意文本**被当作 SQL 写入 `state["sql"]`（`:65` `return {"sql": result}`） | **无拒答通道**：提示词里没有"上下文不足必须拒答"的契约（`prompts/generate_sql.prompt:18-24` 七条要求逐条核对均未涉及），代码侧也没有任何"这是不是一条真查询"的判据。LLM 编伪 SQL 时**行为上完全合规** |
| 2 | `app/agent/nodes/validate_sql.py:32` → `app/repositories/mysql/dw/dw_mysql_repository.py:46-49`<br>`sql = f"explain {sql}"` | 唯一的校验动作是 `EXPLAIN` | **只验语法，不验语义**。`SELECT '…' AS error_message;` 是合法 SQL → 校验通过 → `:35` `return {"error": None}`。**这是整条链路上最致命的一跳**：校验层本该是最后一道闸门，但它对伪 SQL 完全无感 |
| 3 | `app/agent/graph.py:83-87`<br>`path=lambda state: "run_sql" if state["error"] is None else "correct_sql"` | 按 `state["error"]` 路由分支 | 伪 SQL 让 `error is None` → 直奔 `run_sql`，**「校正SQL」节点永不触发**（自我修正机制结构性地救不了这类失败） |
| 4 | `app/agent/nodes/run_sql.py:28` `result = await dw_mysql_repository.run(sql)`<br>→ `dw_mysql_repository.py:51-54` `return [dict(row) for row in result.mappings().fetchall()]` | 真实执行 SQL，取回行 | 执行层**只负责取行，不判断行是否有意义**。1 行 `{'error_message': '无法生成SQL：…'}` 在这里是"一次完全成功的查询结果" |
| 5 | `app/agent/nodes/run_sql.py:31`<br>`writer({"type": "result", "data": result})` | 推送最终结果事件 | **后端侧第一个失效点**：事件类型在此**被无条件钉死为 `result`**。执行器没有"这个结果可疑"的表达通道，任何行集合都会被标成成功结果 |
| 6 | `app/services/query_service.py:66`<br>`yield f"data: {json.dumps(chunk, ensure_ascii=False, default=str)}\n\n"` | 序列化成 SSE 帧 | **原样透传**，不做任何载荷分类/改写。第 5 跳定的类型在这里被忠实固化进协议 |
| 7 | `app/services/query_service.py:67-70`<br>`error = {"type": "error", "message": str(e)}` | 唯一的 `type:"error"` 出口 | **唯一错误出口不可达**：它只在 `except Exception` 里触发。伪 SQL 不抛异常、空集不抛异常、全 null 不抛异常 → **后端能表达"失败"的唯一通道在这条链路上一次都没被使用** |
| 8 | `fe:src/lib/agentApi.ts:60-77` `parseSseChunk` → `JSON.parse(payload) as AgentEvent` | 解析 SSE 帧 | 只做 JSON 语法校验，**不做载荷语义校验**。`as AgentEvent` 是编译期断言，运行时零校验 → 后端发了什么形状，前端就照单全收 |
| 9 | `fe:src/App.tsx:113-120`<br>`if (event.type === "result") { … status: "done", content: summarizeResult(event.data), result: event.data }` | 前端主分流 | **前端侧第一个失效点，也是任务书点名的核心缺陷**：`type==="result"` **无条件**按成功渲染。`status:"done"` 把消息标成成功、`result: event.data` 把可疑数据**当成正式结果存档** |
| 10 | `fe:src/App.tsx:122-128`<br>`status: "error", content: "这次查询没有成功。", error: event.message` | 红色错误框分支 | **永远走不到**：它是 `if/if` 之后的兜底 `return`，只有 `event.type !== "progress" && event.type !== "result"` 才会进入。后端对这三类失败**一次都没发过 `type:"error"`** |
| 11 | `fe:src/lib/format.ts:16-19`<br>`return data.length > 0 ? \`查询完成，共 ${data.length} 行结果。\` : "查询完成，结果为空。";` | 生成摘要文案 | **只数行数，不看内容**。1 行错误数据 → 「查询完成，共 1 行结果。」；0 行 → 「查询完成，结果为空。」。文案层面**没有任何一处**能区分"成功"与"失败" |
| 12 | `fe:src/components/ResultTable.tsx:38-40`<br>`if (columns.length === 0) { return null; }` | 空数组场景 | **整块表格直接消失**。用户屏幕上连"有 0 行"这个事实都看不到，只剩一句轻描淡写的「查询完成，结果为空。」 |
| 13 | `fe:src/components/ResultTable.tsx:23-26`<br>`if (value === null || value === undefined) return "-";` | 单元格渲染 | **全 null 列被渲染成一片 `-`**，与"该列恰好没数据"的合法情形**在视觉上完全无法区分** |
| 14 | `fe:src/components/ResultTable.tsx:9-13` `normalizeRows` + `:31-36` 列名聚合 | 行→表格 | 伪 SQL 的列名 `error_message` 被当成**普通业务列名**渲染成表头。一个"错误"被完整地"表格化"了 |
| 15 | `fe:src/components/MessageBubble.tsx:51-55`<br>`{message.error && ( <div className="…border-tomato/30 bg-tomato/10 …text-tomato">{message.error}</div> )}` | 红色错误提示框本体 | 红色框**存在且样式完备**，但 `message.error` 只在 `fe:src/App.tsx:126`（第 10 跳那个不可达分支）被赋值 → **`message.error` 恒为 `undefined` → 红框恒不渲染** |
| 16 | `fe:src/components/StepRail.tsx:63-65`<br>`return map[step]?.status ?? "pending";` | 流程图节点状态 | 后端把 11 个步骤全写成 `success`（`app/agent/nodes/*.py` 的 `writer({"type":"progress","step":step,"status":"success"})`，全仓 **13 处**，其中 `validate_sql.py` 占 2 处）→ **11 个绿勾**。另注：`app/agent/nodes/validate_sql.py:33` 与 `:39` **两个分支都写 `status:"success"`**，所以即使真的 EXPLAIN 失败，「校验SQL」节点也是绿勾 |
| 17 | `fe:src/App.tsx:62-65` `completedCount` → `:237` `<span>{completedCount}</span>`；`fe:src/App.tsx:283` `{isStreaming ? "运行中" : "就绪"}` | 侧栏计数 + 底栏状态 | 侧栏「完成 +1」：`message.status === "done"`（第 9 跳写死的）→ 失败计入完成数。底栏「就绪」：`isStreaming = Boolean(activeController)`（`:59`），`finally` 里 `setActiveController(null)`（`:158`）→ **只反映"连接是否还在"，不反映"查询成败"** |

---

## 2. 失效点清单（错误被吞掉的所有位置）

> 每条给出：位置 / 吞掉的是什么 / 改成不吞会怎样 / **修复的副作用风险**。

### FP-1 · `app/agent/nodes/run_sql.py:31` —— 执行结果无条件标成 `result`
- **吞掉什么**：后端**唯一**表达"这次查询结果不可信"的通道。执行器不区分"查到了真数据"与"查到了一句报错"。
- **改成不吞**：需要在 `run_sql` 内（或其后加节点）判断结果是否可疑，命中则发 `type:"error"` 或 `type:"result" + meta`。
- **副作用风险 🔴 高**：判据只能基于**结果内容**（如"单行且唯一列名像错误文案"），而列名每次都不同（`docker/fixed-backend-report.md:640` 实测 12/12 命中但列名在 `error_message` / `错误信息` / `message` / `查询状态` / `user_query` 之间漂移）→ **基于内容匹配的实现必然漏检**。更稳的判据是回看 `state["sql"]`（判"是否纯字面量 SELECT / 全 NULL 投影"），但那需要引入 SQL 解析器（`sqlparse`/`sqlglot`），是新增依赖。

### FP-2 · `app/agent/nodes/validate_sql.py:32-35` —— 校验层只有语法断言
- **吞掉什么**：伪 SQL 之所以能一路畅通，是因为校验层**只跑 `EXPLAIN`**（`dw_mysql_repository.py:48`）。`EXPLAIN` 结构上不可能发现"SELECT 一个字符串常量"是错的。
- **改成不吞**：在 `validate_sql` 内补语义断言（禁纯字面量 SELECT、禁 NULL 投影、结果列别名白名单）。
- **副作用风险 🔴 高**：断言一旦过严，**原本"蒙对"的题会开始报错**——`docker/fixed-backend-report.md:641` 记录「统计每个用户的支付方式占比」4/5 命中错误行、1/5 返回真实数据，说明当前有一批题**是靠运气蒙对的**。加断言会把这些题从"偶然成功"变成"确定失败"，需要用 `docs/OPTIMIZATION-BACKLOG.md:135-144` 的 10 题基线逐行比对回归。

### FP-3 · `app/agent/nodes/validate_sql.py:33` 与 `:39` —— 失败分支也写 `status:"success"`
- **吞掉什么**：发生过一次自我修正的事实。`docs/OPTIMIZATION-BACKLOG.md:192` 已把它列为已知问题。
- **改成不吞**：`:39` 改成 `status:"error"`。
- **副作用风险 🟡 中**：`fe:src/components/StepRail.tsx:63-65` 的 `statusFor` 只认 `running|success|error|pending`，改成 `error` 会让「校验SQL」节点变红 —— 但**最终查询是成功的**，红叉会误导用户以为整次查询失败。更合理是新增一个 `warning` 态，那要同时改 `fe:src/types/agent.ts:5` `ProgressStatus` 与 `fe:src/components/StepRail.tsx:9` `FlowStatus`（前端类型面变更）。

### FP-4 · `app/agent/nodes/recall_column.py:66` / `recall_metric.py:66` / `recall_value.py:66` —— 召回为空也写 `success`
- **吞掉什么**：**"检索跑完了"与"检索到东西了"的区别**。`ux-examples-catalog.md:187` 原文：「召回链路 3 路全部 `success`……『召回成功』只意味着*检索过程跑完了*，不代表*召回到了东西*」。
- **改成不吞**：召回结果为空时发 `status:"error"` 或新增 `status:"empty"`。
- **副作用风险 🟡 中**：会**误伤"问题本身就没命中"但其实可答的题**（例如 #5 `GMV by region in Q1 2024` 召回是成功的，只是库里没 2024 数据 —— 这题必须保持绿色）。判据必须是"召回为 0 **且**下游 SQL 退化"，单看召回为空会大面积误报。

### FP-5 · `app/services/query_service.py:67-70` —— 唯一 `type:"error"` 出口结构性不可达
- **吞掉什么**：所有**不抛异常**的失败形态。三类静默失败**全部**属于此类。
- **改成不吞**：不能靠"多发一个 error 事件"解决，因为根本没有异常。要么补异常（治不了伪 SQL），要么补语义判定（回到 FP-1/FP-2）。
- **副作用风险 🟡 中**：本跳本身是**正确的错误处理**（真异常如连接池耗尽确实能走到），不应改动；问题在它的**上游**没有东西能触发它。**这条是"症状位"不是"病灶位"，不要在这里做修复**。

### FP-6 · `fe:src/App.tsx:113-120` —— 前端只看事件类型，不看载荷内容
- **吞掉什么**：载荷里携带的失败语义。三类静默失败在协议层与真成功**完全同形**。
- **改成不吞**：在 `type==="result"` 分支里加内容判定（`error_message` 类键 / 全 null 列 / 空数组），命中则改走错误态。
- **副作用风险 🔴 高**：前端**没有任何后端语义的先验知识**（`fe:src/types/agent.ts:13-16` `ResultEvent` 只有 `{type, data: unknown}`）。若后端列名漂移（FP-1 已证），前端按固定键名匹配会漏检；而按"单行且值为长中文句子"这种启发式匹配**会误伤合法查询**（例如某次 `SELECT '春节' AS 活动名称` 返回 1 行）。**把失败识别责任放在前端是最脆的一档**。

### FP-7 · `fe:src/lib/format.ts:16-19` —— 摘要文案只看长度
- **吞掉什么**：结果内容的任何异常特征。文案是用户**唯一**会读的"系统自述"。
- **改成不吞**：让 `summarizeResult` 返回 `{text, degraded}` 之类，让调用方能拿到"降级"信号。
- **副作用风险 🟢 低**：纯函数改签名，调用点只有 `fe:src/App.tsx:117` 一处。但**只改文案不改渲染 = 仍然骗人**（文案说"这次查询没查到数据"，表格还是一片绿勾）。

### FP-8 · `fe:src/components/ResultTable.tsx:38-40` —— 空数组时整块表格 `return null`
- **吞掉什么**："查询确实执行了、返回 0 行"这个事实。
- **改成不吞**：渲染一个空态区块（"没有符合条件的数据" + 可能的原因提示），而不是让表格区域凭空消失。
- **副作用风险 🟢 低**：纯前端呈现。⚠️ 注意**不能**把空数组直接标成红色错误 —— `[]` 是**合法语义**（库里真的没这批数据，见 `ux-examples-catalog.md:119` #5），改成错误态会破坏正常场景。

### FP-9 · `fe:src/components/ResultTable.tsx:23-26` —— `null` 与"缺失"渲染成同一个 `-`
- **吞掉什么**："这一列的值是 NULL" 与 "这一列压根没召回到"的差别。
- **改成不吞**：区分 `null`（真 NULL 值）与"整列全 null 且列名是模型自造的"（降级）。
- **副作用风险 🟡 中**：`docker/mysql/dw.sql` 里 **NULL 出现 0 次**（`grep -c NULL dw.sql` → 0），所以当前数仓里"输出列出现 NULL"**几乎必然**来自伪 SQL 的 `NULL AS x` 投影或 LEFT JOIN 未命中 → 判据很有效。但这是**当前 schema 的巧合**，schema 一变（如引入可空字段）判据即失效 → 必须配合 schema 元数据，不能写死。

### FP-10 · `fe:src/App.tsx:62-65` + `:283` —— 侧栏计数与底栏状态与成败脱钩
- **吞掉什么**：全局层面的失败可见度。
- **改成不吞**：`completedCount` 区分"成功数"与"失败数"；底栏在失败时显示不同状态。
- **副作用风险 🟢 低**：纯前端。但 ⚠️ 底栏语义变更会影响用户的"系统是否正常"的直觉 —— 「就绪」目前只反映连接态，改动需明确新语义。

---

## 3. 三类静默失败 × 用户可见表现对照表

| 类别 | SSE 原文（实测） | 屏幕表现 | 用户会怎么理解 | 真实含义 |
|---|---|---|---|---|
| **空数组** | `{"type": "result", "data": []}`<br>（`ux-examples-catalog.md:119` #5） | `ResultTable` 因 `columns.length === 0` 直接 `return null`（`fe:src/components/ResultTable.tsx:38-40`）→ **屏幕上连表格都没有**，只剩一句「查询完成，结果为空。」（`fe:src/lib/format.ts:18`） | 「查完了，确实没数据」——甚至「界面是不是坏了」 | **这次查询其实是"合法但无数据"**（SQL 正确、库里没这批数据），**不是失败**。UI 把它渲染成"什么都没发生"，是**呈现缺陷**而非语义失败 |
| **整列 null** | `{"type": "result", "data": [{"customer_id": "C001", "支付方式": null, "支付方式占比": null}, … 共 20 行]}`<br>（`ux-examples-catalog.md:165` #7） | 一张**规规矩矩的 20 行 3 列表格**，两列每个格子都是 `formatCell(null)` 渲染的 `-`（`fe:src/components/ResultTable.tsx:24`），文案「查询完成，共 20 行结果。」 | 「查到了 20 个客户，但支付方式字段全是空的」 | **字段 `支付方式` 在元数据里根本不存在**（`ux-examples-catalog.md:187`）。LLM 编了 `NULL AS 支付方式, NULL AS 支付方式占比` 的伪 SQL，**"召回到 0 条字段"这个根因在 UI 上完全不可见**。这是**真失败被伪装成正常结果** |
| **error_message 行** | `{"type": "result", "data": [{"error_message": "无法生成SQL：未提供可用数据表信息，且查询内容不明确"}]}`<br>（`ux-examples-catalog.md:140` #6） | 一张**看起来完全正常的「查询结果」表格**，1 行 1 列，**表头就叫 `error_message`**，格子里是那句中文说明；文案「查询完成，共 1 行结果。」；**画面上没有任何红色** | 「查到了 1 条结果」——甚至可能读成「系统告诉我出错了」而误以为系统有在报错 | **LLM 编了伪 SQL** `SELECT '无法生成SQL：…' AS error_message;`，后端**真实执行**了它并如实返回了执行结果。后端自始至终**不知道**这是一次失败（无异常、无 `type:"error"`）。**这是三类里最危险的一类**：唯一"看起来像有报错"的提示，恰恰是数据本身 |

**三者共同点**（`ux-examples-catalog.md:297-301` 已记录，此处从代码复核）：
1. 后端**一次都没发过** `type=error`（`app/services/query_service.py:69` 的唯一错误出口未被触发）；
2. `message.status` 都是 `"done"`（`fe:src/App.tsx:116`），`message.error` 都是 `undefined` → 红色框（`fe:src/components/MessageBubble.tsx:51-55`）不渲染；
3. 流程图 11 个节点全绿（`fe:src/components/StepRail.tsx:63-65` + 后端 13 处 `status:"success"`）；
4. 侧栏「完成 +1」（`fe:src/App.tsx:63`）；
5. 文案统一是「查询完成…」（`fe:src/lib/format.ts:18`）。

**它们比真报错更危险**：真 `type=error` 会得到醒目的红框 + 「这次查询没有成功。」；
这三类反而给用户一个「一切正常」的错觉。

---

## 4. 可观测性缺口

> 判据：**运维或用户**能不能从 SSE / 日志 / UI 上看出这次查询其实失败了？以下 6 条「本该有但没有」。

| # | 本该有的信号 | 现状（代码证据） | 后果 |
|---|---|---|---|
| **OG-1** | **每步耗时** | SSE progress 事件只有 `{type, step, status}` —— `app/services/query_service.py:66` 把节点 `writer({...})` 的内容**原样序列化**，没有任何时间字段。全仓库 `grep -rn "elapsed\|duration\|耗时" --include=*.py app/` **零命中**（`docs/OPTIMIZATION-BACKLOG.md:81-89` 已列为 P2-1） | 用户为一张**必然全空的表**等了 **47.2 秒**（#7），UI 上**看不出任何异常**；运维只能人工比对 api 日志时间戳。**没有耗时 = 没有"这次异常慢"这个信号** |
| **OG-2** | **召回命中率 / 召回条数** | 召回节点的 progress 事件（`app/agent/nodes/recall_column.py:26/66`、`recall_metric.py:26/66`、`recall_value.py:26/64`）**不带任何召回条数**。日志侧同样残缺：`recall_metric.py:65` `logger.info(f"检索到指标信息：{list(metric_info_map.keys())}")` 与 `recall_value.py:63` 有打，但 **`recall_column.py` 成功路径上连一条日志都没有**（只 `:69` 有 error 日志） | **字段召回为 0 条时，日志里没有任何痕迹**（`app/agent/nodes/recall_column.py` 全文只有 `:16` import、`:69` error 两处 logger）。#7 的根因（字段召不到）在**日志和 SSE 里都不可见** |
| **OG-3** | **结果行是否全 null** | `app/agent/nodes/run_sql.py:29` `logger.info(f"SQL执行结果：{result}")` 把结果原样打进日志，**但不做任何 null 统计**；SSE 里更无此字段。`fe:src/components/ResultTable.tsx:23-26` 把 null 渲染成 `-`，**信息在渲染时就被抹平了** | 20 行里两列全 null 这种"形式完整、内容全空"的结果，在 SSE、日志、UI 三处**都退化成一个正常表格**。运维无法用"null 比例"做批量筛查 |
| **OG-4** | **`error_message` 键 / 伪 SQL 的存在性** | 后端 `grep -rn "error_message"` 在 `.py/.prompt/.yaml/.sql` **零命中** → 后端**根本不存在**这个概念（键名是 LLM 现场编的）。`docker/fixed-backend-report.md:640` 记录 12/12 命中但**列名在 `error_message`/`错误信息`/`message`/`查询状态`/`user_query` 间漂移**，`ux-examples-catalog.md:155-156` 记录**三次措辞各不相同** | **不存在稳定的失败特征可供检测**。既没有后端检测点，前端也无法按固定键名可靠匹配。这是本次审计最硬的约束：**任何"按 `error_message` 键名检测"的方案都只能覆盖部分 case** |
| **OG-5** | **request_id 贯穿到 SSE** | `app/main.py:25-28` 生成了 `request_id`，`app/core/log.py:19-28` 把它注入每条日志 —— 但 `app/services/query_service.py:66` 序列化 payload 时**不含 request_id**（`grep -n request_id app/services/query_service.py` 零命中） | 用户报障说"某次查询坏了"，运维**无法把这次提问和日志行对上**，只能靠时间戳人工对齐。多用户并发时基本不可用 |
| **OG-6** | **失败率指标 / 告警端点** | 全仓库唯一 APIRouter 是 `app/api/routers/query_router.py:19`（只有 `/api/query`）；`grep -rn "metrics\|prometheus\|/health" --include=*.py app/ main.py` **零命中** | 静默失败率**无法被采集**，也就无法告警。当前只能靠人肉看视频/截图发现 |

---

## 5. 修复方向对比

> 关键约束（贯穿所有方案）：**`[]` 是合法语义**（库里真的没这批数据，#5），**绝不能把"结果为空"改成失败态**。
> 三类必须分别对待：空数组 → **改呈现**；全 null 列 → **改判定**；error_message 行 → **改判定（且判据要能抗列名漂移）**。

### 方案 ① · 后端把这类结果改成真正的 `type:"error"`

| 维度 | 内容 |
|---|---|
| **改动面** | 后端 3 处：`app/agent/nodes/run_sql.py`（或新增语义判定节点）、`app/agent/nodes/validate_sql.py`、`app/agent/graph.py`（若加节点需改条件边）。可选：`app/agent/state.py` 加字段 |
| **兼容性** | ✅ **最好**。`type:"error"` 是协议里**已定义**的事件（`fe:src/types/agent.ts:18-21`），前端红色框分支（`fe:src/App.tsx:122-128` + `fe:src/components/MessageBubble.tsx:51-55`）**已经存在且样式完备**，改完立刻生效。**前端可以零改动** |
| **是否破坏"结果为空"正常场景** | ⚠️ **取决于判据**。判据必须**排除 `[]`**（`ux-examples-catalog.md:119` #5 是合法空集）。若判据写成"结果行数 < 1 即失败"→ **误伤 #5**；写成"结果为空但 SQL 退化（伪 SQL / NULL 投影）"才安全 |
| **核心风险** | 🔴 **判据从哪来**。伪 SQL 是"一次成功的执行"，没有异常可抓。判据必须来自 **`state["sql"]` 的静态特征**（是否纯字面量 SELECT / 是否含 `NULL AS` 投影 / 结果列是否全为 `NULL`），需要引入 SQL 解析（`sqlparse`/`sqlglot`）或写正则 → 新增依赖 + 新增误判面 |
| **需动文件** | `app/agent/nodes/run_sql.py`、`app/agent/nodes/validate_sql.py`、`app/agent/graph.py`、`app/agent/state.py`、（新增）SQL 语义校验模块 |

### 方案 ② · 后端加 `meta: {degraded: true}` 之类标记

| 维度 | 内容 |
|---|---|
| **改动面** | 后端 1-2 处：`app/agent/nodes/run_sql.py:31` 的 `writer({...})` 加 `meta` 字段、`app/services/query_service.py:66` 原样透传（**已透传，无需改**）。前端 3 处：`fe:src/types/agent.ts:13-16` 加 `meta`、`fe:src/App.tsx:113-120` 读 `meta.degraded` 决定渲染、`fe:src/components/ResultTable.tsx` 弱化样式 |
| **兼容性** | ✅ **向后兼容最好**。`meta` 是**增量字段**，老前端不读就忽略它 → 可灰度：先上后端标记，再上前端消费，两步解耦。⚠️ 但 `fe:src/lib/agentApi.ts:71` 是 `as AgentEvent` 强转，**新增字段在 TS 侧需要手动改 `ResultEvent` 类型**，否则类型面上"字段不存在"（运行时无碍，编译期会报） |
| **是否破坏"结果为空"正常场景** | ✅ **天然不破坏**。`meta.degraded` 是**正交维度**：`[]` 可以是 `degraded:false`（合法空集）也可以是 `degraded:true`（伪 SQL 返回空），两者由后端判据区分，不互相污染 |
| **核心风险** | 🟡 **只是"标记"，不解决问题**。后端不说人话 → 用户仍然看不懂。**必须配合前端消费**，否则等于没做。同时判据问题与方案 ① 完全相同（只是失败表达从"改类型"变成"加字段"） |
| **需动文件** | `app/agent/nodes/run_sql.py`、`fe:src/types/agent.ts`、`fe:src/App.tsx`、`fe:src/components/ResultTable.tsx`、（可选）`fe:src/lib/format.ts` |

### 方案 ③ · 前端在 `summarizeResult` / `ResultTable` 里识别并转错误态

| 维度 | 内容 |
|---|---|
| **改动面** | **纯前端 4 处**：`fe:src/lib/format.ts:16-19`、`fe:src/components/ResultTable.tsx:29-40`、`fe:src/App.tsx:113-120`、`fe:src/components/MessageBubble.tsx`（可选样式）。**后端零改动** |
| **兼容性** | ✅ **零部署风险**，改前端即可回滚。但 ⚠️ `fe:src/types/agent.ts:13-16` `ResultEvent.data` 是 `unknown` → 前端要读内容必须先做**运行时类型收窄**，得补 type guard |
| **是否破坏"结果为空"正常场景** | ⚠️ **需要精确设计**。空数组必须走"空态"而非"错误态"（#5 合法）。若规则写成"数组长度 < 1 → 错误"→ **误伤 #5** |
| **核心风险** | 🔴 **判据最不可靠**。前端**没有后端语义先验**（`ResultEvent.data: unknown`）。按固定键名 `error_message` 匹配 → 漏检（列名漂移已实测，`docker/fixed-backend-report.md:640`）；按"单行 + 长中文句子"启发式 → **误伤合法查询**（如 `SELECT '春节' AS 活动名称`） |
| **需动文件** | `fe:src/lib/format.ts`、`fe:src/components/ResultTable.tsx`、`fe:src/App.tsx`、`fe:src/types/agent.ts`、（可选）`fe:src/components/MessageBubble.tsx` |

### 方案 ④ · 分层治本（推荐组合）

把"识别失败"的责任放回**它该在的地方**（后端语义层），把"表达失败"的责任放回前端，各司其职：

| 层 | 动作 | 落地位置 | 关键约束 |
|---|---|---|---|
| **提示词层** | 建立"上下文不足必须拒答"的显式契约（如固定标记 `__NO_ANSWER__:<原因>`）+ 禁"常量/NULL 作为结果列" | `prompts/generate_sql.prompt`、`prompts/correct_sql.prompt` | 🔴 **必须与代码层同批落地**：只改提示词 → 标记会被 `EXPLAIN` 判为语法错误 → 进 `correct_sql` → 再被拒答 → 死循环（`docs/audit-prompts.md:224` 已警告 R3 同款风险） |
| **代码层** | 识别拒答标记 → 走**显式失败分支**（`state["error"]` / 新增 `state["no_answer"]`）→ 发 `type:"error"`；并在 `validate_sql` 补**语义断言**（禁纯字面量 SELECT、禁 NULL 投影、结果列别名 ⊆ `alias` 白名单） | `app/agent/nodes/generate_sql.py`、`app/agent/nodes/correct_sql.py`、`app/agent/nodes/validate_sql.py`、`app/agent/graph.py:83-87`、`app/agent/state.py` | 🔴 **高**：接口面变更（state + graph），且**原本"蒙对"的题会开始报错**（`docker/fixed-backend-report.md:641`：4/5 命中错误行、1/5 真成功）。必须用 `docs/OPTIMIZATION-BACKLOG.md:135-144` 的 10 题基线逐行回归 |
| **前端层** | 消费 `type:"error"`（**已存在**，零改动）+ **新增**"空数组 → 空态区块"（区别于错误）+ **新增**"全 null 列 → 降级提示" | `fe:src/components/ResultTable.tsx:38-40`（空态）、`fe:src/lib/format.ts:18`（空文案）、`fe:src/App.tsx:113-120`（降级） | 🟢 低。注意 `[]` 走**空态**（不是错误） |
| **观测层**（可并行） | 补 `elapsed_ms`（OG-1）、召回条数（OG-2）、结果 null 统计（OG-3）、SSE 带 request_id（OG-5）、`/metrics`（OG-6） | `app/agent/nodes/*.py` 埋点 + `app/services/query_service.py` 透传 + `fe:src/types/agent.ts` + `fe:src/components/StepRail.tsx` | 🟢 低，**纯增量、向后兼容**，且是验证上面所有改动的"眼睛"（`docs/OPTIMIZATION-BACKLOG.md:88` 原话） |

### 横向对比

| | ① 后端改 error | ② 后端加 meta | ③ 前端识别 | ④ 分层治本 |
|---|---|---|---|---|
| 改动面 | 后端 3-4 文件 | 后端 1 + 前端 3 | 前端 4 | 后端 5-6 + 提示词 2 + 前端 3 + 观测多处 |
| 兼容性 | ✅ 前端零改动 | ✅ 可灰度 | ✅ 可独立发布 | 🟡 需协调批次 |
| 抗列名漂移 | ✅（若判据基于 SQL 文本） | ✅（同上） | ❌ | ✅ |
| 不误伤 `[]` | ⚠️ 需精确判据 | ✅ 天然隔离 | ⚠️ 需精确判据 | ✅ |
| 前端是否要改 | ❌ 不用 | ✅ 要 | ✅ 要 | ✅ 要 |
| 副作用风险 | 🔴 | 🟡 | 🔴 | 🔴 |
| **推荐度** | 中（治标） | 中（治标但可灰度） | 低（最脆） | **高（唯一治本）** |

**推荐落单**：**④ 的代码层 + 方案 ② 的表达方式**（用 `meta.degraded` 而非改 `type`）先上，
因为 `meta` 可灰度且**天然不误伤 `[]`**；**提示词层的拒答契约必须与代码层同批**；
**方案 ③ 只作为前端的额外兜底**，不作为主判据。

---

## 6. 待验证清单（本轮未实测，约束禁止打真实 LLM）

- **V1 · `state["sql"]` 静态特征能否可靠区分伪 SQL**（纯字面量 SELECT / 全 NULL 投影）
  → **推断**：可区分。**验证方法**：把 `ux-examples-catalog.md` 记录的 10 题 SQL 原文喂给判定器，
  期望 #6/#7 被判伪、#1-#5/#8-#10 被判真；**不需打 LLM**，纯离线单测。
- **V2 · 语义断言上线后原 10 题的结果变化**
  → **推断**：会有原本"蒙对"的题转为显式失败（依据 `docker/fixed-backend-report.md:641` 的 4/5 vs 1/5 分布）。
  **验证方法**：改后跑 `docs/OPTIMIZATION-BACKLOG.md:135-144` 的 10 题基线逐行比对（需真实 LLM）。
- **V3 · `meta.degraded` 的端到端消费**
  → **推断**：`fe:src/lib/agentApi.ts:71` 的 `as AgentEvent` 强转不影响运行时透传，但**编译期**需改 `fe:src/types/agent.ts:13-16`。
  **验证方法**：`npm run build`（`tsc` 类型检查）即可确证，不需打 LLM。
- **V4 · "全 null 列"判据在真实数据上的误报率**
  → **推断**：当前 `docker/mysql/dw.sql` 里 `NULL` 出现 **0 次**，故判据几乎无误报；
  **这是 schema 巧合，schema 一变即失效**。**验证方法**：在引入可空字段后重跑判据。

---

## 7. 审计边界声明

- **只读**：本轮**未修改**任何 `app/`、`prompts/`、`conf/`、前端 `src/` 文件；**唯一新建文件是本文件** `docs/audit-silent-failure.md`。
- **未执行**：`docker`、`sudo`、**未请求 `POST /api/query`**（会打真实 LLM）、未运行 `docs/hotpath_probe.py`。
- **curl 配额**：使用 **2 次只读 curl**，均未打 LLM、未改动任何状态：
  `GET http://127.0.0.1:8000/docs` → `HTTP=200`（后端存活，接口在线）；
  `GET http://127.0.0.1:9200/_cat/indices/value_index?v` → `value_index` 存在，`docs.count=75`。
- **与既有审计的关系**：
  - `docs/audit-prompts.md` 已覆盖**提示词契约层**（占位符、隐式协议 P1-P20、R1-R10），
    其中 §3.2 B-1/B-2 已识别伪 SQL 形态与 `generate_sql.py:65 → validate_sql.py:32 → graph.py:85 → run_sql.py:31 → App.tsx:113-120` 的链路骨架。
    **本报告不重复提示词层结论**，只做**链路完整追踪 + 失效点枚举 + 可观测性缺口 + 修复方向对比**，
    并在 §0 **修正了任务书「后端把异常包成 error_message 行」的表述**（后端零命中该字符串，伪 SQL 由 LLM 生成）。
  - `docs/audit-frontend-contract.md` 已覆盖**前后端字段契约层**（其 §3.2 与本报告 §3 的 `error_message` 行同源结论一致，
    并同样记录了「后端代码零命中 `error_message`、该列名是 LLM 每次现场编的」这一事实）。
    **本报告在其之上新增**的是：完整 17 跳链路表、10 条失效点（含每条的修复副作用风险）、
    6 条可观测性缺口、4 种修复方向的横向对比。
- **未覆盖**：`app/repositories/**` 内部实现细节（ES/Qdrant 检索质量）、`app/clients/**` 生命周期管理、
  `docker/**` 部署侧配置、`app/services/meta_knowledge_service.py` 元数据构建链路。
  提示词层细节请见 `docs/audit-prompts.md`；字段契约细节请见 `docs/audit-frontend-contract.md`。
