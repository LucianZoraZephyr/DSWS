# 元数据 ↔ 数仓 ↔ 实体 ↔ 提示词 口径一致性审计

> 审计对象：`code/shopkeeper-agent`（电商问数 Agent）｜审计日期：2026-10-20｜性质：**只读审计**
> 未修改任何源码/配置/元数据/SQL；未执行 `docker`/`sudo`/任何 SQL；未调用 `/api/query`（不打真实 LLM）；
> 仅用 **2 次只读 `curl`**（`:9200/_cat/indices/value_index` 与 `:9200/value_index/_search` 聚合），
> 其余数据全部靠**静态读取 SQL 文件**统计得出。

## 0. 结论摘要（按严重度）

| # | 结论 | 严重度 | 关键证据 |
|---|------|--------|----------|
| C1 | **AOV 自相矛盾**：描述写"成交金额平均值"，依赖列却是 `fact_order.order_quantity`（件数） | 致命 | `conf/meta_config.yaml:173,175` |
| C2 | **"城市"无处可去**：数仓**无 city 列**，元数据也未声明粒度只到省，LLM 只能拿 `province` 顶上并起别名"城市" | 致命 | `docker/mysql/dw.sql:9-15`；`docker/fixed-backend-report.md:666-671` |
| C3 | **数据可用范围全链路零声明**：元数据/提示词/实体/ORM 均无 min-max date 与枚举全集，越界查询返回空数组并报"成功" | 致命 | §3 |
| C4 | **字段描述过薄**：`"订单金额。"`/`"月份。"`/`"季度。"` 不足以让 LLM 选对列或写对过滤条件 | 高 | `conf/meta_config.yaml:110,116,162` |
| C5 | **同一语义两套写法并存**：日期既写 `date_id BETWEEN` 又应写 `JOIN dim_date`，元数据未指定标准写法 | 高 | `logs/app.log:27,30,33` |
| C6 | **`examples` 截断到 10 条且无 ORDER BY**，LLM 无法据此推断覆盖范围 | 中 | `app/repositories/mysql/dw/dw_mysql_repository.py:31` |
| C7 | **别名互撞**：`dim_region.region_id` 与 `fact_order.region_id` 的 alias 逐字相同 | 中 | `conf/meta_config.yaml:9` vs `:151` |
| C8 | **元数据库 4 张表无 schema 契约校验**，`alias`/`examples` 用 JSON 存列表 | 低 | `docker/mysql/meta.sql:25,27`；`app/models/column_info.py:30,32` |

---

## 1. 四方对照表

> **meta_config.yaml**（人工元数据）/ **数仓 DDL**（`docker/mysql/dw.sql`、`meta.sql`）/ **entity**（`app/entities/*.py`）/
> **mapper·ORM**（`app/repositories/mysql/meta/mappers/*.py`、`app/models/*.py`）/
> **提示词里怎么说**（LLM 实际所见文本，来源 `app/agent/nodes/generate_sql.py:52-57` 的 `yaml.dump`）。

| # | 概念 | meta_config.yaml | 数仓 DDL | entity | mapper/ORM | 提示词里怎么说 | 一致？ | 风险 |
|---|------|------------------|----------|--------|------------|----------------|--------|------|
| 1 | 表清单（5 张 dw 表） | `dim_region`(2) `dim_customer`(30) `dim_product`(58) `dim_date`(86) `fact_order`(120) | `dw.sql:9,27,60,88,192` 同名同数 | `TableInfo`(`table_info.py:12-18`) 只存 `id/name/role/description`，**不含列清单** | `table_info_mapper.py:18-29`；ORM `table_info.py:74-84` | `generate_sql.prompt:6` 注入 `table_infos` | ✅ | 列级一致性完全依赖 YAML 人工维护 |
| 2 | `dim_region.region_id` | `:6-10` `primary_key`，「地区唯一标识。」alias `[地区ID, 区域ID]` | `dw.sql:11` `VARCHAR(20) PRIMARY KEY` | `ColumnInfo`(`column_info.py:13-23`) 含 type/role/examples/alias | `column_info_mapper.py:20-29`；ORM `column_info.py:22-33` | `ColumnInfoState`(`state.py:27-36`) | ✅ | alias 与第 14 行完全相同 |
| 3 | **`province`（被当"城市"）** | `:12-16`「订单所属的省份名称。」alias `[省份, 省, 所在省份]` | `dw.sql:12` `VARCHAR(50)`，**全库无 city 列** | 同上 | 同上 | 原样进提示词(`merge_retrieved_info.py:112-122`) | ❌ 粒度缺失 | **致命**：实测生成 `SELECT r.province AS 城市`（`fixed-backend-report.md:668-669`） |
| 4 | `dim_region.region_name` | `:18-22`「订单所属的大区名称，如华东、华南等。」alias `[地区, 区域, 大区]` | `dw.sql:13`，实际 5 值：华东/华南/华北/西南/华中 | 同上 | 同上 | 同上 | ⚠️ 与第 2/14 行 alias 同域 | "区域"既指 id 又指 name |
| 5 | `dim_region.country` | `:24-28`「地区所属国家名称。」 | `dw.sql:14`，值只有 `中国` | 同上 | 同上 | 同上 | ✅ | 值域恒定，无信息量 |
| 6 | `dim_customer.member_level` | `:52-56`「客户会员等级。」alias `[会员等级, 用户等级]` | `dw.sql:32`，4 值：黄金/白银/青铜/铂金 | 同上 | 同上 | 同上 + ES 取值(`value_es_repository.py:20`) | ⚠️ 无数值枚举 | 用户问"钻石会员"时 LLM 写出恒空条件 |
| 7 | `dim_product.category` | `:74-78`「商品所属品类。」alias `[商品类别, 品类, 分类]` | `dw.sql:64`，6 值：手机数码/家用电器/鞋靴/服饰/食品饮料/休闲零食 | 同上 | 同上 | 同上 | ⚠️ 无数值枚举 | 同上 |
| 8 | `dim_product.brand` | `:80-84`「商品品牌名称。」 | `dw.sql:65`，**15 值** | 同上 | 同上 | 同上 | ⚠️ | 15 值 > examples 上限 10，提示词里只出现 10 个 |
| 9 | **商品单价（不存在）** | **无此列** | `dw.sql:60-66` `dim_product` 仅 4 列，**无 price 列** | — | — | LLM 看不到任何单价列 | ❌ | `AOV.alias` 却含「平均单价」(`:176`) → 指向物理上不可算的口径 |
| 10 | `dim_date.date_id` | `:90-94`「日期唯一标识，格式 yyyyMMdd。」 | `dw.sql:90` `INT PRIMARY KEY`，90 行 20250101–20250331 | 同上 | 同上 | 同上 | ✅ | 但 `fact_order.date_id`（第 11 行）**没有**这条格式说明 |
| 11 | `fact_order.date_id` | `:142-146`「关联时间维度的外键。」alias `[日期, 下单日期]` | `dw.sql:197` `INT` | 同上 | 同上 | 同上 | ❌ 格式缺失 | 描述只说"外键"，未说 yyyyMMdd；`role: foreign_key` 暗示要 join，实测未 join（`logs/app.log:33`） |
| 12 | `dim_date.quarter` | `:102-106`「季度。」`sync: true` | `dw.sql:92` `VARCHAR(2)`，取值形如 `'Q1'`(`dw.sql:98-187`) | 同上 | 同上 | 同上 + ES 索引了唯一值 `Q1` | ❌ 取值格式缺失 | 未说带 Q 前缀，LLM 可能写 `quarter = 1`/`'第一季度'` → 恒空 |
| 13 | `dim_date.year/month/day` | `:96-100`「年份。」/`:108-112`「月份。」/`:114-118`「日。」，`sync: false` | `dw.sql:91-94` 均 INT；year=2025、month∈{1,2,3} | 同上 | 同上 | 同上 | ❌ 枚举缺失 | 未说 month 是 1–12 数字；`sync:false` ⇒ ES 里无月份值 |
| 14 | `fact_order.region_id` | `:148-152`「关联地区维度的外键。」alias `[地区ID, 区域ID]` | `dw.sql:198` `VARCHAR(20)` | 同上 | 同上 | 同上 | ⚠️ alias 与第 2 行逐字相同 | "区域"歧义：JOIN 出 name 还是直接过滤 id |
| 15 | `fact_order.order_amount` | `:160-164` `measure`「订单金额。」alias `[销售额, 订单金额, 收入]` | `dw.sql:200` `FLOAT`；115 行合计 **279159.5**，范围 30–9499 | 同上 | 同上 | 同上 | ⚠️ 未说整单粒度 | 未说"含件数、非单价"，也未说"不含运费/退款"（库中无此列） |
| 16 | `fact_order.order_quantity` | `:154-158` `measure`「订单中商品的购买数量。」alias `[销量, 购买数量, 件数]` | `dw.sql:199` `INT`；合计 622，单行 1–30 | 同上 | 同上 | 同上 | ⚠️ 缺"订单数"口径 | **"订单量"不属于任何列 alias**（`order_id.alias` 仅 `[订单ID]`,`:127`）→ 易写成 `SUM(qty)`，偏差 5.41 倍 |
| 17 | `fact_order.order_id` | `:124-128` `primary_key`「订单唯一标识。」 | `dw.sql:194` `VARCHAR(30) PRIMARY KEY` → **一行一单**成立 | 同上 | 同上 | 同上 | ⚠️ 描述未写"一行一单" | LLM 无法判断"订单量"该 `COUNT(*)` 还是 `COUNT(DISTINCT order_id)` |
| 18 | **指标 GMV** | `:167-171`「…所有订单的成交金额总和。」`relevant_columns:[fact_order.order_amount]` | 实测 `SUM(order_amount)=279159.5`，与 `logs/app.log:35` 五大区合计一致 | `MetricInfo`(`metric_info.py:12-20`) 带 relevant_columns | `metric_info_mapper.py:19-30`；ORM `metric_info.py:48-61` | `generate_sql.prompt:9` 注入；`:19` 要求"严格遵循其业务口径" | ✅ | 但未声明是否含退款/运费（库中无此列） |
| 19 | **指标 AOV** | `:172-176`「…成交金额平均值。」**`relevant_columns:[fact_order.order_quantity]`** | 真值 `SUM(amount)/COUNT(orders)` = 279159.5/115 = **2427.47** | 同上 | 同上 | 同上 | ❌ 严重不一致 | 描述"金额平均"、依赖"件数"：三个口径 → **2427.47 / 448.81 / 5.41** |
| 20 | **示例值 `examples`** | 无（Service 生成） | 真实数据 | `ColumnInfo.examples`(`column_info.py:20`) | `column_info_mapper.py:25`；ORM `column_info.py:30`(JSON) | `ColumnInfoState.examples`(`state.py:34`) | ⚠️ 截断 | `dw_mysql_repository.py:31` `select distinct … limit N` **无 ORDER BY**、N=10 → `fact_order.date_id` 只给 **10/90** 个随机日期，`brand` 只给 **10/15** |
| 21 | **元数据库 4 张表** | — | `meta.sql:8-14` table_info、`:19-29` column_info、`:32-39` metric_info、`:43-48` column_metric | `table_info.py`/`column_info.py`/`metric_info.py`/`column_metric.py`/`value_info.py` | 4 mapper + 4 ORM model | **不进提示词** | ✅ 结构一致 | `alias`/`examples` 为 JSON 列表，ORM 声明 `dict \| list \| None`(`models/column_info.py:30,32`) → **无 schema 校验** |
| 22 | **别名 alias 体系** | 逐列维护 | — | `ColumnInfo.alias`/`MetricInfo.alias` | 同上 | 进提示词，且每个 alias 单独生成 Qdrant 向量点(`meta_knowledge_service.py:124-131`) | ❌ 互撞 | `:9` 与 `:151` 逐字相同；`:21` 的「地区/区域」与之同域 |
| 23 | **数据可用范围** | **完全缺失** | 真实存在（§3.1） | 无 | 无 | **无槽位**（`generate_sql.prompt:6,9,12,15` 只有 table_infos/metric_infos/date_info/db_info） | ❌ 完全不一致 | **致命**：LLM 无从知道"只有 2025 Q1" |
| 24 | **`date_info`（"当前时间"）** | 无 | — | `DateInfoState`(`state.py:48-53`) | — | `generate_sql.prompt:12` | ⚠️ 语义陷阱 | `add_extra_context.py:27-31` 用**服务器当天**算季度：实测 `{'date':'2026-10-19','quarter':'Q4'}`(`logs/app.log:32`)，而数据只有 2025 Q1 → "本季度"必空 |

---

## 2. "LLM 看不见真相"清单

LLM 只看到提示词里喂进去的文本（`app/agent/nodes/generate_sql.py:52-57` 把 `table_infos`/`metric_infos`/`date_info`/`db_info`
全部 `yaml.dump` 后拼进去）。**它看不到 `dw.sql`，更看不到数据边界。** 下表逐列引用元数据描述原文。

### 例子 1 · `dim_region.province` → "城市"（严重）
元数据原文 `conf/meta_config.yaml:12-16`：`description: 订单所属的省份名称。` / `alias: [省份, 省, 所在省份]`。
真实 schema `docker/mysql/dw.sql:9-15`：`dim_region(region_id, province, region_name, country)`，**没有 city 列**，粒度只到省。
**够不够？不够。** 描述既没说"本表无城市粒度"，也没说"用户问'城市'时按省回答"；alias 里也匹配不到"城市"字样，
LLM 只能硬套 province，并按 `prompts/generate_sql.prompt:23`「别名优先使用用户问题中的业务名称」起成 `AS 城市`。
实测坐实：`docker/fixed-backend-report.md:666-671`「统计每个城市 2025 年 3 月的订单量」生成的 SQL 是 `SELECT r.province AS 城市`。
**验证方法**：在 province 描述里加"只到省级、无城市粒度"后重放同一问题，观察 SQL 是否改用 `region_name` 或明确改写别名。

### 例子 2 · `fact_order.order_quantity` → "订单量"（严重）
元数据原文 `conf/meta_config.yaml:154-158`：`description: 订单中商品的购买数量。` / `alias: [销量, 购买数量, 件数]`。
真实 `docker/mysql/dw.sql:199` `order_quantity INT`，115 单合计 622 件（单行 1–30 件）。
**够不够？不够。** 描述与别名都指向"**件数**"，而**没有任何一列的 alias 命中"订单量"**（`order_id.alias` 只有 `[订单ID]`,`:127`）。
正确口径应为 `COUNT(*)`（`dw.sql:194` 主键保证一行一单），LLM 最可能生成 `SUM(order_quantity) AS 订单量` → **偏大 5.41 倍**（622/115）。
**验证方法**：静态核算 622/115=5.41；改描述后重放"2025 年 3 月的订单量"，核对 SQL 是否为 `COUNT(*)`，并与 `dw.sql` 中 202503 的 42 单（qty=322）比对。

### 例子 3 · `fact_order.date_id` → 日期过滤写法（严重）
元数据原文 `conf/meta_config.yaml:142-146`：`description: 关联时间维度的外键。` / `alias: [日期, 下单日期]`。
真实 `docker/mysql/dw.sql:197` `date_id INT`（同为 yyyyMMdd 整数）。
**够不够？不够。** 描述**只字未提格式**；偏偏同概念的 `dim_date.date_id`(`:92`) 写了「格式 yyyyMMdd」——同一概念两处描述强度不一致。
同时 `role: foreign_key` 暗示"必须 join `dim_date`"，实测却没 join：`logs/app.log:27` 合并阶段召回了 `dim_date`，
`logs/app.log:30` 过滤阶段又把它裁掉，最终 `logs/app.log:33` 生成 `WHERE f.date_id BETWEEN 20250101 AND 20250331`。
**结论**：同一时间口径两种写法并存（`date_id BETWEEN` 与 `JOIN dim_date + quarter/month`），元数据未指定标准写法。
**验证方法**：同一数据上分别跑两种写法比聚合值；再往 `dim_date` 补 2025-Q2 后复跑，看两种写法是否仍给出同一"Q1"口径。

### 例子 4 · `dim_date.quarter` → 季度取值格式（高）
元数据原文 `conf/meta_config.yaml:102-106`：`description: 季度。` / `alias: [季度]` / `sync: true`。
真实 `docker/mysql/dw.sql:92` `quarter VARCHAR(2)`，90 行全为 `'Q1'`。
**够不够？不够。** 两个字什么都没说。LLM 可能写 `quarter = 1` / `'第一季度'` / `'1'` → 恒空；而用户高频词就是"第一季度"
（`logs/app.log:14` 关键词抽取确实抽到了「第一季度」）。补充风险：`sync:true` 让 `'Q1'` 进了 ES，但**值召回经常失败**——
`logs/app.log:26`「检索到字段取值：[]」、`logs/app.log:38` 同样为空（尽管「铂金」确实在 `value_index` 里，见 §3.2），
指望"取值召回来告诉 LLM 合法枚举"不可靠。

### 例子 5 · `fact_order.order_amount` → 金额粒度（高）
元数据原文 `conf/meta_config.yaml:160-164`：`description: 订单金额。` / `alias: [销售额, 订单金额, 收入]`。
真实 `docker/mysql/dw.sql:200` `order_amount FLOAT`。静态核算：14/15 个商品满足 `order_amount = order_quantity × 恒定单价`
（`P010` 恒 25 元：`dw.sql:206` 5 件 125 元、`dw.sql:235` 4 件 100 元）；**例外 `P008`**：`dw.sql:211` 2 件 299 元（149.5/件）
vs `dw.sql:226` 1 件 199 元，**同一商品两个单价**。
**够不够？不够。** 未说"整单金额（已含件数）"；库中**无 price 列**可交叉验证，故 `AOV.alias` 的「平均单价」(`:176`) 不可靠；
`P008` 单价不自洽又说明"金额÷件数=单价"对它不成立。

### 例子 6 · `dim_date.month`/`year` → 数字枚举（中高）
元数据原文 `conf/meta_config.yaml:108-112`：`description: 月份。` / `alias: [月, 月份]` / `sync: false`；真实 `dw.sql:93` `month INT`，值 1/2/3。
**够不够？不够。** 未说 month 是 1–12 **数字**而非月份名；且 `sync:false` ⇒ ES 取值索引里**没有** month 的值（实测 §3.2 只含 10 个文本型维度列），
提示词里的 `examples` 也只是 `limit 10` 抽样。

---

## 3. 数据覆盖范围审计

### 3.1 真实数据边界（静态读取 `docker/mysql/dw.sql` 统计）

| 维度 | 实际取值范围 | 证据 |
|------|--------------|------|
| **时间范围** | `date_id` ∈ [20250101, 20250331]，**90 个不同日期**；事实表 **115 单** | `dw.sql:97-187`（dim_date 90 行）、`dw.sql:203-318`（fact_order 115 行） |
| **年/季** | `year`={2025}；`quarter`={`Q1`} | `dw.sql:98-187` |
| **月份分布** | 202501=40 单、202502=33 单、202503=42 单 | 静态聚合 `dw.sql:203-318` |
| **金额/销量** | `SUM(order_amount)`=**279159.5**；`SUM(order_quantity)`=**622**；单行金额 30–9499、单行件数 1–30 | 静态聚合，与 `logs/app.log:35` 五大区合计一致 |
| **区域** | dim_region 6 行；province 6 值（广东省/浙江省/四川省/北京市/上海市/湖北省）；region_name 5 值（华东/华南/华北/西南/华中）；country 1 值（中国） | `dw.sql:17-23` |
| **省份 GMV** | 广东省 70202.0、上海市 60210.0、浙江省 47163.0、北京市 41099.5、四川省 31528.0、湖北省 28957.0 | 静态聚合 `dw.sql:203-318` |
| **品类** | dim_product 15 行；category **6 值**（手机数码/家用电器/鞋靴/服饰/食品饮料/休闲零食）；brand **15 值** | `dw.sql:68-83` |
| **会员等级** | dim_customer 20 行；member_level **4 值**（黄金/白银/青铜/铂金）；gender 2 值 | `dw.sql:35-55` |
| **客户/商品** | 20 个 customer_id、15 个 product_id | 同上 |

### 3.2 LLM 能拿到的"取值"真相（实测 ES）
`curl :9200/_cat/indices/value_index?v` → `docs.count = 75`；`curl :9200/value_index/_search`（terms 聚合 `column_id`）：

```
dim_customer.customer_name 20   dim_product.brand 15   dim_product.product_name 15
dim_product.category 6          dim_region.province 6   dim_region.region_name 5
dim_customer.member_level 4     dim_customer.gender 2   dim_date.quarter 1
dim_region.country 1
```
→ **ES 取值索引里没有任何日期值**：`fact_order.date_id`(`:146`)、`dim_date.date_id`(`:94`)、`year`(`:100`)、`month`(`:112`)、
`day`(`:118`) 的 `sync` 全为 `false`，只有 `quarter`(`:106`) 为 `true`。
→ **LLM 不可能从取值召回得知数据只到 2025-03-31。**

### 3.3 元数据/提示词里有没有任何范围声明？——**没有，一处都没有**
- `conf/meta_config.yaml` 全文 176 行**没有任何** `min_date`/`max_date`/`date_range`/`data_scope` 字段；
  `app/conf/meta_config.py:13-61` 的四个 dataclass **连承载它的属性都没有**（`MetaConfig` 只有 `tables`、`metrics`，`:60-61`）。
- `prompts/generate_sql.prompt` 占位符只有 4 个：`{table_infos}`(6) `{metric_infos}`(9) `{date_info}`(12) `{db_info}`(15) —— **无数据范围槽位**。
- `app/agent/nodes/add_extra_context.py:27-31` 补的 `date_info` 是**服务器当天**，实测 `{'date':'2026-10-19','quarter':'Q4'}`
  （`logs/app.log:32`）——这是"现在"不是"数据覆盖到哪"，反而诱导 LLM 把"本季度"理解成 2026 Q4。

### 3.4 越界提问时系统的实际表现（引用实测）
链路：SQL 正常生成 → `EXPLAIN` 通过（`validate_sql.py:68`，实测 `logs/app.log:34`「SQL语法正确」）→ 执行成功返回 `[]`
（`run_sql.py:28-31` 写 `{"type":"progress","status":"success"}` 与 `{"type":"result","data":[]}`）。
前端 `shopkeeper-agent-frontend/src/components/ResultTable.tsx:38-40`：
```tsx
if (columns.length === 0) { return null; }
```
→ 空数组没有列 → **整个结果表返回 null，界面什么都不渲染**（连"0 行"都没有），而步骤条 `StepRail.tsx:19-30` 的全部节点仍是绿色。
实测（`docker/fixed-backend-report.md:643`）：「`GMV by region in Q1 2024` | 3/4 | 3 次空集 `[]`，1 次 `{"GMV": null}`」。
**即：用户问了一个数据完全覆盖不到的时间段，系统返回"成功 + 空白页"，没有任何一处告诉用户"数据只到 2025-03-31"**；
且 1/4 返回 `{"GMV": null}`（`SUM()` 空集 → NULL）与空集 `[]` **两种形态随机出现，同一问题两次跑出两种结果**（同报告 `:634-643` 记录了 LLM 非确定性）。
**推断**（验证方法）：因系统不存在"数据范围声明"层（§3.3），LLM 只能把 `2024` 原样翻成 `date_id BETWEEN 20240101 AND 20240331`
或 `JOIN dim_date WHERE d.year=2024`，两者在当前数据上必然为空；静态核对 `dw.sql:97-187` 的 `dim_date` 不含任何 2024 行即可复现。

---

## 4. 口径歧义清单

**D1 · AOV 的定义与依赖列互相矛盾（致命）**　`conf/meta_config.yaml:172-176` 描述「…成交金额平均值。」，
`relevant_columns` 却指向 `fact_order.order_quantity`（**件数**）。当前数据上三种算法的结果：
`SUM(amount)/COUNT(order_id)`=**2427.47**（描述口径）；`AVG(order_quantity)`=**5.41**（依赖列口径）；
`SUM(amount)/SUM(order_quantity)`=**448.81**（混合口径）。且 `alias:[平均单价, 平均订单金额]`(`:176`) 里的「平均单价」既不等于 448.81 也不等于 5.41
（库中无单价列，见对照表第 9 行）。**为什么危险**：`merge_retrieved_info.py:56-64` 把 `relevant_columns` 当"必须补进上下文的字段"，
`filter_metric.py:50-52` 一旦留下 AOV，LLM 拿到的就是"金额平均值 + 依赖件数列"的矛盾组合，必然二选一猜错。
实测 `logs/app.log:37` 召回阶段确实同时召回 `['AOV','GMV']`，只是被 `logs/app.log:42` 裁成 `['GMV']` 才没出事 —— **这是运气，不是设计**。

**D2 · GMV 是否含退款/运费/未支付订单（高）**　`:168`「表示所有订单的成交金额总和。」真实 `dw.sql:192-201` 的 `fact_order`
**只有** `order_quantity` 与 `order_amount` 两个度量列，**没有** `refund_amount`/`freight`/`status`/`pay_status`。
所以"含不含退款"在当前模型里不是选择题，而是无路可走 —— 但描述从未声明；"GMV"在行业语境下通常指未扣退款的口径。

**D3 · "季度"的定义与取值格式（高）**　`:104`「季度。」没说自然季度、没说取值是 `'Q1'` 字符串；真实 `dw.sql:92` 为 `VARCHAR(2)`、
值形如 `'Q1'`。附带冲突：`date_info.quarter` 是**当前**季度且同为 `'Q4'`（`logs/app.log:32`），数据里只有 `'Q1'` ——
同一个词在提示词里同时指"当前季度(2026Q4)"与"数据季度(2025Q1)"，**语义冲突**。附带风险：`'Q1'` 只在 ES 有 1 条且值召回常失败（`logs/app.log:26,38`）。

**D4 · "订单量"是 `COUNT(*)` 还是 `SUM(order_quantity)`（高）**　`:156-157` 描述「订单中商品的购买数量。」alias `[销量, 购买数量, 件数]`；
`:126-127` `order_id` 描述「订单唯一标识。」alias 仅 `[订单ID]`。真实 `dw.sql:194` 主键 ⇒ 一行一单，115 行 = 115 单。
歧义点：**"订单量"不属于任何列的 alias**，LLM 面对 `order_quantity`（"购买数量"）与 `order_id`（"订单唯一标识"）两个都不明确的候选，
最易写成 `SUM(order_quantity)` → **偏大 5.41 倍**（622 vs 115）。

**D5 · 金额粒度：整单金额 vs 单价（高）**　`:162`「订单金额。」未说粒度。真实：静态核算 14/15 个商品满足
`order_amount = order_quantity × 恒定单价`；**例外 `P008`**（`dw.sql:211` 2 件 299 元 vs `dw.sql:226` 1 件 199 元）。
歧义点：(a) 无 price 列可交叉验证整单/单价；(b) `P008` 单价不自洽 ⇒ "金额÷件数=单价"对它不成立；(c) `AOV.alias`「平均单价」因此无可靠落地方式。

**D6 · 别名互撞与召回歧义（中）**　`:9`（dim_region.region_id）与 `:151`（fact_order.region_id）alias **逐字相同**；
`:21`（region_name）alias `[地区, 区域, 大区]` 与之同域。这些 alias 都各自生成 Qdrant 向量点（`meta_knowledge_service.py:124-131`），
关键词"区域"会同时命中三列。实测佐证 `docker/fixed-backend-report.md:654-657`：「同一语义问出过 `大区`（中文题）、`地区`（英文题）、`region_name`（英文题 #5）」。

**D7 · `role` 标注的语义暗示与实际用法冲突（中）**　`fact_order.date_id.role=foreign_key`(`:143`) 暗示"必须 join `dim_date`"；
而 `dim_date.date_id.role=primary_key`(`:91`)、`year/month/day` 全是 `dimension`。`role` 原样进提示词（`merge_retrieved_info.py:116`），
LLM 据此判断"这列能不能直接过滤"，实测它选择了不 join（`logs/app.log:30` 裁掉 `dim_date` → `logs/app.log:33` 直接 BETWEEN）。
结论：**元数据未指定"该用哪种日期过滤写法"**，两种口径因此并存漂移。

---

## 5. 修复建议

### A 类 · 元数据描述怎么改（改 `conf/meta_config.yaml` 及其 dataclass 载体）

| # | 建议 | 改动面 | 风险 |
|---|------|--------|------|
| A1 | 修 **AOV**：`relevant_columns` 改 `[fact_order.order_amount, fact_order.order_id]`，描述补公式 `SUM(order_amount)/COUNT(DISTINCT order_id)`，删 alias「平均单价」 | `conf/meta_config.yaml:172-176` | 低。须重跑指标索引（`docker/docker-compose.yaml:135` 的 `meta-build`），否则线上仍是旧口径 |
| A2 | `dim_region.province` 描述补「**本表只到省级行政区，无城市粒度**；用户问'城市'时按省回答，别名体现真实粒度」 | `:14` | 低（纯文案）但**必须重建 Qdrant 索引**才生效（描述参与向量：`meta_knowledge_service.py:116-122`） |
| A3 | `fact_order.date_id` 补「= `dim_date.date_id`，**格式 yyyyMMdd 整数**，标准写法 `date_id BETWEEN yyyyMMdd AND yyyyMMdd`」；`order_id` 补「**一行一单**，订单数用 `COUNT(*)`」 | `:144`、`:126` | 低–中。定死"标准写法"后若改 JOIN `dim_date`，描述需同步更新，否则又漂移 |
| A4 | `quarter` 补「自然季度，取值形如 `'Q1'`（带 Q 前缀字符串）」；`month` 补「**1–12 的数字**，非月份名」；`year`/`day` 同理补取值域 | `:98,104,110,116` | 低（纯文案） |
| A5 | `order_amount` 补「**整单金额（已含件数），非单价**；本库无退款/运费列」；`order_quantity` 补「**件数**，非订单数」 | `:162`、`:156` | 低 |
| A6 | `dim_region` 表描述补粒度（省份 6/大区 5/国家 1）；`member_level`、`category` 补枚举全集 | `:4`、`:54`、`:76` | 低。但枚举会随数据变化，写死 YAML 会过期 → 见 C3 |
| A7 | 拆分冲突别名：`fact_order.region_id.alias` 去掉「地区ID/区域ID」改 `[外键, 关联地区ID]`；`dim_region.region_name.alias` 去掉「地区」只留 `[大区, 区域名]` | `:151`、`:21` | **中**。别名即向量检索入口（`meta_knowledge_service.py:124-131`），改别名会**改变召回结果**，须重跑基线对比 |
| A8 | 给 `MetricConfig` 增加可选 `formula`/`exclude`（如 `["退款","运费"]`）字段 | `app/conf/meta_config.py:41-50` + YAML | **中**。`MetricInfo`(`metric_info.py:12-20`)、ORM(`models/metric_info.py:48-61`)、`meta.sql:32-39` 都需加列 → **本次只读约束下不可改**，建议单独立项 |

### B 类 · 提示词要不要加约束（改 `prompts/*.prompt`）

| # | 建议 | 改动面 | 风险 |
|---|------|--------|------|
| B1 | `generate_sql.prompt` 增「**不得把 A 列当 B 列**；用户用词在元数据中无严格对应列（如'城市' vs 只有 province）时，用语义最近列并让别名体现真实粒度（如 `AS 省份`）」 | `prompts/generate_sql.prompt:17-24` 增 1 行 | **中**。提示词变长会挤占 MTU（本项目有 MTU 黑洞，需 MSS clamp）；且属软约束，须配合 A2/A5 生效 |
| B2 | `generate_sql.prompt` 增「时间过滤**统一 `date_id BETWEEN`**；仅当用户明确要求按季度/月份**分组**时才 JOIN `dim_date`」 | 同上 | **中**。固化口径会改变现有 SQL 形态；`correct_sql.prompt:29-30` 要求"保持语义不变、最小修改"，两处提示词需同步，否则校正节点与生成节点打架 |
| B3 | `filter_table_info.prompt:30-34` 增「用户概念无严格对应项时（如'城市' vs province），**必须保留语义最近候选字段**，不得凭空丢弃该维度」 | `prompts/filter_table_info.prompt` | 中。该节点目前会把 `dim_date` 整个裁掉（`logs/app.log:30`），保留策略过激会让提示词变大 |
| B4 | `filter_metric_info.prompt` 增「用户**显式点名指标名或别名**时必须选中该指标」 | `prompts/filter_metric_info.prompt:21-24` | 低。`logs/app.log:42` 实测 GMV 被正确保留；补这条主要防"客单价/AOV"类中文别名被误删（`logs/app.log:37` AOV 曾召回后被裁） |
| B5 | `generate_sql.prompt` 增「筛选条件与元数据声明的数据范围冲突时，**在别名中标注**（如 `AS 城市_数据仅有省份`），不得静默返回空」 | 同 B1 | **中–高**。提示词层打补丁依赖 LLM 自觉，更稳的是 C4 节点级硬约束 |

### C 类 · 要不要新增"数据范围声明"节点

**结论：建议新增"声明"，但不要新建 LangGraph 节点 —— 扩展现有 `add_extra_context` + `meta_config.yaml` 即可。**

| # | 建议 | 改动面 | 风险 |
|---|------|--------|------|
| C1 | **不要**新增独立节点 | — | 新节点 = 图拓扑变化（`app/agent/graph.py:46-89` 现 12 个节点），会打乱前端 `StepRail.tsx:19-30` 的 12 步布局与"全绿"判定，改动面/收益比最差 |
| C2 | **推荐**：扩展 `add_extra_context`，新增 `data_scope`（min/max date、各维度枚举全集、fact 行数），`generate_sql.prompt` 加 `{data_scope}` 槽位 | `app/agent/nodes/add_extra_context.py:27-40` + `app/agent/state.py:48-53`（加 `DataScopeState`）+ `prompts/generate_sql.prompt:12` + `app/agent/nodes/generate_sql.py:35-62`（input_variables） | **中**。`date_info` 本就 `yaml.dump` 注入（`generate_sql.py:58`），扩字段不影响结构；但 `data_scope` **来源必须是数仓实时统计**，不能写死在 YAML |
| C3 | `data_scope` 来源：**新增只读统计**（`SELECT MIN(date_id),MAX(date_id),COUNT(*) FROM fact_order` + 各维度 `SELECT DISTINCT`），走 `dw_mysql_repository.py` 新增方法 | `app/repositories/mysql/dw/dw_mysql_repository.py` 新增 1 方法 | **低–中**。只读，多 1 次往返（约 +10–30ms；当前真瓶颈是 `docs/OPTIMIZATION-BACKLOG.md:42-60` 记的 ES 串行检索）。**不要**把枚举写死进 YAML（会过期，见 A6） |
| C4 | **必须**新增"空结果提示"通道：`run_sql` 返回空数组时发 `{"type":"warning","message":"该条件在数据范围内无记录（数据时间范围：2025-01-01 ~ 2025-03-31）"}`，前端渲染为醒目提示 | `app/agent/nodes/run_sql.py:28-31` + `app/api/schemas/query_schema.py` + 前端 `ResultTable.tsx:38-40` | **中**。这是**唯一能真正解决"空数组却报成功"**的改动（现状见 §3.4）；前端在另一个仓库 `code/shopkeeper-agent-frontend`，需跨仓改动 |
| C5 | 过滤节点裁剪后，若"被裁掉的表"恰是用户问题必需维度，**不要静默裁剪**：记入 state，并在提示词里保留「⚠ 用户要求的维度 X 已被过滤，答案可能不完整」 | `app/agent/nodes/filter_table.py:50-58` | 中。提示词变长；收益是消除 `logs/app.log:30` 这类静默失真 |

---

## 6. 证据索引

| 结论 | 位置 |
|------|------|
| AOV 描述与依赖列矛盾 | `conf/meta_config.yaml:172-176` |
| 无 city 列 / 无 price 列 | `docker/mysql/dw.sql:9-15` / `:60-66` |
| 数据只到 2025-03-31、115 单 | `docker/mysql/dw.sql:97-187`、`:203-318` |
| `dim_date` 被召回又被裁掉 | `logs/app.log:27` vs `:30` |
| 生成的日期过滤写法 | `logs/app.log:33` |
| GMV 聚合与静态核算一致（279159.5） | `logs/app.log:35` |
| `date_info.quarter`=Q4 而数据仅 Q1 | `logs/app.log:32` |
| 值召回经常为空 | `logs/app.log:26`、`:38` |
| "城市→province" 实测 | `docker/fixed-backend-report.md:666-671` |
| "Q1 2024 → 空集" 实测 | `docker/fixed-backend-report.md:643` |
| 空结果前端不渲染表格 | `code/shopkeeper-agent-frontend/src/components/ResultTable.tsx:38-40` |
| `examples` 截断到 10 且无序 | `app/repositories/mysql/dw/dw_mysql_repository.py:31` |
| ES 取值索引无日期 | 实测 `value_index` 聚合（75 docs / 10 字段） |
| 提示词只有 4 个上下文槽位 | `prompts/generate_sql.prompt:6,9,12,15` |

*本报告为只读审计产物，未对任何源码、配置、元数据或 SQL 文件做修改。*
