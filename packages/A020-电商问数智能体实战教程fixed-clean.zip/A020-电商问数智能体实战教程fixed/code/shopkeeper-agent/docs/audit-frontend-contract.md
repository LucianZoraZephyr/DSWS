# 前后端契约一致性审计报告（SSE 事件 / 步骤条 / 结果表）

- 审计对象：
  - 后端 `code/shopkeeper-agent`（FastAPI + LangGraph，SSE 出口在 `app/services/query_service.py`）
  - 前端 `code/shopkeeper-agent-frontend`（React + Vite，消费方 `src/lib/agentApi.ts` / `src/App.tsx` / `src/components/*`）
- 审计时间：2026-10-20，审计方式：**纯静态代码走查 + 只读实测**（未发起任何 `/api/query` 请求，未使用 docker/sudo，未修改任何源码）
- 路径约定：下文「后端 X:行号」指 `code/shopkeeper-agent/X`，「前端 X:行号」指 `code/shopkeeper-agent-frontend/X`；所有行号取自审计时的当前工作区。
- 已有材料交叉引用：`/home/zhensirong/VM-Share/ux-examples-catalog.md`（10 题实测记录，后文简称「实测目录」）。

---

## 0. 结论摘要（TL;DR）

1. **事件信封层是契约良好的**：三类事件（`progress` / `result` / `error`）的字段名、类型、状态枚举值，前后端逐字对得上，12 个步骤名也逐字对得上；SSE 帧格式（`data: {json}\n\n`）与前端解析器严格匹配。
2. **任务前提中的「后端 11 节点 vs 前端 12 节点」不成立**。后端图注册的是 **12 个节点**（后端 `app/agent/graph.py:46-57`），前端画的 12 个节点与之**一一对应**（含 `校正SQL`）。真正的不一致是：`校正SQL` 是**条件节点**，只在校验失败时才跑，因此绝大多数查询里它**永远停在灰色 pending**，而 `StepRail` 没有「已跳过」这一档。
3. **红色错误框确实存在且有效**（前端 `src/components/MessageBubble.tsx:51-55`），`type:"error"` 路径是全链路唯一被完整处理的失败路径；前端 `src/App.tsx:113-128` 的 `type:"result"` 分支**只看事件类型不看载荷**，因此「后端把失败编码进数据行」的 3 类静默失败（空数组 / 全 null 行 / `error_message` 行）全部被渲染成「绿色成功」。
4. **用户主动取消被渲染成「成功」**：中断分支把 `status` 写成 `"done"`（前端 `src/App.tsx:149`），并且被计入侧栏「完成」计数（前端 `src/App.tsx:62-65`）；同时正在跑的步骤被 `stopRunningSteps` 标成 `error`（前端 `src/App.tsx:35-41`），于是画面上是「文案说已停止 + 步骤条一个红叉」，语义互相打架。
5. **数值类型被后端 `default=str` 悄悄改写**（后端 `app/services/query_service.py:66`）：MySQL `DECIMAL` → Python `Decimal` → JSON **字符串**（`"10"`），而同行的 `FLOAT` 列是 JSON 数字（`62190.0`）。前端 `formatCell` 一律 `String(value)`（前端 `src/components/ResultTable.tsx:23-27`），屏幕上完全看不出差别，但复制到剪贴板后下游拿到的是 `"10"`。

---

## 1. 契约对照表（逐字段）

| # | 事件/字段 | 后端产生位置 | 后端实际形状 | 前端类型声明 | 前端消费位置 | 一致 | 差异风险 |
|---|---|---|---|---|---|---|---|
| 1 | HTTP 方法/路径 | 后端 `app/api/routers/query_router.py:27` `@query_router.post("/api/query")` | `POST /api/query` | 无（`agentApi.ts` 内联） | 前端 `src/lib/agentApi.ts:15` `fetch(\`${API_BASE_URL}/api/query\`, {method:"POST"...})` | ✅ | 无 |
| 2 | 请求体 `query` | 后端 `app/api/schemas/query_schema.py:15` `query: str` | `{"query":"..."}`，必填，缺失返回 422 | 无 | 前端 `src/lib/agentApi.ts:21` `body: JSON.stringify({ query })` | ✅ | 前端发送前已 `trim()`，空串会被前端拦下（`App.tsx:76`），不会打到后端 |
| 3 | `Accept` 头 | 后端不校验 | — | 无 | 前端 `src/lib/agentApi.ts:19` `Accept: "text/event-stream"` | ✅ | 无 |
| 4 | 响应 `Content-Type` | 后端 `app/api/routers/query_router.py:39` `media_type="text/event-stream"` | `text/event-stream` | 无 | 前端 **不校验** content-type | ⚠️ 宽松一致 | 实测 `http://127.0.0.1:8000/openapi.json` 里 200 响应被声明为 `application/json`，与实现不符；前端不校验所以不炸，但任何信 OpenAPI 的客户端会误当 JSON 解析 |
| 5 | SSE 帧格式 | 后端 `app/services/query_service.py:66` `yield f"data: {json.dumps(chunk, ensure_ascii=False, default=str)}\n\n"` | `data: <json>\n\n` | 无 | 前端 `src/lib/agentApi.ts:42` `buffer.split(/\n\n/)` + `:64` `.replace(/^data:\s?/, "")` | ✅ | 后端**不发** `event:` / `id:` / `[DONE]` 哨兵；前端靠流 EOF 判断结束（`agentApi.ts:39` `if (done) break`），属弱契约 |
| 6 | JSON 编码 | 后端 `json.dumps(..., ensure_ascii=False, default=str)` | 中文原样、日期/Decimal 降级为字符串 | 无 | 前端 `src/lib/agentApi.ts:71` `JSON.parse(payload) as AgentEvent` | ⚠️ | `default=str` 是**类型副作用源**，详见 §4 第 1 条 |
| 7 | 判别字段 `type` | 所有 `writer({...})` 第一键均为 `"type"` | `"progress"` / `"result"` / `"error"` | 前端 `src/types/agent.ts:23` `AgentEvent = ProgressEvent \| ResultEvent \| ErrorEvent` | 前端 `src/App.tsx:105/113/122` | ✅ | 前端 `App.tsx:122` 的兜底 `return` 会把**任何未知 type** 当成 error 处理（详见 §3.1 风险 b） |
| 8 | `progress.step` | 后端各节点 `step = "..."`，如 `app/agent/nodes/extract_keywords.py:19`、`run_sql.py:19` | 中文步骤名，共 12 个取值 | 前端 `src/types/agent.ts:9` `step: string` | 前端 `src/components/StepRail.tsx:18-31` 硬编码 12 个同名节点 | ✅ | 12 个名字逐字相同；但前端**硬编码**，后端加/改节点不会自动同步（详见 §5 B7） |
| 9 | `progress.status` | 后端 `app/agent/nodes/*.py` 仅用 `"running"` / `"success"` / `"error"` | 三值枚举 | 前端 `src/types/agent.ts:5` `ProgressStatus = "running" \| "success" \| "error"` | 前端 `src/App.tsx:109` `upsertStep`、`StepRail.tsx:63-65` `statusFor` | ✅ | 前端另加了 `FlowStatus = ProgressStatus \| "pending"`（`StepRail.tsx:9`），`pending` **后端从不发**，是纯前端补位 |
| 10 | `progress` 的耗时字段 | 后端 writer 只有 `type/step/status` 三个键 | **无**耗时/时间戳 | 前端 `src/types/agent.ts:28` `updatedAt: number`（**本地** `Date.now()`） | 前端 `src/App.tsx:48` 写入，但 `StepRail` 从不渲染 | ⚠️ 能力缺失 | 后端无耗时 → 前端无法显示单步耗时；`updatedAt` 是「最后一次事件到达时间」而非耗时，即使渲染也是错的 |
| 11 | `result.data` 整体 | 后端 `app/agent/nodes/run_sql.py:31` `writer({"type": "result", "data": result})`，`result` 来自 `app/repositories/mysql/dw/dw_mysql_repository.py:51-54` `[dict(row) for row in result.mappings().fetchall()]` | `list[dict]`（可能为空 `[]`） | 前端 `src/types/agent.ts:15` `data: unknown` | 前端 `src/App.tsx:113-120`、`src/components/ResultTable.tsx:7-21` | ⚠️ | 前端声明为 `unknown`，**没有任何行/列类型**，全靠运行时猜；`data` 实为数组这一点没有在类型里体现 |
| 12 | `result.data` 元素 | 后端 `dw_mysql_repository.py:54` `dict(row)`（SQLAlchemy RowMapping） | `dict[str, str\|int\|float\|None\|Decimal\|date]` | 前端 `src/types/agent.ts:15` `unknown` → `ResultTable.tsx:7-21` 运行时归一 | 前端 `ResultTable.tsx:9-13` 非对象元素兜底成 `{序号, 值}` | ⚠️ | 元素类型不透明；见 §4 |
| 13 | `result.data` 里的 `error_message` 行 | **后端代码零命中**（`grep -rn "error_message" app/ prompts/` 无结果）；由 LLM 编造的伪 SQL `SELECT '...' AS error_message` 执行成功产生（实测目录 §2 #6、:147、:156） | `[{ "error_message": "无法生成SQL：..." }]` | 前端**无任何声明、无任何检查** | 前端无消费点 → 被当普通数据行渲染 | ❌ **不一致** | 静默失败：用户看到一张「看起来完全正常」的 1 行 1 列表格 |
| 14 | `result.data` 为 `[]` | 后端如实返回空集（实测目录 §2 #5） | `[]` | 前端 `src/types/agent.ts:15` `unknown` | 前端 `ResultTable.tsx:38-40` `if (columns.length === 0) { return null; }` | ❌ **不一致** | 整块「查询结果」表格**不渲染**，用户只看到「查询完成，结果为空。」一句 |
| 15 | `error.message` | 后端 `app/services/query_service.py:69` `error = {"type": "error", "message": str(e)}` | 原始 Python 异常字符串 | 前端 `src/types/agent.ts:20` `message: string` | 前端 `src/App.tsx:126` `error: event.message` → `MessageBubble.tsx:51-55` 红框 | ✅ | 内容是 `str(e)`，可能是 `OperationalError(...)` 这类技术串，没有人类可读的解释 |
| 16 | `ChatMessage.content` | 后端无此字段（后端不产出文案） | — | 前端 `src/types/agent.ts:34` `content: string` | 前端 `App.tsx:108/117/125/138/150` | ⚠️ 单向 | 前端**自造**文案（`正在执行：X` / `查询完成，共 N 行结果。` / `这次查询没有成功。` / `已停止本次查询。`），后端无法控制措辞 |
| 17 | `ChatMessage.error` | 后端对应字段是 `error.message` | 字符串 | 前端 `src/types/agent.ts:39` `error?: string` | 前端 `MessageBubble.tsx:51` `{message.error && (...)}` | ✅ 映射正确 | 仅 `type:"error"` 与非 abort 的 catch 会写入；`result`/`[]`/abort 三条路径都不写 |
| 18 | `ChatMessage.status` | 后端无 | — | 前端 `src/types/agent.ts:36` `"streaming" \| "done" \| "error"` | 前端 `App.tsx:91/116/124/149` | ⚠️ 单向 | 后端只有 3 种事件，前端却有 3 种状态；「被用户取消」被迫复用 `"done"`（见 §3.4） |
| 19 | `ChatMessage.result` | 后端对应 `result.data` | 数组 | 前端 `src/types/agent.ts:38` `result?: unknown` | 前端 `MessageBubble.tsx:58` `message.result !== undefined && <ResultTable .../>` | ✅ | `[]` 也会进 ResultTable，但被内部 `return null` 吞掉 |
| 20 | `ChatMessage.steps` | 后端对应 `progress` 事件流 | 步骤数组 | 前端 `src/types/agent.ts:37` `steps?: StepState[]` | 前端 `App.tsx:109` `upsertStep` 聚合 → `StepRail.tsx:117` | ✅ | 聚合键是**步骤名字符串**（`App.tsx:44`），后端改名即断链 |
| 21 | 流结束信号 | 后端不发结束事件，靠生成器结束 | EOF | 无 | 前端 `agentApi.ts:39/53-57` 读完后收尾 → `App.tsx:135-141` 若仍 `streaming` 则写「流程已结束，后端未返回查询结果。」 | ⚠️ | 后端若中途断流（进程被杀、代理截断），前端无法区分「正常结束」和「半途而废」，只显示「流程已结束」 |
| 22 | 取消/中断事件 | 后端无取消协议 | — | 无 | 前端 `App.tsx:143` `error instanceof DOMException && error.name === "AbortError"` | ⚠️ | 前端只是**单方面** abort 本地 fetch；后端侧仍在跑（推断，见 §6 验证方法 V3） |

---

## 2. 节点数不一致的完整分析（12 个节点逐个说明）

### 2.1 先纠正一个前提

- 后端图**注册了 12 个节点**：后端 `app/agent/graph.py:46-57` 连续 12 行 `graph_builder.add_node(...)`，含 `"correct_sql"`（`:56`）。
- 前端画了 **12 个节点**：前端 `src/components/StepRail.tsx:18-31` 的 `const nodes: FlowNode[]` 恰好 12 项，第 11 项是 `{ step: "校正SQL", x: 670, y: 630 }`。
- 12 个步骤名与后端 12 个 `step = "..."` 常量**逐字相同**（`extract_keywords.py:19`「抽取关键词」、`recall_column.py:25`「召回字段信息」、`recall_metric.py:25`「召回指标信息」、`recall_value.py:25`「召回字段取值」、`merge_retrieved_info.py:31`「合并召回信息」、`filter_metric.py:24`「过滤指标信息」、`filter_table.py:24`「过滤表信息」、`add_extra_context.py:21`「添加额外上下文」、`generate_sql.py:24`「生成SQL」、`validate_sql.py:20`「校验SQL」、`correct_sql.py:24`「校正SQL」、`run_sql.py:19`「执行SQL」）。
- 因此**不存在「前端多画了一个后端没有的节点」**。后端在**正常路径**上只发 11 个节点的 progress 事件（11 × running/success = 22 条，实测目录 §1 正是「22 条 progress 事件」），第 12 个 `校正SQL` 被条件边挡住。

### 2.2 条件边的真实行为

后端 `app/agent/graph.py:83-87`：

```python
graph_builder.add_conditional_edges(
    source="validate_sql",
    path=lambda state: "run_sql" if state["error"] is None else "correct_sql",
    path_map={"run_sql": "run_sql", "correct_sql": "correct_sql"},
)
```

`state["error"]` 只有 `validate_sql` 会写：`app/agent/nodes/validate_sql.py:35` 成功写 `{"error": None}`，`:40` 失败写 `{"error": str(e)}`；`:39` 在失败分支里**仍然发 `status:"success"`**。

### 2.3 逐节点对照

| 前端节点（`StepRail.tsx:18-31`） | 后端发出位置 | 后端何时发 | 前端画成什么 | 该节点缺失时的表现 |
|---|---|---|---|---|
| 抽取关键词 (`:19`) | `extract_keywords.py:21/49/54` | 总是（START 之后） | running→绿勾 | 步骤条整体不渲染（`StepRail.tsx:118` `if (steps.length === 0) return null`） |
| 召回字段信息 (`:20`) | `recall_column.py:26/66/70` | 总是，**与下面两个并行** | running→绿勾 | 同上；并行三个节点在图上是同一行（y=112），不体现先后 |
| 召回指标信息 (`:21`) | `recall_metric.py:26/66/70` | 总是，并行 | 同上 | 同上 |
| 召回字段取值 (`:22`) | `recall_value.py:26/64/68` | 总是，并行 | 同上 | 同上 |
| 合并召回信息 (`:23`) | `merge_retrieved_info.py:32/150/157` | 三路召回全部完成后 | running→绿勾 | 缺失即表示上游异常，通常已伴随 `type:error` |
| 过滤指标信息 (`:24`) | `filter_metric.py:25/58/63` | 总是，**与过滤表信息并行** | running→绿勾 | — |
| 过滤表信息 (`:25`) | `filter_table.py:25/63/68` | 总是，并行 | running→绿勾 | — |
| 添加额外上下文 (`:26`) | `add_extra_context.py:22/39/44` | 总是（两路过滤都完成后） | running→绿勾 | — |
| 生成SQL (`:27`) | `generate_sql.py:25/64/69` | 总是 | running→绿勾 | LLM 超时/报错 → `status:"error"` → 红叉 + 异常继续抛出 |
| 校验SQL (`:28`) | `validate_sql.py:21/33/39/44` | 总是 | **永远绿勾**（失败也发 success，`:39`） | 无失败态可显示：用户看不出曾经自我修正过一次 |
| 校正SQL (`:29`) | `correct_sql.py:25/73/77` | **仅当 `state["error"] is not None`** | 绝大多数查询里**永久灰色 pending**（`StepRail.tsx:64` `?? "pending"`、`:80` 空心 Circle、`:94` 灰底） | 永久 pending，不是「卡住」：pending 图标是空心圆，与 running 的旋转图标（`:69`）视觉可区分 |
| 执行SQL (`:30`) | `run_sql.py:20/30/31/35` | 总是（校正分支之后） | running→绿勾→随后发 `result` | 抛异常 → `run_sql.py:35` 发 error + re-raise → 后端补一条 `type:error` |

### 2.4 由此产生的两个真实视觉问题

1. **「有误」分支箭头永远画着**。前端 `src/components/StepRail.tsx:47` 的连接线 `"M488 650 L586 650"`（校验SQL→校正SQL）和 `:51-54` 的静态标签 `{ text: "有误", x: 530, y: 642 }` / `{ text: "无误", x: 366, y: 704 }` 都是**常量**，不随真实分支高亮。配合「校验SQL 永远绿勾」，用户看到的是「一条指向灰色校正SQL 的『有误』箭头 + 一个绿色校验SQL」，既可能误以为走过修正分支，也可能误以为流程还没走完。
2. **pending 承担了两种语义**：「不需要走」（校正SQL）与「还没走到」（步骤条右侧尚未执行的节点）在前端**用同一种灰色空心圆**表达（`StepRail.tsx:64`、`:80`、`:94`、`:103`）。前端类型里没有 `skipped` 档（`src/types/agent.ts:5` 只有 running/success/error）。

---

## 3. 异常路径的前端表现审计

### 3.1 `type:"error"` 事件 → 前端**确实有**红色错误框（结论：不是问题）

代码依据链：

1. 前端 `src/App.tsx:122-128`（`onEvent` 的兜底分支，即非 progress、非 result）：

```tsx
return {
  ...message,
  status: "error",
  content: "这次查询没有成功。",
  error: event.message,
  steps: stopRunningSteps(message.steps),
};
```

2. 前端 `src/components/MessageBubble.tsx:51-55`：

```tsx
{message.error && (
  <div className="mt-3 border border-tomato/30 bg-tomato/10 px-3 py-2 text-sm text-tomato">
    {message.error}
  </div>
)}
```

3. `tomato` 是真实主题色（前端 `tailwind.config.ts:27` `tomato: "#d64e3a"`），所以红框会真实渲染，不是死类名。
4. 同时 `stopRunningSteps`（前端 `src/App.tsx:35-41`）把正在 `running` 的步骤改成 `error`，`StepRail.tsx:76-78`/`:97`/`:106` 会画成红色叉号。

**结论**：`type:"error"` 是全链路唯一被完整处理、且有明确红色信号的失败路径。实测目录 §3.2 的判断（「真正的 `type=error` 会得到醒目的红色框 + 『这次查询没有成功。』」）与代码一致。

遗留风险：
- **(a) 红框内容是原始异常串**：`error: event.message` 来自后端 `str(e)`（后端 `app/services/query_service.py:69`），可能是 `OperationalError(...)`；红框**不包含失败发生在哪个步骤**，需要用户自己对照步骤条的红叉去猜。
- **(b) 未知事件类型会被误判成失败**：前端 `src/App.tsx:113-128` 没有用 `switch`，而是「progress / result / 其余全当 error」。后端将来加一个 `type:"meta"` 或 `type:"token"`，前端会立刻把 `content` 改成「这次查询没有成功。」、`status` 改成 `"error"`，而 `event.message` 是 `undefined` → `message.error = undefined` → **红框也不显示**（`MessageBubble.tsx:51` 条件为假）→ 变成「文案说失败但没有任何红框」的静默失败。
- **(c) 失败在第一个 progress 之前到达**：`message.steps` 为 `[]` → `StepRail.tsx:118` 返回 `null` → 界面上只有一段红框，没有流程图。

### 3.2 `data:[{"error_message": "..."}]` → 前端显示成一张**正常表格**，用户**无法**意识到失败

代码依据：

1. 前端 `src/App.tsx:113-120`：`type:"result"` 分支**只看事件类型**：

```tsx
if (event.type === "result") {
  return { ...message, status: "done", content: summarizeResult(event.data), result: event.data };
}
```

2. 前端 `src/lib/format.ts:18`：`summarizeResult` 对 1 行数组返回 `` `查询完成，共 ${data.length} 行结果。` `` → **「查询完成」**。
3. 前端 `src/components/ResultTable.tsx:7-13` `normalizeRows` 把该行原样当成一行记录；`:31-36` 把 `error_message` 收集为**表头**；`:42-83` 渲染成标准表格。
4. 前端 `src/components/MessageBubble.tsx:58` `message.result !== undefined` → 表格被渲染。

最终画面：**一张 1 行 1 列、表头写着 `error_message` 的「查询结果」表格 + 「查询完成，共 1 行结果。」**，**全屏没有一处红色**。用户第一反应是「查到了 1 条数据」，而不是「查询失败了」。

补充事实：这个 `error_message` 列名**不是后端常量**（后端代码零命中），是 LLM 每次现场编的伪 SQL 的别名，实测目录记录过 `error_message` / `错误信息` / `message` / `查询状态` 等多种措辞（实测目录 :156）。因此**前端按列名硬匹配也不可靠**，根治必须后端发 `type:"error"`。

### 3.3 `data:[]` → 表格**完全不渲染**，只剩一句话

代码依据：

1. 前端 `src/App.tsx:113-120`：`status:"done"`，`content: summarizeResult([])`。
2. 前端 `src/lib/format.ts:18`：`data.length > 0 ? ... : "查询完成，结果为空。"`。
3. 前端 `src/components/ResultTable.tsx:30` `normalizeRows([])` → `[]`；`:31-36` → `columns = []`；`:38-40`：

```tsx
if (columns.length === 0) {
  return null;
}
```

4. 前端 `src/components/MessageBubble.tsx:58` 条件为真、但组件返回 `null` → **整块表格区消失**。

最终画面：**「查询完成，结果为空。」一句话 + 一条全绿的步骤条**（22 条 progress 全 success，实测目录 §2 #5）。用户无法区分「这个时间范围确实没数据」「召回失败」「SQL 跑偏了」三种完全不同的语义。

### 3.4 流被中断（`AbortError`）→ 「用户取消」与「成功」**没有区分**

代码依据：

1. 前端 `src/App.tsx:142-156`：

```tsx
const isAbort = error instanceof DOMException && error.name === "AbortError";
...
status: isAbort ? "done" : "error",
content: isAbort ? "已停止本次查询。" : "无法连接问数接口。",
error: isAbort ? undefined : error instanceof Error ? error.message : String(error),
steps: stopRunningSteps(message.steps),
```

2. 前端 `src/App.tsx:35-41` `stopRunningSteps`：`status === "running"` → `status: "error"`（**红叉**）。
3. 前端 `src/components/StepRail.tsx:76-78`/`:97`/`:106`：`error` 状态 → 红色叉 + `border-tomato/35 bg-tomato/10 text-tomato`。
4. 前端 `src/App.tsx:62-65`：`completedCount` 统计 `message.status === "done"` → **被取消的查询被计入侧栏「完成」计数**（前端 `src/App.tsx:233-238` 展示该计数）。
5. 前端 `src/components/MessageBubble.tsx:51`：`error` 为 `undefined` → **不渲染红框**；`:38` `status !== "streaming"` → 显示复制按钮。

结论：
- 画面 = 文案「已停止本次查询。」+ **步骤条上一个红叉**（看起来像失败）+ 无红框 + 侧栏「完成」+1 + 可复制。
- 也就是说：**被用户取消在状态位上与真正成功完全相同（都是 `"done"`）**，唯一差别只有文案和那个红叉。红叉语义是「这一步失败了」，但真实情况是「这一步被你主动掐了」——**前端没有把「被用户取消」和「成功」区分开，也没有和「失败」区分开**。
- 附带：`stopRunningSteps` 只改 `running`，已经 `success` 的步骤保持绿色，所以被取消时的步骤条是「前半段绿 + 当前红叉 + 后半段灰」。

---

## 4. 类型不一致清单

| # | 不一致类型 | 产生位置（后端） | 传到前端的形状 | 前端渲染结果 | 归属 |
|---|---|---|---|---|---|
| 1 | **`DECIMAL` → 字符串** | 后端 `app/services/query_service.py:66` `json.dumps(chunk, ensure_ascii=False, default=str)`；MySQL `SUM(INT)` 返回 DECIMAL → asyncmy 映射为 Python `Decimal` | JSON **字符串**（实测 `json.dumps([{'销量': Decimal('10')}], default=str)` → `[{"销量": "10"}]`）；实测目录 §2 #2 线上载荷确为 `{"销量": "10", "销售额": 62190.0}` | 前端 `ResultTable.tsx:26` `String(value)` → 屏幕上是 `10`；与右边 `62190.0` 肉眼无差别，但复制出去是 `"10"`（`MessageBubble.tsx:15` → `format.ts:32-34` `JSON.stringify`），下游做数值计算会踩坑 | **后端**（前端只能事后归一） |
| 2 | **数字 vs 字符串混列** | 后端 `docker/mysql/dw.sql:199-200` `order_quantity INT` / `order_amount FLOAT` → `SUM()` 后前者 DECIMAL、后者 DOUBLE | 同一行里 `"10"`（string）与 `62190.0`（number） | 前端 `format.ts` / `ResultTable.tsx:23-27` **不区分**，全部 `String()`；列与列之间类型不一致时没有任何提示 | 后端（根治）+ 前端（列级类型提示可选） |
| 3 | **数值无格式化** | 后端原样透传 | `62190.0`、`0.5`、`100178.5` | 前端 `String(62190.0)` → **「62190.0」**（带多余小数点）；没有千分位、没有单位、没有有效位控制；`Decimal("62190.00")` 会显示成「62190.00」 | 前端即可（但要先解决 #1，否则不知道精度意图） |
| 4 | **`null` 单元格** | 后端 NULL 列原样透传 | `null` | 前端 `ResultTable.tsx:24` `if (value === null || value === undefined) return "-";` → 渲染成 **`-`**；**无法区分「没召回到这个字段」与「值真的是空」**（实测目录 §2 #7：20 行两列全是 `-`，看起来却像一张正常表） | 前端即可（加空值提示）+ 后端（区分「召回为空」） |
| 5 | **日期/时间** | 后端 `default=str` | `"2025-03-01"`（实测 `json.dumps([{'日期': date(2025,3,1)}], default=str)` → `[{"日期": "2025-03-01"}]`） | 前端按普通字符串渲染，无本地化、无时区标注 | 前端即可 |
| 6 | **列集合随问法漂移** | 后端 `generate_sql` 完全交给 LLM，列别名现场决定（实测目录 §3.1：同义问法出现「地区」/「大区」两种别名） | 每次查询的 key 集合都可能不同 | 前端 `ResultTable.tsx:31-36` 用所有行 key 的**并集**当列，列顺序=首次出现顺序；前端**无任何 schema 校验**，别名漂移无从提示 | 后端（固定别名）+ 前端（可选的别名映射表） |
| 7 | **缺列** | 同一份 `data` 内行键不一致时 | 该行缺某列 → `row[column]` 为 `undefined` | 前端 `ResultTable.tsx:74` → `formatCell(undefined)` → **`-`**（与真 NULL 视觉相同） | 前端即可 |
| 8 | **多列 / 非对象元素** | `data` 里混入非对象（如字符串、数字） | `["a", 1]` | 前端 `ResultTable.tsx:9-13` 兜底成 `{序号, 值}` → 表头变成「序号 / 值」；若与对象行混排则行键异构 → 大量 `-` | 前端即可 |
| 9 | **`data` 非数组** | 后端 `run()` 恒返回 list（`dw_mysql_repository.py:51-54`），理论不会发生 | — | 前端 `ResultTable.tsx:16-20` 兜底成单行 `{值: data}` | 前端即可 |

---

## 5. 可改进项清单

> 归属标注：**前端即可** = 只改 `shopkeeper-agent-frontend`；**需后端配合** = 必须改 `shopkeeper-agent`（或前后端都要改）。

### 5.1 前端即可（不依赖后端改动即可闭环）

| # | 现象 | 位置 | 建议 | 影响面 | 风险 |
|---|---|---|---|---|---|
| F1 | 被用户取消的查询状态是 `"done"`，被计入侧栏「完成」计数 | 前端 `src/App.tsx:149`、`:62-65` | 新增 `ChatMessage.status = "canceled"`（前端 `src/types/agent.ts:36`），abort 分支写 `"canceled"`，`completedCount` 排除它 | 侧栏计数、气泡状态、复制按钮显隐 | 低（纯前端枚举扩展） |
| F2 | 取消时正在跑的步骤被标成 `error`（红叉＝失败） | 前端 `src/App.tsx:35-41` `stopRunningSteps` | 区分「失败」与「被取消」：新增 `stopRunningSteps(steps, "canceled")`，取消时改为 `canceled`/灰色 | 步骤条视觉 | 低；但需同步扩 `ProgressStatus`（`src/types/agent.ts:5`）与 `StepRail.tsx` 的 `FlowStatus`/样式（`:67-81`、`:94-107`） |
| F3 | `onEvent` 兜底分支把未知事件类型当成错误 | 前端 `src/App.tsx:113-128` | 改成 `switch (event.type)`，`default` 分支**忽略**（或只记日志），不要改 `status`/`content` | 事件处理健壮性 | 低 |
| F4 | 空数组时整块表格消失，只剩「查询完成，结果为空。」 | 前端 `src/components/ResultTable.tsx:38-40` | `columns.length === 0` 时渲染一个**空态块**（图标 + 文案 + 「换时间范围/维度再试」引导），而不是 `return null` | 空结果体验 | 低 |
| F5 | `error_message` 这类「失败数据行」被当成功渲染 | 前端 `src/App.tsx:113-120`、`ResultTable.tsx:29-40` | 在 result 分支加启发式：单行 + 单列 + 列名命中 `error_message`/错误文案特征 → 不渲染表格，改渲染红色错误条（文案用该单元格内容） | 静默失败 1/3 | **中**：列名由 LLM 现场决定，启发式会漏判（实测目录 :156 记录过 4 种不同列名）。只能当止损，不能替代后端 |
| F6 | 全 null 列看起来像正常表格 | 前端 `src/App.tsx:113-120` | result 分支检测「存在某一列所有值都是 null」→ 文案改为「查询完成，但没有取到该指标的数据」并给该列加弱化样式 | 静默失败 2/3 | 低 |
| F7 | `message.error` 只有原始异常串，且不含失败步骤 | 前端 `src/App.tsx:126`、`MessageBubble.tsx:51-55` | 红框里补上「失败步骤：X」（前端已有 `message.steps`），并对 `str(e)` 做一次友好化包装 | 报错可读性 | 低 |
| F8 | 步骤条是固定 820×780 画布，窄视口需横向滚动 | 前端 `src/components/StepRail.tsx:129-130` `overflow-x-auto` + `h-[780px] w-[820px]` | 改成按容器宽度等比缩放（`transform: scale` 或 SVG `viewBox` 自适应），或在小屏改用竖向列表 | 响应式 | 低-中：SVG 连接线是绝对坐标硬编码（`:33-49`），缩放需保持 `viewBox` 一致 |
| F9 | 「校正SQL」永久灰色 pending，与「还没走到」视觉相同 | 前端 `src/components/StepRail.tsx:63-65`、`:94`、`:103` | 前端给该节点加「已跳过」样式（区别于 pending）；判据可用「校验SQL 已 success 且校正SQL 无事件」 | 流程图语义 | 低（纯前端推断，无需后端） |
| F10 | `formatCell` 不区分数字/字符串，也无数字格式化 | 前端 `src/components/ResultTable.tsx:23-27` | 加千分位与小数位控制；字符串数字额外做一次数值识别并标注（如等宽字体） | 表格可读性 | 低-中：字符串数字的精度意图已丢失（见 B4） |
| F11 | HTTP 4xx/5xx 一律显示「无法连接问数接口。」 | 前端 `src/lib/agentApi.ts:25-27`（`throw new Error(\`接口请求失败：HTTP ${response.status}\`)`）+ `src/App.tsx:150` | 按 status 区分文案（422＝问题格式不对、5xx＝服务异常、TypeError＝网络不可达） | 报错可读性 | 低 |
| F12 | 步骤条不显示任何耗时 | 前端 `src/components/StepRail.tsx` 全文 + `src/types/agent.ts:28` | 前端可用 `updatedAt` 差值做**近似**耗时（注意：`updatedAt` 是该步最后一次事件的到达时间，不是真实耗时，只能近似，需在 UI 上注明「≈」） | 可观测性 | 中：语义不精确，若后端补了真时间戳就应改用后端的 |
| F13 | 复制结果把 `"10"` 这类字符串数字原样复制出去 | 前端 `src/lib/format.ts:32-34` `JSON.stringify` | 复制时对「看起来是数字的字符串」保持原样但在 UI 上标注（避免下游误用） | 下游数据质量 | 低 |

### 5.2 需要后端配合（前端改不动，或改了也不彻底）

| # | 现象 | 位置（后端） | 建议 | 影响面 | 风险 |
|---|---|---|---|---|---|
| B1 | 失败被编码成 `result.data` 里的一行数据（`error_message`），前端无从判断 | 后端全仓无 `error_message` 字样；根因是 LLM 编造伪 SQL 且该 SQL 能通过 `explain` 与执行（实测目录 :147） | 当 LLM 生成的 SQL 是「字面量 SELECT」或召回结果全空时，**显式发 `type:"error"`**（`{"type":"error","message":"..."}`），不要把它当查询结果 | 覆盖 3 类静默失败中的最危险一类 | 中：需要后端识别「伪 SQL」，判定规则要稳（例如禁止单列字面量投影） |
| B2 | 「校验SQL」即使 `explain` 失败也发 `success` | 后端 `app/agent/nodes/validate_sql.py:36-40`（`writer({... "status": "success"})` 在 except 分支里） | 失败时发 `status:"error"`，或新增 `status:"warning"`；前端 `StepRail.tsx:76-78` 已能吃 `error` | 流程图正确性 | 低（前端零改动即可受益） |
| B3 | `progress` 事件无时间戳/耗时 | 后端各节点 `writer({"type":"progress","step":step,"status":...})` | 加 `ts`（毫秒）或 `duration_ms` 字段 | 前端 `src/types/agent.ts:7-11` 需同步扩类型 | 低 |
| B4 | `Decimal` 被 `default=str` 降级成 JSON 字符串 | 后端 `app/services/query_service.py:66` `json.dumps(chunk, ensure_ascii=False, default=str)` | 给 `json.dumps` 传自定义 encoder：`Decimal → float`（或保留字符串但**带明确约定**），`date/datetime → ISO 8601` | 消除 `"10"` vs `10` 混型 | 中：转 float 会引入浮点误差（建议 Decimal→str→float 或统一转字符串并让前端统一解析） |
| B5 | 召回/过滤为空仍报 `success` | 后端 `app/agent/nodes/recall_column.py:66`、`recall_metric.py:66`、`recall_value.py:64`、`filter_table.py:63` 等（列表为空也走 success 分支） | 区分「跑完了」与「召回到了东西」：空召回时发 `error` 或新增 `warning`/`empty` 状态 | 静默失败 2/3 的根因 | 中：空召回在某些问题上是**合法**的（如用户问的字段本就不存在），一刀切报 error 会误伤 |
| B6 | 空结果集没有专门语义 | 后端 `run_sql.py:31` 只发 `{"type":"result","data":[]}` | 追加 `meta:{"row_count":0}` 或新增 `type:"empty"` 事件，前端据此渲染带解释的空态 | 静默失败 1/3 | 低 |
| B7 | 步骤名三套命名并存 | 后端图节点名 `correct_sql`（`app/agent/graph.py:56`）、节点内 `step = "校正SQL"`（`app/agent/nodes/correct_sql.py:24`）、前端硬编码（`StepRail.tsx:29`） | 后端导出**唯一一份步骤清单**（常量或 `/api/steps` 端点），前端据此渲染或做一致性校验 | 前后端长期维护 | 低 |
| B8 | OpenAPI 中 200 响应声明为 `application/json`，实际是 `text/event-stream` | 实测 `http://127.0.0.1:8000/openapi.json`：`"responses": {"200": {"content": {"application/json": ...}}}`；根因是路由未声明 `response_class`/`responses=`（`app/api/routers/query_router.py:36-40`） | 补 `responses={200: {"content": {"text/event-stream": {}}}}` | 文档正确性、第三方客户端 | 低 |
| B9 | 流结束没有显式信号 | 后端生成器自然结束 | 发一条 `type:"done"`（或 `[DONE]` 哨兵），让前端能区分「正常结束」与「中途断流」 | 断流可观测性 | 低 |
| B10 | 前端 abort 后后端仍在跑，无取消协议 | 后端 `app/services/query_service.py:45-70` 无取消检查点 | 在节点边界检查 `await request.is_disconnected()` 或接收 `POST /api/query/{id}/cancel` | 资源浪费 | 中-高：LangGraph 图执行的中断需要额外机制，收益一般 |

---

## 6. 推断标注与验证方法

| 编号 | 推断 | 依据 | 验证方法（本次未执行） |
|---|---|---|---|
| V1 | 节点内异常会**穿透** `graph.astream` 并被后端 `except` 捕获，最终发出一条 `type:"error"` 事件 | 后端 `app/agent/nodes/run_sql.py:33-36` `raise`；后端 `app/services/query_service.py:67-70` 捕获后 yield error | 实测目录 §3.2 记录 10 题里 `type=error` 出现 **0 次**，说明该路径本次未被覆盖。可用一个必然失败的 SQL（如引用不存在的库）触发，观察是否出现 `type:error` 事件 |
| V2 | 前端 `abort()` 后后端生成器会在下一次 `yield` 时感知断连并被取消 | 后端 `query_service.py:61-66` 是 `async for` + `yield`，无断连检查点 | 前端点「停止」，同时在后端日志里观察节点是否继续执行到 `run_sql` |
| V3 | `message.status === "done"` 的消息同时代表「成功」「被取消」「后端未返回结果」三种语义 | 前端 `src/App.tsx:116`、`:138`、`:149` 三处都写 `"done"` | 纯代码可验证；产品上需定义第 4 个状态 |
| V4 | `data` 里的 `error_message` 行由 LLM 生成的伪 SQL 产生（伪 SQL 能过 `explain`） | 实测目录 :147、:156 + 后端 `grep -rn "error_message"` 零命中 | 需要一次能复现该降级路径的提问，并检查后端日志里的「生成的SQL」 |
| V5 | `Decimal` 之所以变成字符串，是因为 `default=str` 而不是 MySQL 驱动 | 后端 `query_service.py:66`；本地 `json.dumps([{'x': Decimal('10')}], default=str)` 实测输出 `[{"x": "10"}]`；`docker/mysql/dw.sql:199-200` 证实源列是 `INT`/`FLOAT` | 直接查 `SHOW CREATE TABLE fact_order` 确认列类型；或在后端加一行 `type(result[0])` 日志 |

---

## 7. 一句话收尾

**事件层契约是干净的（字段名、枚举值、12 个步骤名逐字对齐），问题全部集中在「语义层」**：后端把「失败」编码进数据内容、把 `Decimal` 编码成字符串、把「校验失败」编码成 `success`，前端则把「一切返回都当成功」「取消＝成功」「未知事件＝失败」。其中 **F1/F2/F3/F4/F6/F8/F9/F11 可以纯前端立刻修掉**，而 **B1/B2/B3/B4/B5 是必须后端配合才能根治的部分**；在 B1 落地前，F5 的启发式短路只能算止损。
