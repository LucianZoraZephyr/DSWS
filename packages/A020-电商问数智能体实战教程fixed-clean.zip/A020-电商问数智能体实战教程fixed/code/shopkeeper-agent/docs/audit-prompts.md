# 提示词契约审计报告（prompt ↔ 代码变量 ↔ 失效模式）

> **范围**：`code/shopkeeper-agent/prompts/*.prompt`（7 个）↔ `app/agent/nodes/*.py` 的 `PromptTemplate`/`ainvoke` 装配 ↔ 已实测的两个正确性缺陷。**日期**：2026-10-20。
> **性质**：**纯只读审计**，未修改任何 `app/`、`prompts/`、`conf/` 文件；唯一新增文件是本文件。**证据口径**：每条结论标注 `文件:行号` + 原文引用；无法从原文确证的标「待验证」并给验证方法。

## 0. 结论摘要（3 句）

1. **7 个提示词的占位符契约四方完全一致**（模板占位符 = 代码声明的 `input_variables` = `ainvoke` 实际传入键 = 磁盘文件占位符），但这个"一致"**没有运行时保障**——实测证明 langchain-core 1.2.28 会用模板自动探测结果**覆盖**节点里写的 `input_variables=[...]`，那 7 处声明是**死代码**，拼错也不报错。
2. **两个已实测缺陷都不是"要求写弱了"，而是"要求根本不存在"**：`ORDER BY`/`排序`/`LIMIT`/`Top` 在 7 个提示词里**总命中 0**，`拒绝`/`无法生成` 也**总命中 0**；`generate_sql.prompt:18` 的"禁止编造"只约束**表/字段名**不约束**结果列常量与 NULL 投影**，而 `correct_sql.prompt:30` 又禁止增删指标列，于是伪 SQL 一旦生成就"稳定"地穿过 `EXPLAIN` 校验并被当作数据行返回。
3. **提示词里 13 条在性质上可机器校验的隐式协议，代码层 10 条完全没实现**（排序、别名白名单、禁 NULL 投影、禁字面量 SELECT、拒答标记、只读 SQL、单条 SQL、无 Markdown、占位符校验…），全压在 LLM 的"听话程度"上；建议按 **R6 → R4+R5 → R7 → R3 → R2+R8 → R1 → R9** 顺序改，其中 **R3/R8/R9 是跨层改动**，会同时触达 `generate_sql.py`、`correct_sql.py`、`graph.py`、`state.py` 与前端。

## 1. 审计方法

- **占位符**：正则 `(?<!\{)\{([A-Za-z_][A-Za-z0-9_]*)\}(?!\})` 逐行扫描 `.prompt`，**排除 `{{`/`}}` 转义**。
- **代码声明**：`ast` 解析 `app/agent/nodes/*.py`，取 `PromptTemplate(template=load_prompt("X"), input_variables=[...])`。
- **实参键**：`ast` 遍历**所在函数**取 `chain.ainvoke({...})` 的 dict key 常量。⚠️ `ainvoke` 是 `PromptTemplate` 的**同级语句**而非嵌套调用（第一版脚本漏抽，已修正）。
- **运行时验证**：用 `langchain-core==1.2.28`（`uv.lock:819-820`）实跑构造与 `format()`，见 §2.3 四条实证。
- **交叉校验**：与仓库内既有工具 `docs/interface_count.py`（`docs/interface_count.py:78-82`）独立比对，结论一致。脚本在仓库外 `/tmp/opencode/`（`prompt_contract.py`、`verify_runtime_contract.py`），**未写入仓库**。

## 2. 提示词契约表

### 2.1 四方一致性总表

**A** = 模板占位符（`.prompt` 内 `{...}` 名字，不含 `{{`/`}}`）；**B** = 代码声明的 `input_variables`；**C** = `ainvoke` 实参键；**D** = 磁盘↔代码覆盖。

| # | 提示词文件 | A. 模板占位符（行号） | B. 代码声明 | C. `ainvoke` 实参键 | D. 覆盖 | **四方一致** |
|---|---|---|---|---|---|---|
| 1 | `prompts/generate_sql.prompt` | `table_infos`(L6)、`metric_infos`(L9)、`date_info`(L12)、`db_info`(L15)、`query`(L27) | `["table_infos","metric_infos","date_info","db_info","query"]`<br>`app/agent/nodes/generate_sql.py:37-43` | 同左 5 键<br>`generate_sql.py:50-61` | `load_prompt("generate_sql")`<br>`generate_sql.py:36` | ✅ 一致 |
| 2 | `prompts/correct_sql.prompt` | `table_infos`(L8)、`metric_infos`(L11)、`date_info`(L14)、`db_info`(L17)、`query`(L20)、`sql`(L23)、`error`(L26) | `["table_infos","metric_infos","date_info","db_info","query","sql","error"]`<br>`app/agent/nodes/correct_sql.py:41-49` | 同左 7 键<br>`correct_sql.py:56-69` | `load_prompt("correct_sql")`<br>`correct_sql.py:40` | ✅ 一致 |
| 3 | `prompts/filter_table_info.prompt` | `query`(L57)、`table_infos`(L60) | `["query","table_infos"]`<br>`app/agent/nodes/filter_table.py:34` | `query`、`table_infos`<br>`filter_table.py:42-47` | `load_prompt("filter_table_info")`<br>`filter_table.py:33` | ✅ 一致 |
| 4 | `prompts/filter_metric_info.prompt` | `query`(L77)、`metric_infos`(L80) | `["query","metric_infos"]`<br>`app/agent/nodes/filter_metric.py:34` | `query`、`metric_infos`<br>`filter_metric.py:42-47` | `load_prompt("filter_metric_info")`<br>`filter_metric.py:33` | ✅ 一致 |
| 5 | `prompts/extend_keywords_for_column_recall.prompt` | `query`(L56) | `["query"]`<br>`app/agent/nodes/recall_column.py:39` | `query`<br>`recall_column.py:46` | `load_prompt("extend_keywords_for_column_recall")`<br>`recall_column.py:38` | ✅ 一致 |
| 6 | `prompts/extend_keywords_for_metric_recall.prompt` | `query`(L53) | `["query"]`<br>`app/agent/nodes/recall_metric.py:39` | `query`<br>`recall_metric.py:46` | `load_prompt("extend_keywords_for_metric_recall")`<br>`recall_metric.py:38` | ✅ 一致 |
| 7 | `prompts/extend_keywords_for_value_recall.prompt` | `query`(L51) | `["query"]`<br>`app/agent/nodes/recall_value.py:39` | `query`<br>`recall_value.py:46` | `load_prompt("extend_keywords_for_value_recall")`<br>`recall_value.py:38` | ✅ 一致 |

**判定**：**少一个 / 多一个 / 拼写不同——一个都没有**，A/B/C 三集合两两完全相等（集合语义；声明列表的**书写顺序**与模板探测的**排序顺序**不同，见 §2.3）。**D**：磁盘 7 个 `.prompt` ↔ 代码 7 处 `load_prompt` 引用，**无孤儿文件、无悬空引用**。

### 2.2 各提示词的"非占位符"输出契约

| 提示词 | 输出形态 / 代码侧解析器 | 输出格式硬约束位置 |
|---|---|---|
| `generate_sql` / `correct_sql` | 纯文本 SQL；`StrOutputParser()` `generate_sql.py:46` / `correct_sql.py:52` | `generate_sql.prompt:24` / `correct_sql.prompt:38`「输出必须仅包含一条完整 SQL 语句的纯文本，严禁使用```、```sql 等 Markdown代码块」 |
| `filter_table_info` / `filter_metric_info` | JSON 对象（表名→字段数组）/ JSON 字符串数组；`JsonOutputParser()` `filter_table.py:37` / `filter_metric.py:37` | `filter_table_info.prompt:48-52`（`{{`/`}}` 为 f-string 转义）、`filter_metric_info.prompt:39-43`「允许输出空数组 []」；两者 LLM 只做"选择"，程序负责裁剪（`filter_table.py:50-58`）与过滤（`filter_metric.py:50-52`） |
| `extend_keywords_for_*_recall`（3 个） | JSON 字符串数组；`JsonOutputParser()` `recall_column.py:42` / `recall_metric.py:42` / `recall_value.py:42` | `…column_recall.prompt:35-39` / `…metric_recall.prompt:33-37` / `…value_recall.prompt:32-36`；结果并入 jieba 关键词分别做 Qdrant/ES 召回（`recall_*.py:49`） |

### 2.3 ⚠️ 关键发现：代码里的 `input_variables` 是**死代码**

langchain-core 1.2.28 源码 `langchain_core/prompts/prompt.py:129-136`：

```python
if values["template_format"]:
    values["input_variables"] = [
        var for var in get_template_variables(values["template"], values["template_format"])
        if var not in values["partial_variables"]
    ]
```

即构造时**用模板自动探测结果覆盖调用方传入的 `input_variables`**；且 `validate_template` 默认 `False`（`prompt.py:93-94`），**不做任何一致性校验**。四条实测：

| # | 场景 | 实测结果 |
|---|---|---|
| 1 | `PromptTemplate(template="hi {a} {b}", input_variables=["a"])` | **构造成功不报错**；实际 `input_variables` 被改成 `['a','b']` |
| 2 | `PromptTemplate(template="hi {a}", input_variables=["a","b"])` | **构造成功不报错**；多写的 `b` 被丢弃 |
| 3 | 声明写成 `["table_infos","metrc_infos","query"]`（拼错） | **静默忽略**，`'metrc_infos' in effective → False` |
| 4 | 模板占位符在 `ainvoke` 里**没有对应键** | `format()` 抛 `KeyError: 'query'` —— 硬失败（好事） |
| 5 | `ainvoke` 传了**模板里没有的多余键** | **静默忽略**，不影响输出 |

**对结论的影响**：① §2.1 的"B = 代码声明"这一列**对运行时零约束力**，真正的运行时契约只有 **A ↔ C** 两方；本项目 7/7 匹配 ✅，且第 4 条保证**一旦失配必然硬失败**（不会静默）。② 但**拼写错误不会被发现**（第 3 条）：今天 7 个节点没拼错是**人工纪律**保证的，不是工具保证的。③ **`{{`/`}}` 转义是必须的**：`filter_table_info.prompt:49-52` 的 JSON 花括号写成 `{{`/`}}`；实测若写单花括号，`string.Formatter` 会把 `"表名1"` 当字段名 → `KeyError: '"表名1"'`，当前写法正确 ✅。④ 另一佐证：`docs/interface_count.py:78-82` 用**另一套正则**（`r"\{([a-z_]+)\}"`）独立抽出的集合与本报告 A 列完全一致；`check_valid_template(template, "f-string", declared)` 对 7 个提示词全部返回 **VALID**。
## 3. 失效模式归因（已实测缺陷 → 具体提示词条目）

**证据来源**：排序/别名 → `docker/fixed-backend-report.md` §5.5/§5.6、`/home/zhensirong/VM-Share/ux-examples-catalog.md` #1/#8；伪 SQL → `ux-examples-catalog.md` #6/#7、`docker/fixed-backend-report.md` §5.1；静默失败清单 → `docs/OPTIMIZATION-BACKLOG.md:188-198`（§6）。

### 3.1 缺陷 A：中英文同义问法 → 别名不同 + 排序丢失

**实测事实**：中文题「统计 2025 年第一季度各大区的 GMV，并按 GMV 从高到低排序」→ 别名 `大区`、**带** `ORDER BY ... DESC`、行序 `华东 107373.0 → 华南 70202.0 → …`（`docker/fixed-backend-report.md` §4.3、`ux-examples-catalog.md` #1）；英文题 `GMV by region in Q1 2025` → 别名 `地区`、**不带** `ORDER BY`、行序变成 `华南 70202.0` 排在 `华东 107373.0` 之前（§5.6、`ux-examples-catalog.md` #8）。**数值 5 个大区完全一致**，只有别名与行序不同。

#### 归因 A-1（排序丢失）→ `generate_sql.prompt` 的【任务要求】**整块缺少排序条款**

**决定性证据**：对 7 个提示词全量检索，`ORDER BY`=**0**、`排序`=**0**、`LIMIT`=**0**、`Top`=**0**（总命中 0）。`prompts/generate_sql.prompt:17-24` 的【任务要求】共 7 条（L18–L24），**逐条核对"是否涉及行序"→ 全部 ❌**，原文如下：

| 行 | 原文（节选） | 涉及行序？ |
|---|---|---|
| L18 | `1. 仅允许使用数据表信息中真实存在的表与字段名称，禁止编造、猜测或引入未提供的表和字段。` | ❌ |
| L19 | `2. 若指标信息中存在相关指标定义，必须严格遵循其业务口径、计算逻辑、过滤规则与时间口径，不得偏离或重解释，…` | ❌ |
| L20–L22 | `3. 生成的SQL只能用于查询，不能涉及数据写入、更新、删除等操作。` / `4. 生成的SQL的语法必须严格符合数据库环境中指定的数据库类型与版本。` / `5. 默认只生成一条SQL，不可生成多条SQL。` | ❌ |
| L23 | `6. SELECT 中的聚合字段、计算字段和函数表达式必须使用 AS 指定清晰、稳定的结果列别名，…` | ❌ |
| L24 | `7. 输出必须仅包含一条完整 SQL 语句的纯文本，严禁使用```、```sql 等 Markdown代码块或任何格式化符号。` | ❌ |

**结论**：排序要求**根本不存在**。`ORDER BY` 是 LLM 读到问句里"按 GMV 从高到低排序"时**自发**加上的；英文问句无排序词，模型就没理由自发加 → "同语义不同问法 → 不同 SQL"**不是随机性，是提示词把排序决策完全外包给了模型的临场理解**。`docs/OPTIMIZATION-BACKLOG.md:196` 已点破：「同一问题每次 SQL 文本不同 | `temperature=0` 仍如此 | 差异来自**提示词约束不足**，不是采样随机性」。**第二层问题**：即使补上"有排序词必须 ORDER BY"，**无排序词的问法仍返回任意行序**——`GROUP BY` 无 `ORDER BY` 在 MySQL 里行序**不保证稳定**，这属"确定性缺失"，同样零条款覆盖。

#### 归因 A-2（别名漂移）→ `generate_sql.prompt:23` 第 6 条把别名写成"问法启发式"而非"白名单"

原文（`prompts/generate_sql.prompt:23`）：

> `6. SELECT 中的聚合字段、计算字段和函数表达式必须使用 AS 指定清晰、稳定的结果列别名，优先使用用户问题中的业务名称或指标名称，避免返回 `SUM(...)` 这类表达式列名。`

问题出在**"优先使用用户问题中的业务名称或指标名称"**这半句：它明确指示模型**从问句取别名**。于是中文问句含"各大区"→ 别名 `大区`；英文问句 `by region` → 模型回到中文列语义 → 别名 `地区`（`ux-examples-catalog.md` #8 结论 1：「英文问法**没有**产生英文别名——别名跟着『列的中文语义』走」）。**而白名单本来就在上下文里，只是提示词没用它** —— `conf/meta_config.yaml:21`：

```yaml
- name: region_name
  role: dimension
  description: 订单所属的大区名称，如华东、华南等。
  alias: [地区, 区域, 大区]
```

该 `alias` **已经喂给模型**：`app/agent/nodes/merge_retrieved_info.py:119`（`alias=column_info.alias`）、`:138`（`alias=retrieved_metric_info.alias`），再由 `generate_sql.py:52-54` 的 `yaml.dump(table_infos, ...)` 渲染进提示词。**这条规则 100% 可机器校验，却写成了纯人工启发式** —— "人工依赖 vs 可自动化"错配的最典型样本。

#### 归因 A-3（别名漂移在纠错环节无法修复）→ `correct_sql.prompt:29` + `:30`

- `:29`（第 1 条）`必须严格基于 SQL 执行错误信息进行修正，仅修复导致 SQL 无法执行或不符合数据库规范的问题，不得无依据重写 SQL 结构。`
- `:30`（第 2 条）`必须严格保持原始业务语义不变，不得擅自新增、删除或替换统计指标、统计维度、过滤条件或时间范围。`

两条合起来**禁止了校正节点修改别名或增删排序**。即使错误信息隐含"列名找不到"，校正节点也**无权**改别名 → **别名一致性必须在 `generate_sql` 一步就定死，事后无法补救**。

### 3.2 缺陷 B：字段召不到时 LLM 编造伪 SQL

**实测事实**（`ux-examples-catalog.md` #6/#7）：

- **B-1 纯字面量**：`SELECT '无法生成SQL：未提供可用数据表信息，且查询内容不明确' AS error_message;` → 1 行 1 列，表头就叫 `error_message`，**画面全绿**。
- **B-2 全 NULL 投影**：`SELECT customer_id, NULL AS 支付方式, NULL AS 支付方式占比 FROM fact_order GROUP BY customer_id;` → 20 行标准表，两列全是 `-`。

#### 归因 B-1（B-1 形态）→ `generate_sql.prompt:18` 的"禁止编造"**作用域太窄**，且**没有拒答契约**

原文（`prompts/generate_sql.prompt:18`）：

> `1. 仅允许使用数据表信息中真实存在的表与字段名称，禁止编造、猜测或引入未提供的表和字段。`

这条的**作用域是"表与字段名称"**。B-1 形态里模型：没引用任何不存在的表 ✅ 满足；没引用任何不存在的字段 ✅ 满足；只是 SELECT 了一个字符串字面量并起名 `error_message` → **不在规则约束范围内**。**换句话说：模型写 B-1 时是"合规"的。** 规则 1 禁的是"编造表字段"，B-1 的失败模式是"用一句说明冒充查询结果"——两者正交。

**"那它该怎么办"从没被回答过**：① 全量检索 7 个提示词：`拒绝`=**0**、`无法生成`=**0**，"上下文不足 / 无法作答 / 输出错误标记"一条都没有。② 唯一的 few-shot「返回空」示例在 `filter_metric_info.prompt:62-73`（示例二：`在职实习生有哪些？` → `[]`），**位于指标过滤节点，与 SQL 生成无关**；`generate_sql.prompt` 全文 29 行、**示例命中数 0**（`correct_sql.prompt` 同样为 0）。③ 代码侧**没有接收拒答的通道**：`generate_sql.py:46` `StrOutputParser()` → 任何文本都是"SQL" → `generate_sql.py:65` `return {"sql": result}` 直接写进 state。

#### 归因 B-2（伪 SQL 能"静默"跑完）→ 校验层只有 `EXPLAIN`，语义层零断言

| 步骤 | 位置 | 对 B-1 的行为 |
|---|---|---|
| 生成 | `generate_sql.py:65` | `state["sql"] = "SELECT '无法生成SQL：…' AS error_message;"` |
| 校验 | `validate_sql.py:32` → `dw_mysql_repository.py:46-49`（`sql = f"explain {sql}"` → `await self.session.execute(text(sql))`） | **语法完全合法 → EXPLAIN 通过 → `validate_sql.py:35` `return {"error": None}`** |
| 分支 | `graph.py:83-87`（`path=lambda state: "run_sql" if state["error"] is None else "correct_sql"`） | 走 `run_sql`，**`correct_sql` 根本不会被触发**（"自我修正"救不了它） |
| 执行 | `run_sql.py:28` → `dw_mysql_repository.py:51-53` | 真实执行，返回 1 行 `{'error_message': '无法生成SQL：…'}` |
| 出栈 | `run_sql.py:31` `writer({"type": "result", "data": result})` | 作为**正常结果**推给前端 |
| 前端 | `../shopkeeper-agent-frontend/src/App.tsx:113-120`（`if (event.type === "result") { … status: "done" … }`），错误分支在 `:122-128`（仅 `event.type === "error"` 触发） | 渲染成**正常表格**，无红色 |

**结论**：伪 SQL 的"静默"不是提示词的错，而是**校验层只有语法断言、没有语义断言**；提示词是**唯一**能提前拦下它的地方（代码层压根没有"这是不是一条真查询"的判据）。

#### 归因 B-3（B-2 形态）→ `generate_sql.prompt:23` 第 6 条**恰好被这条垃圾 SQL 满足**，且**无条款禁止常量投影**

对 `SELECT customer_id, NULL AS 支付方式, NULL AS 支付方式占比 FROM fact_order GROUP BY customer_id;` 逐条核对 7 条要求：**L18（只用真实表字段）未违反**（`customer_id`/`fact_order` 都真实存在；`支付方式` 是**结果列别名**不是字段引用）、**L19（指标口径）未涉及指标**、**L20（只读）未违反**、**L21（语法）未违反**、**L22（单条 SQL）未违反**、**L24（无 Markdown）未违反**——而 **L23（聚合/计算/函数字段必须 `AS` 清晰稳定别名）也未违反：`NULL AS 支付方式` 恰恰带了一个"清晰稳定"的 AS 别名！**

**7 条要求一条都没被违反，输出却是垃圾。** 归因非常精确：**第 6 条只约束"别名怎么起"，没约束"结果列从哪来"**——`NULL` 常量投影、字面量投影都不在规则射程内。叠加 `correct_sql.prompt` 侧：`:30`（第 2 条）禁止"擅自新增、删除或替换统计指标、统计维度、过滤条件" → **不能删掉** `NULL AS 支付方式` 两列；`:29`（第 1 条）"仅修复导致 SQL 无法执行…的问题" → `NULL AS 支付方式` **能正常执行**，不属于"错误"，不需要修。→ **伪 SQL 一旦生成，校正环节按规则必须原样保留。**

#### 归因 B-4（伪 SQL 的语义成因）→ `generate_sql.prompt:19` 的"通用业务常识"兜底

原文（`prompts/generate_sql.prompt:19`）：

> `2. 若指标信息中存在相关指标定义，必须严格遵循其业务口径、计算逻辑、过滤规则与时间口径，不得偏离或重解释，若指标信息未覆盖用户问题中的指标或口径，则基于用户问题语义与通用业务常识进行。`

后半句"通用业务常识"直接开口子：**上下文没覆盖时可以靠常识补**。而"支付方式"正是一个"常识里存在的电商字段名"。这条兜底**削弱了 L18 的封锁**，是 B-2 形态的语义温床。

#### 归因 B-5（上下文为空时提示词毫无提示）→ YAML 渲染出的是 `[]`

`generate_sql.py:52-59` 用 `yaml.dump(table_infos, ...)` 渲染上下文；实测 `yaml.dump([], allow_unicode=True, sort_keys=False)` → `'[]\n'`。模型看到的是 `可用数据表信息如下：` 紧跟 `[]` —— **`"[]"` 既不像"没有数据"也不像"合法输入"**，而提示词没有任何一句告诉模型"这里是空的必须拒答"。加上 §3.2 的 B-1 归因（无拒答契约），模型只好**自己发明一个错误消息**交差。

### 3.3 归因小结

| 已实测缺陷 | 直接归因的提示词条目（文件:行号） | 归因类型 | 缺失的条款 |
|---|---|---|---|
| 排序丢失 / 行序不稳定 | `generate_sql.prompt:17-24`（7 条全不涉及行序） | **条款缺失** | 无 "ORDER BY"/"LIMIT"/确定性行序要求（全库零命中） |
| 别名漂移 `大区`/`地区` | `generate_sql.prompt:23`（"优先使用用户问题中的业务名称"） | **规则方向错** | 无 "别名必须取自 `alias` 白名单"（白名单已在 `merge_retrieved_info.py:119` 喂进上下文） |
| 别名漂移事后无法修 | `correct_sql.prompt:29` + `:30` | **规则过严（反向封锁）** | 无 "允许在语义不变前提下统一别名/补排序" 的授权 |
| B-1 伪 SQL（字面量 SELECT） | `generate_sql.prompt:18`（作用域只到"表/字段名"）+ 全库无拒答条款 | **作用域太窄 + 条款缺失** | 无 "上下文不足必须拒答"、无固定拒答标记 |
| B-2 伪 SQL（NULL 投影） | `generate_sql.prompt:23`（被它**满足**）+ 无禁常量投影条款 | **条款缺失** | 无 "禁止 NULL/字面量作为结果列" |
| B-2 的语义温床 | `generate_sql.prompt:19`（"通用业务常识"兜底） | **规则相互削弱** | 兜底与 L18 冲突 |
| 伪 SQL 静默通过 | `generate_sql.prompt` 无结构化输出约束 + `generate_sql.py:46` `StrOutputParser` | **契约缺失（跨层）** | 无结构化输出协议（如 JSON `{sql, ok, reason}`） |
| 空上下文无提示 | `generate_sql.py:52-54` 渲染出 `[]` + `generate_sql.prompt:5-6` 无状态说明 | **上下文协议缺失** | 无 "可用表数量：0 ⇒ 必须拒答" 的机器生成标记 |
## 4. 提示词里的"隐式协议"清单：人工依赖 vs 可自动化

> 判据：**可自动化** = 存在纯函数 `f(提示词文本, 代码上下文, LLM 输出) → bool`，不依赖人对语义的理解。**"代码现状"**列是关键：❌ = 当前代码**没有任何一处**实现这条校验，全靠 LLM 自觉。

| # | 隐式协议（写给模型看的） | 出处（文件:行号） | 性质 | 机器可校验判据 | 代码现状 |
|---|---|---|---|---|---|
| P1 | 仅允许使用真实存在的表与字段 | `generate_sql.prompt:18`；`correct_sql.prompt:31` | **可自动化** | 解析 SQL 的表名/列名 ⊆ `state["table_infos"]` 的 `name`/`columns[].name` | ❌ |
| P2 | 只生成查询，不含写操作 | `generate_sql.prompt:20`；`correct_sql.prompt:35` | **可自动化** | 首关键字 ∈ {SELECT,SHOW,EXPLAIN,WITH}；全文无 `INSERT/UPDATE/DELETE/CREATE/DROP/ALTER/TRUNCATE` | ❌（`dw_mysql_repository.py:48` 只 `explain`，不拦写操作） |
| P3 | 只输出一条 SQL | `generate_sql.prompt:22`；`correct_sql.prompt:36` | **可自动化** | 语句分割后 statement 数 == 1 | ❌ |
| P4 | 禁止 Markdown 代码块 | `generate_sql.prompt:24`；`correct_sql.prompt:38` | **可自动化** | 输出中无 ```` ``` ```` 标记 | ❌ |
| P5 | 聚合/计算列必须有 AS 别名 | `generate_sql.prompt:23`；`correct_sql.prompt:37` | **可自动化** | 每个非平凡投影都有 `AS`，别名 ∉ {`SUM(...)` 等表达式原文} | ❌ |
| P6 | 别名必须稳定、可复现 | `generate_sql.prompt:23`（"清晰、稳定"） | **可自动化**（改造后） | 结果列别名 ⊆ 字段/指标的 `alias` 白名单（`conf/meta_config.yaml:21` 等） | ❌ |
| P7 | **必须确定性行序 / 排序** | **（缺失）** | **可自动化** | 问题含排序意图 ⇒ SQL 含 `ORDER BY`；聚合查询恒有 `ORDER BY` | ❌（条款本身也不存在） |
| P8 | **禁止常量 / NULL 结果列** | **（缺失）** | **可自动化** | 投影中无 `NULL`、无字符串字面量、无纯数字常量 | ❌ |
| P9 | **上下文不足必须拒答** | **（缺失）** | **可自动化** | `table_infos == []` ⇒ 输出必须是固定拒答标记，且不得是 SQL | ❌ |
| P10 | 语法符合数据库方言与版本 | `generate_sql.prompt:21`；`correct_sql.prompt:34` | 半自动 | `EXPLAIN` 能过（现有 `validate_sql.py:32`）+ 方言关键字白名单 | ⚠️ 部分（仅 EXPLAIN） |
| P11 | 必须严格遵循指标业务口径/计算逻辑/过滤规则/时间口径 | `generate_sql.prompt:19`；`correct_sql.prompt:32` | **人工依赖** | 需比对 `MetricInfoState.description` + `relevant_columns`（`state.py:17-24`）→ 语义级，无法机器判定"口径是否被偏离" | ❌ |
| P12 | 指标未覆盖时"基于用户问题语义与通用业务常识进行" | `generate_sql.prompt:19`（后半句） | **人工依赖**（且**危险**：与 P1 冲突） | 无法机器校验；建议直接删除（R5） | ❌ |
| P13 | 字段/指标"是否必需"是唯一选择标准 | `filter_table_info.prompt:26`；`filter_metric_info.prompt:17` | **人工依赖** | 需语义理解"本次查询会不会用到" | ❌ |
| P14 | 指标选择保持最小集合、不做兜底 | `filter_metric_info.prompt:26-28` | **人工依赖** | 无客观判据 | ❌ |
| P15 | 表选择"不做冗余保留，不做兜底保留" | `filter_table_info.prompt:15` | **人工依赖** | 无客观判据 | ❌ |
| P16 | 关键词/字段名必须是"稳定、抽象、可复用的业务概念" | `…column_recall.prompt:17`；`…metric_recall.prompt:17` | **人工依赖** | 无客观判据（只能靠召回率间接验证） | ❌ |
| P17 | 字段值必须来自用户问题本身的显式或隐含语义 | `…value_recall.prompt:22` | **人工依赖** | 可粗查"取值是否出现在 query 里"，但"隐含语义"无法判定 | ❌ |
| P18 | 输出仅 JSON / 纯文本，不带解释 | 5 个 JSON 提示词的"输出要求"段（见 §2.2） | **可自动化** | `JsonOutputParser` 已做（`recall_*.py:42`、`filter_*.py:37`）；SQL 侧无 | ⚠️ JSON 侧已有，SQL 侧无 |
| P19 | 占位符名称与实参键一一对应 | `.prompt` 全文 + `PromptTemplate(input_variables=…)` | **可自动化** | `get_template_variables` == `ainvoke` 键集合 | ❌（且 §2.3 证明声明是死代码） |
| P20 | `{{`/`}}` 转义正确 | `filter_table_info.prompt:49-52` | **可自动化** | `format()` 不抛 `KeyError` | ✅ 有效（构造时即验证） |

**统计**：20 条隐式协议 → **13 条可自动化**（P1–P10、P18–P20），其中 **P7/P8/P9 三条条款本身在提示词里就不存在**；**代码现状 ❌ = 10 条**、⚠️ = 2 条、✅ = 1 条。**7 条纯人工依赖**（P11–P17），其中 **P12 是"人工依赖里的反例"——它是一条不该存在的兜底**。

## 5. 改进建议（只提建议，不改代码）

### R1 · 补齐"排序 / Top-N / 确定性行序"条款
- **问题**：`generate_sql.prompt:17-24` 的 7 条**无一条涉及行序**；全库 `ORDER BY`/`排序`/`LIMIT`/`Top` 总命中 **0**。排序行为完全由模型临场决定（§3.1 A-1）。
- **建议改法**：`generate_sql.prompt`【任务要求】追加两条（插在 L22 之后保持编号连续）：① **意图驱动**：`若用户问题中包含排序、升序、降序、从高到低、从低到高、前 N 名、Top-N、排名等表述，必须生成对应的 ORDER BY 子句（升序 ASC、降序 DESC），且 Top-N 类问题必须同时带 LIMIT N。` ② **确定性兜底**：`若用户问题未指定排序且查询包含 GROUP BY 聚合，必须为结果给出确定性的 ORDER BY（建议按主度量列 DESC），以保证同一问题多次查询返回的行序一致。`
- **预期收益**：中/英文等价问法行序一致；"前 5 名"不再取错；`docs/OPTIMIZATION-BACKLOG.md:194` 闭环。
- **风险**：**中**。第 ② 条会改变**所有无排序问法**的返回行序（当前是 MySQL 任意行序），下游需回归；前端无"未指定排序"提示（`../shopkeeper-agent-frontend/src/App.tsx:113-120` 只渲染 `result`），行序变化用户可感知但不报错。
- **联动风险**：🔴 **高**。① 排序列名必须与 R2 的别名规则一致，否则 `ORDER BY` 引用不到别名；② `correct_sql.prompt` **必须同步**加同款条款（`correct_sql.prompt:30` 禁止"擅自新增…过滤条件"，不同步则校正轮不会补 `ORDER BY`）；③ `correct_sql.prompt:33`（"保持 SQL 结构尽量稳定"）与"补 ORDER BY"措辞冲突，需显式写"允许在语义不变前提下补齐 ORDER BY/LIMIT"。

### R2 · 别名规则从"问法启发式"改为"alias 白名单"
- **问题**：`generate_sql.prompt:23` 的"优先使用用户问题中的业务名称或指标名称"导致别名随问法漂移（`大区`/`地区`/`region_name`，`docker/fixed-backend-report.md` §5.5）。白名单（`conf/meta_config.yaml:21` `alias: [地区, 区域, 大区]`）**已经**通过 `merge_retrieved_info.py:119`/`:138` 喂进上下文，只是提示词没用它。
- **建议改法**：把 `generate_sql.prompt:23` 改写为 `6. SELECT 中的聚合字段、计算字段和函数表达式必须使用 AS 指定结果列别名。**别名必须从上下文该字段或该指标的 alias 列表中选取**；alias 列表为空时使用字段描述中的业务名。同一字段在所有问法下的别名必须完全一致，禁止随用户提问语言变化。`
- **预期收益**：别名稳定 → 下游可按列名取值（`docs/OPTIMIZATION-BACKLOG.md:195` 闭环）；P6 从人工依赖升级为可自动化。
- **风险**：**中**。用户问"城市"但底层是 `province` 时，别名会固定成"省份"，与用户预期不符——正是 `docker/fixed-backend-report.md` §5.7 的"语义错位"。**这是产品决策**：保口径（别名固定）还是保问法（别名随问法）。建议保口径 + 保留原问法映射。⚠️ 需产品确认后落地。
- **联动风险**：🔴 **高**。① `correct_sql.prompt:37`（第 9 条）是同款措辞，**必须同步改**，否则校正轮会把别名改回问法派生名；② `correct_sql.prompt:30` 禁止增删指标列，白名单改名可能被判为"替换统计指标"，需在该条加豁免；③ R1 的 `ORDER BY` 排序列名依赖 R2 的白名单，**R1 与 R2 必须一起改**；④ 前端 `ResultTable` 按列名取值处需确认。

### R3 · 建立"上下文不足必须拒答"的显式契约与机器可识别标记
- **问题**：伪 SQL 编造的根因（§3.2 B-1/B-2）。`generate_sql.prompt:18` 只禁"编造表字段"，**没有**"没有表可选时怎么办"；7 个提示词 `拒绝`=0。代码侧 `generate_sql.py:46` 的 `StrOutputParser()` 让任何文本成为 `state["sql"]`，`validate_sql.py:32` 的 `EXPLAIN` 对 `SELECT '…' AS error_message;` 判为合法 → `graph.py:85` 直接走 `run_sql` → `run_sql.py:31` 把错误当 `result` 推出 → 前端 `App.tsx:113-120` 渲染成绿表。
- **建议改法**：① **提示词侧**：`generate_sql.prompt` 与 `correct_sql.prompt` 各加一条 `若【可用数据表信息】为空，或所需字段在上下文中不存在，禁止编造任何 SQL；请仅输出一行固定标记 __NO_ANSWER__:<简短原因>`。② **代码侧（必须配套）**：`generate_sql.py`/`correct_sql.py` 在 `StrOutputParser` 后加检测——输出以 `__NO_ANSWER__` 开头则**不写** `state["sql"]`，改写 `state["error"]`（或新增 `state["no_answer"]`），由 `graph.py:83-88` 的条件边路由到显式失败分支。③ **前端侧**：该状态映射到 `type:"error"` 事件（现在只有 `error` 事件才有红色，`../shopkeeper-agent-frontend/src/App.tsx:122-128`）。
- **预期收益**：把"静默失败"从**数据行**变成**显式错误**；`docs/OPTIMIZATION-BACKLOG.md:193` 闭环。
- **风险**：🔴 **高**。**唯一必须跨层同时改**的建议：只改提示词不改代码 → `__NO_ANSWER__:<原因>` 会被 `EXPLAIN` 判为语法错误 → 进 `correct_sql` → 再被拒答 → 死循环或乱码入库；只改代码不改提示词 → 无效。`graph.py` 条件边与 `state.py:63-79` 都要加字段，属**接口面变更**。
- **联动风险**：🔴 **高**。牵动 `generate_sql.py`、`correct_sql.py`、`graph.py:83-88`、`app/agent/state.py:63-79`、`run_sql.py`、前端 `App.tsx`。**建议 R3 单独排期**，不与其它提示词改动混批（否则回归无法区分是"拒答变严"还是别的变了）。

### R4 · 增加"禁止常量 / NULL 结果列"条款
- **问题**：B-2 形态逐条核对 `generate_sql.prompt` 的 7 条要求，**一条都没违反**（尤其第 6 条被它"满足"）。根因是第 6 条只管"别名怎么起"，不管"结果列从哪来"（§3.2 B-3）。
- **建议改法**：`generate_sql.prompt` 增加 `禁止使用 NULL、字符串字面量或数字常量作为结果列；每一个结果列都必须来自上下文中真实存在的字段，或是对这些字段的聚合/计算表达式；若某项指标无法计算，则该列不得出现在结果中。`（`correct_sql.prompt` 同步增加，见联动）
- **预期收益**：堵住"20 行全 `-`"的静默失败（`ux-examples-catalog.md` #7，最慢的一题 47.2s——用户付 47 秒拿一张必然全空的表）。
- **风险 / 联动风险**：**低**（纯新增约束）。唯一顾虑：某些真实场景需要 `COALESCE(x, 0) AS y`——条款应写明"**函数包裹的**常量（如 `COALESCE(销售额, 0)`）仍允许，但裸 `NULL` 常量不允许"，否则误伤合法 SQL。联动 🟡 **中**：`correct_sql.prompt` 必须同步加同样条款，否则校正轮受 `correct_sql.prompt:29`（"仅修复导致 SQL 无法执行的问题"）与 `:30`（"不得擅自新增、删除…统计指标"）约束，**不会**清理已生成的 NULL 列 → B-2 形态一旦生成就永久留存。

### R5 · 删除 `generate_sql.prompt:19` 的"通用业务常识"兜底
- **问题**：`:19` 后半句"若指标信息未覆盖用户问题中的指标或口径，则基于用户问题语义与**通用业务常识**进行"，是 B-2 形态（编造"支付方式"字段）的语义温床，同时**削弱** `:18` 的"仅允许使用真实存在的表与字段"。
- **建议改法**：改为 `若指标信息未覆盖用户问题中的指标或口径，必须优先从【可用数据表信息】中寻找可映射的真实字段；确实无法映射时，按【任务要求】中的拒答条款输出，不得依赖通用业务常识推测字段或口径。`
- **预期收益**：关掉"靠常识补字段"这条路，从源头减少伪 SQL。
- **风险 / 联动风险**：🟡 **中**。收紧了召回失败时的兜底，**原本能"蒙对"的题可能变成拒答** → 必须与 R3 配套，否则用户会看到"以前能答现在答不了"；⚠️ 建议先按 `docs/OPTIMIZATION-BACKLOG.md:135-144` 的 10 题基线做前后对比。与 **R3 强耦合**（R3 不落地时这条会让部分可答题直接失败）；与 R1/R2 无耦合。

### R6 · 把 `input_variables` 从"死代码"变成真校验
- **问题**：§2.3 实测证明 langchain-core 1.2.28 会用模板自动探测结果**覆盖** `input_variables`（`langchain_core/prompts/prompt.py:129-136`），`validate_template` 默认 `False`（`:93-94`）。节点里那 7 处 `input_variables=[...]`（`generate_sql.py:37-43`、`correct_sql.py:41-49`、`filter_table.py:34`、`filter_metric.py:34`、`recall_column.py:39`、`recall_metric.py:39`、`recall_value.py:39`）**对运行时零影响**，拼错也不报错（实测 `metrc_infos` 被静默忽略）。今天 7/7 一致靠**人工纪律**。
- **建议改法**（三选一）：① **就地加固**——每个 `PromptTemplate(...)` 传 `validate_template=True`，构造时调 `check_valid_template` 做双向校验（实测 7 个提示词当前全部 VALID，加了不会炸；⚠️ mustache 模板不支持校验，本项目全是 f-string，无影响）；② **CI 化**——写契约检查脚本（比照 `docs/interface_count.py:78-82`，但用 langchain 的 `get_template_variables` 而非正则），断言"模板占位符集合 == `ainvoke` 实参键集合"，接进 `.pre-commit-config.yaml`；③ **直接删掉** `input_variables=[...]` 参数并在注释里写明"占位符以模板为准"，避免误导后来者以为它有约束力。
- **预期收益**：把"四方一致性"从人工约定变成**工具强制**；未来新增占位符漏传 key 会在构造时立刻炸，而不是等到线上。
- **风险**：**低**。方案 ① 需确认 `check_valid_template` 对 `{{`/`}}` 转义（`filter_table_info.prompt:49-52`）处理正确——已实测 VALID ✅。
- **联动风险**：🟢 **低**。7 个节点各加一个关键字参数；不改任何提示词文本、不改输出语义 → **零业务联动**。

### R7 · 给上下文为空加机器生成的显式状态标记
- **问题**：上下文用 `yaml.dump` 渲染（`generate_sql.py:52-54`/`:55-57`），空列表实测渲染成 `'[]\n'`。模型看到 `可用数据表信息如下：[]` 既不像"无数据"也不像"合法输入"，提示词也没说"这代表无法作答"（§3.2 B-5）。
- **建议改法**：在上下文段落前由**代码**插入状态说明（不写死在提示词里，避免与实际内容脱节），例如 `可用数据表数量：N（当 N=0 时，必须按【任务要求】的拒答条款输出 __NO_ANSWER__）`，同理给出"可用指标数量：M"；同时在 `generate_sql.prompt` 上下文段加一句 `以上数量由系统自动统计，若表数量为 0 表示没有任何可用数据表。`
- **预期收益**：显著提高 R3 的拒答契约被触发的概率——模型更容易识别"这是空上下文"而不是"这是格式怪异的 YAML"。
- **风险 / 联动风险**：**低**。⚠️ 副作用：提示词文本随上下文变化 → **同一问题的提示词不再恒定**，可能放大 LLM 输出抖动（`docs/OPTIMIZATION-BACKLOG.md:196` 已记录该现象）；建议**只在数量为 0 时**才追加该行，非空时不加，以保持提示词稳定。联动 🟡 **中**：与 **R3 强耦合**（这条是 R3 的触发器）；需同步改 `generate_sql.py` 与 `correct_sql.py` 两处；若采纳 R8 的 YAML 结构调整，改动点会重合。

### R8 · 把 `alias` 提升为上下文中显式的"可输出别名白名单"
- **问题**：别名白名单虽已在 YAML 里（`merge_retrieved_info.py:119`、`:138` 渲染 `alias=[地区, 区域, 大区]`），但它和 `name`/`description`/`examples` 混在一起，提示词没说"这就是合法的输出别名来源"。R2 若只改提示词不改上下文结构，模型仍可能忽略 alias 字段。
- **建议改法**：在 `ColumnInfoState`/`MetricInfoState`（`app/agent/state.py:27-36`、`:17-24`）增加显式字段（如 `output_aliases: list[str]`，默认取 `alias`），或在 YAML 渲染时把 `alias` 提升为显著键名（如 `可输出别名`），并让提示词明确引用它。
- **预期收益**：R2 的白名单规则有稳定的上下文锚点 → 可自动化校验 P6（结果列别名 ⊆ `output_aliases`）。
- **风险**：🟡 **中**。改 `state.py` 的 TypedDict 会牵动 `merge_retrieved_info.py:113-121`、`:133-141`、`generate_sql.py:52-59`、`correct_sql.py:58-66`，并**改变提示词文本** → 需用 10 题基线做前后对比（`docs/OPTIMIZATION-BACKLOG.md:135-144`）。
- **联动风险**：🔴 **高**。属**结构级**改动，同时触达 R1（排序列名）、R2（别名规则）、R7（上下文标记）三条建议 → **建议 R2 + R8 合并成一次改动落地**，避免提示词与上下文结构半改半留。

### R9 · 在校验层补"语义断言"，把可机检规则从提示词落到代码
- **问题**：§4 里 13 条可自动化协议，代码现状 10 条 ❌。唯一校验是 `validate_sql.py:32` → `dw_mysql_repository.py:46-49` 的 `explain {sql}`，**只验语法**。于是 P1（只用真表真字段）、P2（只读）、P3（单条 SQL）、P7（排序）、P8（禁 NULL）、P9（拒答）全部无保护。
- **建议改法**：在 `validate_sql` 之后（或其内部、EXPLAIN 前后）加**语义断言**步骤，至少断言 4 条：① 不是纯字面量 SELECT（投影里无常量）；② 投影中无裸 `NULL`；③ 若用户问题含排序意图则 SQL 必须含 `ORDER BY`（意图判定可用关键词表，与 `extract_keywords.py:27-40` 的 `allow_pos` 同源思路）；④ 结果列别名 ⊆ 字段/指标的 `alias` 白名单。断言失败时复用 `state["error"]` 通道，由 `graph.py:83-87` 导向 `correct_sql` 或直接失败。
- **预期收益**：**把"提示词依赖"降级为"提示词 + 断言"双保险**。这是唯一能真正兜住伪 SQL 的手段——`EXPLAIN` 结构上不可能发现"SELECT 一个字符串常量"是错的。
- **风险**：🟡 **中**。需新增 SQL 解析手段（`sqlparse`/`sqlglot`，或先用正则粗判）；断言 ③ 的"排序意图判定"本身会有漏判/误判。
- **联动风险**：🔴 **高**。要改 `graph.py`（新增节点或条件分支）、`app/agent/state.py`（新增断言结果字段）、`app/agent/nodes/validate_sql.py`；并与 R1/R2/R4/R7 的提示词改动**同批验证**（断言的存在会让原本"蒙对"的题开始报错）。**建议 R9 与 R1/R2/R4 一起做**，用 10 题基线逐行比对。

### R10 · 给 5 个 JSON 提示词补 JSON 清洗兜底（**待验证**）
- **问题**：3 个 `extend_keywords_*` 与 2 个 `filter_*` 都用 `JsonOutputParser`（`recall_*.py:42`、`filter_*.py:37`）。若模型在 JSON 前后附加说明文字，解析会失败 → 节点 `raise`（`recall_column.py:68-71`、`filter_table.py:66-69`）→ **整条问数链断裂**而非降级。
- **建议改法 / 预期收益**：在 `JsonOutputParser` 前加"提取第一个 `{...}`/`[...]` 片段"的清洗 Runnable，减少"模型多嘴一句话 → 整链失败"的脆弱点。
- **风险**：**低**。⚠️ **本条为「待验证」**：本轮**未实测**该场景（未调用真实 LLM）。**验证方法**：用同一 `deepseek-flash` 配置对 `filter_table_info.prompt` 连续请求 20 次，统计 `JsonOutputParser` 失败率；或构造带前后缀文本的样例喂给 parser 观察行为。成本 ≈ 20 次 LLM 调用。
- **联动风险**：🟢 **低**。只影响 5 个召回/过滤节点，不触及 SQL 生成链。

## 6. 实施顺序与联动矩阵

| 批次 | 建议 | 联动 | 提示词改动 | 代码改动 | 前端 | 说明 |
|---|---|---|---|---|---|---|
| **0** | **R6** | 🟢 低 | 无 | 7 个节点加 `validate_template=True` 或删死代码 | 无 | 先把"契约一致性"变成工具强制，再动内容；零业务风险 |
| **1** | **R4** + **R5** | 🟡 中 | `generate_sql` + `correct_sql` | 无 | 无 | 堵常量投影与"通用常识"兜底；R5 必须与 R3 同批否则误伤 |
| **2** | **R7** | 🟡 中 | `generate_sql` + `correct_sql` | `generate_sql.py` / `correct_sql.py` | 无 | R3 的触发器，须先于/同批 R3 |
| **3** | **R3** | 🔴 高 | `generate_sql` + `correct_sql` | `generate_sql.py` / `correct_sql.py` / `graph.py` / `state.py` | ✅ `App.tsx` | **单独排期**，不与其它批次混做 |
| **4** | **R2** + **R8** | 🔴 高 | `generate_sql` + `correct_sql` | `state.py` / `merge_retrieved_info.py` / `generate_sql.py` / `correct_sql.py` | ⚠️ `ResultTable` 取值确认 | R1 与 R2 必须同批（R1 排序列名依赖 R2） |
| **5** | **R1** | 🔴 高 | `generate_sql` + `correct_sql` | 无 | ⚠️ 行序变化 | 与批次 4 同批 |
| **6** | **R9** | 🔴 高 | 无（消费前序批次的提示词） | `graph.py` / `state.py` / `validate_sql.py` | ⚠️ 失败态呈现 | 与批次 1/4/5 同批验证 |
| **7** | **R10** | 🟢 低 | 无 | 5 个召回/过滤节点 | 无 | 需先做 20 次 LLM 验证 |

**联动矩阵（哪些建议会同时影响其它提示词）**：`prompts/generate_sql.prompt` ← R1 R2 R3 R4 R5 R7（主力战场，6 条建议都改它）；`prompts/correct_sql.prompt` ← R1 R2 R3 R4 R7（**必须与 `generate_sql.prompt` 同步改**，否则校正轮会按 `correct_sql.prompt:29`/`:30` 把前者改回去或拒绝修正）；`prompts/filter_table_info.prompt` / `filter_metric_info.prompt` / `extend_keywords_for_*.prompt` ← R10（仅解析健壮性）。**单点改动、零提示词联动**的只有 **R6** 与 **R10**（都只改代码）。

## 7. 待验证清单

- **V1 · 补 ORDER BY 条款后中/英文等价问法行序是否收敛**（本轮无结论：需改提示词并打真实 LLM，约束禁止）→ 改后用 `docs/hotpath_probe.py --repeat 5` 跑中英文同义题各 5 次比对行序；成本 10 次 LLM 往返。
- **V2 · `__NO_ANSWER__` 标记在 `correct_sql` 环节是否触发死循环**（本轮无结论：需改代码 + 打真实 LLM）→ 单测：让 `generate_sql` 返回 `__NO_ANSWER__`，观察 `graph.py:83-87` 是否回到 `generate_sql`；成本为纯本地单测，不打 LLM。
- **V3 · 5 个 JSON 提示词的解析失败率**（R10 的前提；本轮不打真实 LLM）→ 同配置连续 20 次请求，统计 `JsonOutputParser` 异常率；成本 20 次 LLM 调用。
- **V4 · 补"上下文数量标记"（R7）是否放大提示词文本抖动**（需实测）→ 同一问题重复 5 次比对生成 SQL 文本是否稳定；成本 5 次 LLM 往返。
- **V5 · `alias` 白名单与用户问法的语义冲突率**（如问"城市"得"省份"；需产品定义 + 实测）→ 10 题基线逐题核对别名与问法；成本 10 次 LLM 往返。

## 8. 审计边界声明

- **只读**：本轮**未修改**任何 `app/`、`prompts/`、`conf/` 或其它源码/提示词文件；唯一新建文件是 `docs/audit-prompts.md`。
- **未执行**：`docker`、`sudo`、改 `/etc/docker/daemon.json`、**未运行 `docs/hotpath_probe.py`**（会打真实 LLM）、**未请求 `POST /api/query`**。
- **未使用 curl**：全部结论可由仓库内文件离线确证，**未消耗**那 2 次只读 `curl` 配额。**验证脚本**：`/tmp/opencode/prompt_contract.py`（纯标准库）、`/tmp/opencode/verify_runtime_contract.py`（需 `langchain-core==1.2.28`，复现可用 `/home/zhensirong/VM-Share/.backend-run/venv/bin/python`）——均在仓库外。
- **交叉校验**：§2.1 的占位符集合与仓库内既有工具 `docs/interface_count.py` 输出**独立一致**；§2.3 的运行时行为与 langchain-core 源码 `langchain_core/prompts/prompt.py:93-94, 129-136` 一致。**未覆盖**：`app/services/`、`app/repositories/` 的业务逻辑细节（非本任务范围）；前端仅在"静默失败放大链路"处引用，未做前端审计。
