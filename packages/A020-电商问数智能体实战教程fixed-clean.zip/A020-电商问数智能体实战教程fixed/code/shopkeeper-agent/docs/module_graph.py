#!/usr/bin/env python3
"""module_graph.py —— 模块依赖图 + 依赖契约检查（只读，不改任何代码）

用途：看清"这个项目里哪些模块互相依赖"，并**机器校验**分层边界有没有被破坏。

    python3 docs/module_graph.py                 # 打印报告
    python3 docs/module_graph.py --write         # 同时生成 docs/module-graph.dot / .mmd
    python3 docs/module_graph.py --json          # 机器可读

只用标准库（ast），不需要装任何东西。
"""
from __future__ import annotations

import argparse
import ast
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PKG = "app"

# ---------------------------------------------------------------- 分层定义
# 越靠前越靠近入口，依赖只能从上往下（反向=违规）
LAYERS: list[tuple[str, tuple[str, ...]]] = [
    ("entry",     ("main",)),
    ("api",       ("app.api",)),
    ("services",  ("app.services",)),
    ("agent",     ("app.agent",)),
    ("support",   ("app.prompt", "app.conf", "app.entities", "app.core")),
    ("repo",      ("app.repositories",)),
    ("client",    ("app.clients",)),
    ("data",      ("app.models", "app.scripts")),
]
LAYER_INDEX = {name: i for i, (name, _) in enumerate(LAYERS)}


def layer_of(mod: str) -> str:
    for name, prefixes in LAYERS:
        for p in prefixes:
            if mod == p or mod.startswith(p + "."):
                return name
    return "external"


# ---------------------------------------------------------------- 契约规则
# 每条规则： (编号, 说明, 违规判定)
# 违规判定收到 (src_mod, dst_mod) 上，返回 True 表示违规
def _is_under(mod: str, prefix: str) -> bool:
    return mod == prefix or mod.startswith(prefix + ".")


def build_contracts() -> list[tuple[str, str, callable]]:
    return [
        ("C1", "agent 节点不得在运行期直接 import 仓储/客户端（必须走 runtime.context 注入）",
         lambda s, d, kind: layer_of(s) == "agent" and "nodes" in s
         and (layer_of(d) in ("repo", "client")) and kind != "type-only"),

        ("C2", "api 层不得直接 import agent 内部（应经 services 中转）",
         lambda s, d, kind: layer_of(s) == "api" and layer_of(d) == "agent"),

        ("C3", "仓储层不得反向依赖 agent / services / api",
         lambda s, d, kind: layer_of(s) == "repo" and layer_of(d) in ("agent", "services", "api")),

        ("C4", "领域实体（entities）不得依赖 ORM / 仓储",
         lambda s, d, kind: layer_of(s) == "support" and s.startswith("app.entities")
         and (layer_of(d) in ("data", "repo"))),

        ("C5", "core 不得依赖上层模块（读 conf 配置、同包引用除外）",
         lambda s, d, kind: layer_of(s) == "support" and s.startswith("app.core")
         and layer_of(d) in ("entry", "api", "services", "agent", "repo", "data")
         and not d.startswith("app.core")),

        ("C6", "同层节点之间不得互相 import（避免横向耦合）",
         lambda s, d, kind: layer_of(s) == layer_of(d) and layer_of(s) != "external"
         and _is_under(s, "app.agent.nodes") and _is_under(d, "app.agent.nodes")),
    ]


# ---------------------------------------------------------------- 采集
def module_name(path: Path) -> str:
    rel = path.relative_to(ROOT).with_suffix("")
    parts = list(rel.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def collect_modules() -> dict[str, Path]:
    mods: dict[str, Path] = {}
    for p in [ROOT / "main.py", *sorted((ROOT / PKG).rglob("*.py"))]:
        if "__pycache__" in p.parts:
            continue
        mods[module_name(p)] = p
    return mods


def _collect_names(tree: ast.AST) -> tuple[set[str], set[str]]:
    """返回 (仅在注解中出现的名字, 运行期真正使用的名字)。"""
    ann: set[str] = set()
    run: set[str] = set()

    def add(sub: ast.AST | None):
        if sub is None:
            return
        for n in ast.walk(sub):
            if isinstance(n, ast.Name):
                ann.add(n.id)

    class V(ast.NodeVisitor):
        def visit_AnnAssign(self, node):
            add(node.annotation)
            if node.value is not None:
                self.visit(node.value)

        def visit_arg(self, node):
            add(node.annotation)

        def visit_FunctionDef(self, node):
            add(node.returns)
            for d in node.decorator_list:
                self.visit(d)
            args = node.args
            for a in list(args.posonlyargs) + list(args.args) + list(args.kwonlyargs):
                self.visit(a)
            for d in list(args.defaults) + [x for x in args.kw_defaults if x]:
                self.visit(d)
            for st in node.body:
                self.visit(st)

        def visit_AsyncFunctionDef(self, node):
            self.visit_FunctionDef(node)

        def visit_Name(self, node):
            if isinstance(node.ctx, ast.Load):
                run.add(node.id)

    V().visit(tree)
    return ann, run


def parse_imports(path: Path, mod: str, known: set[str]) -> dict[str, str]:
    """返回 {内部模块: 导入性质}，性质 ∈ {runtime, type-only}。

    type-only = 该导入的名字只出现在类型注解里（不产生运行期耦合）。
    """
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as e:
        print(f"  ⚠ 解析失败 {path}: {e}", file=sys.stderr)
        return {}

    ann_names, run_names = _collect_names(tree)
    out: dict[str, str] = {}

    def kind_of(binding: str) -> str:
        return "type-only" if (binding in ann_names and binding not in run_names) else "runtime"

    def add_edge(dst: str, binding: str):
        k = kind_of(binding)
        if dst not in out or k == "runtime":
            out[dst] = k

    def resolve_relative(level: int, node: ast.AST | None) -> str:
        pkg = mod.split(".")
        if not pkg or pkg[-1] == "__init__":
            pkg = pkg[:-1]
        base = pkg[: len(pkg) - level] if level else pkg
        if node is not None:
            base = base + [a.name for a in node.names]
        return ".".join(base)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name in known:
                    add_edge(a.name, a.name.split(".")[0])
                else:
                    for m in known:
                        if m.startswith(a.name + "."):
                            add_edge(m, a.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                base = resolve_relative(node.level, None)
                if base in known:
                    add_edge(base, base.split(".")[-1])
                for m in known:
                    if m.startswith(base + "."):
                        add_edge(m, base.split(".")[-1])
                for a in node.names:
                    child = f"{base}.{a.name}" if base else a.name
                    if child in known:
                        add_edge(child, a.asname or a.name)
            elif node.module:
                if node.module in known:
                    add_edge(node.module, (node.names[0].asname or node.names[0].name) if node.names else node.module.split(".")[-1])
                for m in known:
                    if m.startswith(node.module + "."):
                        add_edge(m, (node.names[0].asname or node.names[0].name) if node.names else m.split(".")[-1])
                for a in node.names:
                    child = f"{node.module}.{a.name}"
                    if child in known:
                        add_edge(child, a.asname or a.name)
    return out


def find_cycles(graph: dict[str, set[str]]) -> list[list[str]]:
    """DFS 找有向环（返回环路径列表）。"""
    cycles: list[list[str]] = []
    seen_stack: list[str] = []
    on_stack: set[str] = set()
    done: set[str] = set()

    def dfs(n: str):
        if n in on_stack:
            i = seen_stack.index(n)
            cycles.append(seen_stack[i:] + [n])
            return
        if n in done:
            return
        seen_stack.append(n)
        on_stack.add(n)
        for m in sorted(graph.get(n, ())):
            dfs(m)
        seen_stack.pop()
        on_stack.discard(n)
        done.add(n)

    for n in sorted(graph):
        dfs(n)
    # 去重
    uniq = []
    seen = set()
    for c in cycles:
        key = tuple(sorted(set(c)))
        if key not in seen:
            seen.add(key)
            uniq.append(c)
    return uniq


# ---------------------------------------------------------------- 输出
def to_dot(graph, layers, edges=None) -> str:
    edges = edges or {}
    lines = ["digraph modules {", "  rankdir=LR;",
             '  node [shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10];',
             '  edge [color="#999999", arrowsize=0.6];']
    color = {"entry": "#c8e6c9", "api": "#bbdefb", "services": "#b3e5fc", "agent": "#ffe0b2",
             "support": "#e1bee7", "repo": "#f8bbd0", "client": "#d7ccc8", "data": "#cfd8dc",
             "external": "#eeeeee"}
    for layer, _ in LAYERS:
        members = sorted(m for m in graph if layer_of(m) == layer)
        if not members:
            continue
        lines.append(f"  subgraph cluster_{layer} {{")
        lines.append(f'    label="{layer}"; style="dashed"; color="#bbbbbb";')
        for m in members:
            lines.append(f'    "{m}" [fillcolor="{color[layer]}"];')
        lines.append("  }")
    for src in sorted(graph):
        for dst in sorted(graph[src]):
            if layer_of(dst) == "external":
                continue
            kind = edges.get(src, {}).get(dst, "runtime")
            # 仅类型注解引用 = 无运行期耦合，画成虚线
            style = ' [style=dashed, color="#bbbbbb"]' if kind == "type-only" else ""
            lines.append(f'  "{src}" -> "{dst}"{style};')
    lines.append("}")
    return "\n".join(lines)


def to_mermaid(graph) -> str:
    lines = ["```mermaid", "graph LR"]
    for src in sorted(graph):
        for dst in sorted(graph[src]):
            if layer_of(dst) == "external":
                continue
            lines.append(f"  {src.replace('.', '_')} --> {dst.replace('.', '_')}")
    lines.append("```")
    return "\n".join(lines)


def explain_module(target: str, mods, edges, graph, external, cycles, violations) -> int:
    """查一个模块：在哪、依赖谁、被谁依赖、契约判定。"""
    if target not in mods:
        cands = sorted(m for m in mods if m.endswith("." + target) or target in m)
        if len(cands) == 1:
            target = cands[0]
        elif cands:
            print(f"「{target}」匹配到 {len(cands)} 个模块，请写得更具体：")
            for c in cands:
                print(f"   {c}")
            return 2
        else:
            print(f"找不到模块「{target}」。用 --list 看全部模块。")
            return 2

    path = mods[target]
    upstream = sorted(d for d in graph[target] if layer_of(d) != "external")
    downstream = sorted(s for s, dd in edges.items() if target in dd)

    print("=" * 78)
    print(f"模块  {target}")
    print(f"位置  {path.relative_to(ROOT)}   （{len(path.read_text(encoding='utf-8').splitlines())} 行）")
    print(f"层    {layer_of(target)}")
    print("=" * 78)

    print(f"\n它依赖（出边 {len(upstream)} 个）：")
    if upstream:
        for d in upstream:
            k = edges[target][d]
            mark = "  type-only" if k == "type-only" else ""
            print(f"  → {d:<50} [{layer_of(d):<8}]{mark}")
    else:
        print("  （无内部依赖）")

    print(f"\n谁依赖它（入边 {len(downstream)} 个）：")
    if downstream:
        for s in downstream:
            k = edges[s][target]
            mark = "  type-only" if k == "type-only" else ""
            print(f"  ← {s:<50} [{layer_of(s):<8}]{mark}")
    else:
        print("  （无人依赖它）")

    ext = sorted(external.get(target, ()))
    if ext:
        print(f"\n第三方依赖：{', '.join(ext)}")

    in_cycles = [c for c in cycles if target in c]
    if in_cycles:
        print("\n循环依赖：")
        for c in in_cycles:
            print("  ✘ " + " → ".join(c))

    print("\n契约判定：")
    rel = [v for v in violations if v[2] == target or v[3] == target]
    if not rel:
        print("  ✔ 本模块未触发任何契约")
    for cid, desc, s, d in rel:
        print(f"  ✘ {cid} {desc}")
        print(f"     {s} → {d}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="模块依赖图 + 依赖契约检查")
    ap.add_argument("--write", action="store_true", help="生成 docs/module-graph.dot 与 .mmd")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--list", action="store_true", help="按层列出全部模块及其文件位置")
    ap.add_argument("--explain", metavar="MODULE", help="查某个模块：在哪、依赖谁、被谁依赖")
    args = ap.parse_args()

    mods = collect_modules()
    known = set(mods)
    edges: dict[str, dict[str, str]] = {m: parse_imports(p, m, known) for m, p in mods.items()}
    graph: dict[str, set[str]] = {m: set(d) for m, d in edges.items()}

    # 外部依赖
    external: dict[str, set[str]] = {}
    for m, p in mods.items():
        try:
            tree = ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        ext = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    top = a.name.split(".")[0]
                    if top not in ("app", "main") and top not in known:
                        ext.add(top)
            elif isinstance(node, ast.ImportFrom) and not node.level and node.module:
                top = node.module.split(".")[0]
                if top not in ("app", "main") and top not in known:
                    ext.add(top)
        external[m] = ext

    cycles = find_cycles(graph)
    contracts = build_contracts()
    violations = []
    advisories = []
    for cid, desc, rule in contracts:
        for src in sorted(graph):
            for dst in sorted(graph[src]):
                kind = edges[src][dst]
                if rule(src, dst, kind):
                    violations.append((cid, desc, src, dst))

    # 仅注解使用的跨层依赖（不产生运行期耦合，但建议改成 TYPE_CHECKING）
    advisories = sorted(
        (s, d) for s, dd in edges.items() for d, k in dd.items()
        if k == "type-only" and layer_of(s) == "agent" and "nodes" in s
        and layer_of(d) in ("repo", "client")
    )
    type_only_edges = sorted(
        (s, d) for s, dd in edges.items() for d, k in dd.items() if k == "type-only"
    )

    fan_out = {m: len({d for d in graph[m] if layer_of(d) != "external"}) for m in graph}
    fan_in: dict[str, int] = defaultdict(int)
    for m, deps in graph.items():
        for d in deps:
            if layer_of(d) != "external":
                fan_in[d] += 1

    if args.json:
        print(json.dumps({
            "modules": len(graph),
            "edges": sum(fan_out.values()),
            "cycles": cycles,
            "violations": [{"id": c, "desc": d, "src": s, "dst": t} for c, d, s, t in violations],
            "fan_out": fan_out, "fan_in": dict(fan_in),
            "external": {k: sorted(v) for k, v in external.items() if v},
        }, ensure_ascii=False, indent=2))
        return 0

    if args.explain:
        return explain_module(args.explain, mods, edges, graph, external, cycles, violations)

    if args.list:
        print("=" * 92)
        print(f"全部内部模块（共 {len(graph)} 个）")
        print("=" * 92)
        for layer, _ in LAYERS:
            members = sorted(m for m in graph if layer_of(m) == layer)
            if not members:
                continue
            print(f"\n【{layer}】{len(members)} 个")
            for m in members:
                p = mods[m]
                rel = p.relative_to(ROOT)
                kind = "（包）" if p.name == "__init__.py" else ""
                print(f"  {m:<52} {rel}{kind}")
        return 0

    print("=" * 78)
    print(f"内部模块 {len(graph)} 个 · 内部依赖边 {sum(fan_out.values())} 条")
    print("=" * 78)
    print("\n各层模块数：")
    for layer, _ in LAYERS:
        n = sum(1 for m in graph if layer_of(m) == layer)
        if n:
            print(f"  {layer:<9} {n:>3}")
    print("\n依赖最多的模块（fan-out 内部）：")
    for m, n in sorted(fan_out.items(), key=lambda kv: -kv[1])[:8]:
        if n:
            print(f"  {n:>3}  {m}")
    print("\n被依赖最多的模块（fan-in）：")
    for m, n in sorted(fan_in.items(), key=lambda kv: -kv[1])[:8]:
        if n:
            print(f"  {n:>3}  {m}")

    print("\n依赖契约检查：")
    for cid, desc, _ in contracts:
        bad = [v for v in violations if v[0] == cid]
        mark = "✔ 通过" if not bad else f"✘ {len(bad)} 处违规"
        print(f"  {mark:<12} {cid}  {desc}")
        for _, _, s, d in bad[:6]:
            print(f"                 {s}  →  {d}")

    print("\n循环依赖：")
    if cycles:
        for c in cycles[:5]:
            print("  ✘ " + " → ".join(c))
    else:
        print("  ✔ 无")

    if advisories:
        print("\n提示（仅类型注解引用，不产生运行期耦合，但建议改成 TYPE_CHECKING）：")
        for s, d in advisories:
            print(f"  · {s}  →  {d}   (type-only)")
    if type_only_edges:
        print(f"\ntype-only 依赖共 {len(type_only_edges)} 条（仅用于类型标注）")

    ext_pkgs = sorted({p for v in external.values() for p in v})
    print(f"\n第三方依赖（{len(ext_pkgs)} 个）：{', '.join(ext_pkgs)}")

    if args.write:
        (ROOT / "docs" / "module-graph.dot").write_text(to_dot(graph, LAYERS, edges), encoding="utf-8")
        (ROOT / "docs" / "module-graph.mmd").write_text(to_mermaid(graph), encoding="utf-8")
        print(f"\n已写出：docs/module-graph.dot · docs/module-graph.mmd")

    return 1 if (violations or cycles) else 0


if __name__ == "__main__":
    raise SystemExit(main())
