# SQL 生成 / 校验 / 校正 链路审计

> 审计对象：`code/shopkeeper-agent`（电商问数 Agent）｜审计日期：2026-10-20｜性质：**只读审计**
> 未修改任何源码/配置/提示词；未执行 `docker`/`sudo`；未调用 `/api/query`（不打真实 LLM）；仅用 **1 次只读 `curl`**（`:8000/docs` → 200）。
> 其余结论来自**源码原文** + **对运行中 MySQL 的只读探针**（只跑 `EXPLAIN`/`SELECT`；探针表已全部删除，
> `fact_order` 复核仍 115 行，`dw` 库已恢复原始 5 张表）。

## 0. 结论摘要（按严重度）

- **D1（致命）** 校正分支实质是死代码：`EXPLAIN` 只查语法与表/列名，而 LLM 的实际错误（语义）恰好是 `EXPLAIN` 看不见的 —— 校验层与真实错误**完全错位**（§3.1）
- **D2（高）** 校正后不重新校验：修正后的 SQL 直接进 `run_sql`，无二次校验、无回退（`graph.py:88`）
- **D3（高）** 「校验SQL」永远绿勾：成功/失败两条分支都写 `status:"success"`（`validate_sql.py:33`/`:39`）
- **D4（中）** 「校正SQL」永远 pending：前端硬编码 12 节点，`statusFor()` 取不到即 `pending`（`StepRail.tsx:29`/`:63-64`）
- **D5（中）** `state["error"]` 残留：校正后 `error` 不被清空（`correct_sql.py:74`）
- **D6（高·安全）** 多语句载荷绕过校验 + `EXPLAIN` 不拦写语句：第二句照常执行（DDL 自动提交）（§3.6）
- **D7（中）** 原始 SQL 被丢弃：校正失败无回退，用户直接吃裸 DB 报错（§3.7）
- **D8（低·已澄清）** `correct_sql` **不可能**无限循环（图是 DAG）；`recursion_limit` 未显式配置但永远用不上（§3.8）
- **D9（低）** `error` 标注为 `str` 实际写入 `None`；state 无该键时条件边 `KeyError`（`state.py:79`）

**一句话**：这条链路目前是「**生成 → 假校验 → 执行**」，自我修正环节在真实负载下从不触发；用户看到的全是绿勾。

---

## 1. 链路规格说明

| 步骤 | 代码位置 | 读 state | 写 state | progress 事件 | 异常如何处理 |
|---|---|---|---|---|---|
| `generate_sql` | `app/agent/nodes/generate_sql.py:20-70` | `table_infos`(:29)、`metric_infos`(:30)、`date_info`(:31)、`db_info`(:32)、`query`(:33) | `{"sql": result}`(:65) | `running`(:25)→`success`(:64)；异常 `error`(:69) | `except`→写 `error`→`raise`(:70)，**整图中断** |
| `validate_sql` | `app/agent/nodes/validate_sql.py:16-45` | `sql`(:25)；仓储取自 `runtime.context["dw_mysql_repository"]`(:28) | `{"error": None}`(:35) 或 `{"error": str(e)}`(:40) | `running`(:21)→**成功失败都写 `success`**(:33/:39)；外层异常 `error`(:44) | 内层 `except`(:36) **吞掉**异常写进 state；外层 `except`(:42) `raise`(:45) |
| **条件边** | `app/agent/graph.py:83-87` | `state["error"]`(:85) | —（不写 state） | — | 读不到 `error` 键 → `KeyError`（实测） |
| `correct_sql` | `app/agent/nodes/correct_sql.py:20-78` | `table_infos`(:29)、`metric_infos`(:30)、`date_info`(:31)、`db_info`(:32)、`query`(:33)、`sql`(:36)、`error`(:37) | `{"sql": result}`(:74) —— **不写 `error`** | `running`(:25)→`success`(:73)；异常 `error`(:77) | `except`→写 `error`→`raise`(:78)，整图中断 |
| `run_sql` | `app/agent/nodes/run_sql.py:15-36` | `sql`(:24)；仓储取自 `runtime.context["dw_mysql_repository"]`(:25) | **不写任何 state**（无 `return`） | `running`(:20)→`success`(:30)→`{"type":"result","data":result}`(:31)；异常 `error`(:35) | `except`→写 `error`→`raise`(:36) |
| **SSE 封装** | `app/services/query_service.py:61-70` | — | — | 逐条 `data: {...}`(:66) | 图抛异常→捕获→发 `{"type":"error","message":...}`(:69-70) |
| **路由** | `app/api/routers/query_router.py:31-35` | — | — | `media_type="text/event-stream"`(:34) | — |

**校验的真正实现** —— `app/repositories/mysql/dw/dw_mysql_repository.py:46-49`：

`async def validate(self, sql: str)` → `"""用 EXPLAIN 让数据库提前解析 SQL，发现语法 表名 字段名等错误"""` → `sql = f"explain {sql}"` → `await self.session.execute(text(sql))`。

`run()` 同文件 `:51-54` 直接 `await self.session.execute(text(sql))` —— **无任何写操作防护**。

**提示词侧的三条硬约束（只是"提示"，不是"拦截"）**：`generate_sql.prompt:18`（禁止编造表/列）、`:20`（只能查询不能写）；
`correct_sql.prompt:30`（不得擅自增删指标/维度/过滤/时间范围）、`:35`（不得含 INSERT/UPDATE/DELETE/CREATE）。
> **推断**：模型被提示"不许写"，但校验层不检查"是否只读"。提示词是唯一防线，模型不必遵守。

---

## 2. `state["error"]` 状态机


```text
[初始] DataAgentState(query=...)   ← query_service.py:49；初始只有 'query' 键，'error' 键【不存在】
   │
   ├─ generate_sql ──写──► {sql: "<候选 SQL>"}
   ├─ validate_sql ──读 sql──► explain(sql)
   │     ├─ 成功 → return {"error": None}   (:35)
   │     └─ 抛错 → return {"error": str(e)} (:40)
   │            │
   │            ▼ 【条件边 graph.py:85】
   │            path=lambda state: "run_sql" if state["error"] is None else "correct_sql"
   │            │
   │      ┌─────┴─────┐
   │      ▼           ▼
   │  run_sql     correct_sql（读 sql + error）
   │  (直接执行)         │
   │              return {"sql": result}  ← ⚠ 只写 sql，【error 不清空】
   │                     │
   └─────────────────────┴──► run_sql ← ⚠ 无二次校验 → END
```

| 问题 | 结论 | 依据 |
|---|---|---|
| 初始值 | **不存在该键**（不是 `None`，是根本没有） | `state.py:79` 声明 `error: str`；`query_service.py:49` 只传 `query` |
| 谁写它 / 分叉依据 | **只有 `validate_sql` 写**（`grep` 全 `app/`：仅 `graph.py:85` 与 `correct_sql.py:37` 读）；`state["error"] is None` → `run_sql`，否则 → `correct_sql` | `validate_sql.py:35`/`:40`；`graph.py:85` |
| `{"error": None}` 会被 LangGraph 丢掉吗 | **不会**。实测最终 state = `{'sql':'x','error':None}` | LangGraph `LastValue` 通道保留 `None` |
| 条件边读到没有 `error` 键的 state | **`KeyError: 'error'`**（实测） | 当前安全**仅因为** `validate_sql` 无条件写该键 —— 隐式契约，无断言保护 |
| **会不会残留** | **会**。`correct_sql.py:74` 只 `return {"sql": result}`，从不写 `error`。实测失败路径最终 state = `{'sql':'SELECT 1','error':'boom: unknown column'}` —— 校正成功了，旧错误还留着 | `correct_sql.py:74` |
| 残留会导致"下次判断出错"吗 | **当前不会**：`correct_sql` 后只有一条无条件边 `graph.py:88`→`run_sql`，**无节点再读 `error`**。**但这是地雷**：一旦按 D2 建议加"校正后回 `validate_sql`"的环，残留的旧错误会**立刻**把条件边再次导向 `correct_sql` | `graph.py:88` |
| 会跨请求残留吗 | **不会**。每次请求新建 `DataAgentState`（`query_service.py:49`），且 `graph.py:92` `compile()` **未传 checkpointer**，无持久化 | — |

---

## 3. 缺陷清单

### D1（致命）· 校验层与真实错误完全错位，校正分支实质是死代码
**现象**：`ux-examples-catalog.md` 实测 10 题 **0 题**走过校正分支；复核 `catalog.json` 的 `stepDetail`：**10/10 全部只含 11 个节点、全 `running`/`success`，无一出现「校正SQL」**。
**代码位置**：`dw_mysql_repository.py:46-49`（`explain`）；`prompts/generate_sql.prompt:18`。
**根因（实测拆解）**：`EXPLAIN` 能抓的错，与 LLM 实际会犯的错，是**两个不相交的集合**。
**放行（实测 `EXPLAIN-PASS`）**：错过滤值（`region_name='火星大区'`）、漏 `WHERE`（全表聚合）、全 NULL 投影（`NULL AS 支付方式`）、编造"无法生成SQL"字面量、日期字面量用字符串（`'2025-01-01'` —— 且**执行后 0 行**，`date_id` 是 INT 被强转成 `2025`）。
**抓住（实测 `EXPLAIN-FAIL`，1054/1146）**：只有**表/列名不存在** —— 而它恰恰是 LLM **最不容易**犯的错（`generate_sql.prompt:18` 明确禁止编造，且 `table_infos` 直接把真实 schema 喂进去了）。
⇒ **校验层检查的是最不可能出错的东西，漏掉的是真正出错的东西。**

**实测铁证**：把 10 道基线题的**真实 SQL**（`/tmp/ux-human-video/catalog.json` 的 `generatedSql`）逐条喂给 `EXPLAIN` —— **10/10 全部通过**，包括三道语义彻底错乱的题（#5 空结果、#6 `error_message` 行、#7 全 NULL 列），校验层**一个都没拦住**。
**用户可见影响**：这三道"坏"题在 UI 上是**全绿勾 + 一张看起来正常的表**（`App.tsx:113-120` 走 `type==="result"` → `status:"done"`）。
**修复方向**：校验层从"语法校验"升级为"**语义 + 结果形状校验**"：① 执行期结果形状断言（行数是否合理、指标列是否全 `NULL`、是否出现 `error_message` 单列）；② 加只读门禁（见 D6）；③ 加业务不变量校验（`date_id` 字面量须为 `yyyyMMdd` 格式 INT）。
**风险**：中高。执行期断言会引入"跑一遍再判断"的延迟；一旦发现错误要重入校正，**必须先修 D5**。

### D2（高）· 校正后不重新校验，且无回退
**现象**：实测把 `correct_sql` 的输出设为**仍然错误**的 SQL，图**照常执行**并把它当成功结果返回。
**代码位置**：`app/agent/graph.py:88` → `graph_builder.add_edge("correct_sql", "run_sql")` —— **无条件边**，之后没有任何 `validate_sql`。
**根因**：拓扑是 `validate_sql → {run_sql | correct_sql} → run_sql → END`，校正与执行之间**没有再校验环节**。
**实测输出**（真实节点函数 + 同构图 + fake 仓储）：S3（校正后仍错）：事件序列 `校验SQL:success → 校正SQL:success → 执行SQL:success → result`；`run_sql received: ['SELECT stillbad FROM fact_order']` —— **错的 SQL 被执行了**。
再把 `run()` 改成会失败（模拟真实 DB 报错）：`GRAPH RAISED: RuntimeError (1146, "Table 'dw.x' doesn't exist")`，事件 `校正SQL: success`（**绿勾！修正其实失败了**）、`执行SQL: error`。

**用户可见影响**：① 校正失败时「校正SQL」**仍显示绿勾**（`correct_sql.py:73` 在 LLM 返回成功时就写 `success`，不管 SQL 对不对）；② 整条查询直接失败，用户看到**裸 DB 报错**（`App.tsx:126` `error: event.message` → `MessageBubble.tsx:51-55` 红框里是 `(1146, "Table 'dw.x' doesn't exist")` 这类内部信息）；③ **原始 SQL 已被覆盖丢弃**。
**修复方向**：`correct_sql` 后接回 `validate_sql`（受控环，最大 N 次）；保留 `sql_original`；N 次仍失败 → 回退原 SQL 或发 `type:"error"`。
**风险**：中。改成环后**必须同时修 D5**，否则残留 `error` 会让环立刻自旋。

### D3（高）· 「校验SQL」永远绿勾
**现象**：校验失败时流程图上「校验SQL」仍是绿勾，用户看不出发生过自我修正。
**代码位置**：`app/agent/nodes/validate_sql.py:33` 与 `:39` —— **两条分支写的完全一样**：

成功分支（`:33-35`）：`writer({"type": "progress", "step": step, "status": "success"})` → `logger.info("SQL语法正确")` → `return {"error": None}`。
失败分支（`:38-40`）：`logger.info(f"SQL语法错误：{str(e)}")` → `writer({"type": "progress", "step": step, "status": "success"})` ← **← 同样的 success** → `return {"error": str(e)}`。

**根因**：节点作者把"校验**动作**完成"误当成"校验**通过**"。
**实测**：用 fake 仓储跑真实 `validate_sql`，失败分支事件 = `[{'step':'校验SQL','status':'running'}, {'step':'校验SQL','status':'success'}]` —— **确认绿勾**。
**用户可见影响**：`StepRail.tsx:72-74` 把 `success` 画成 `<Check>` 绿勾；前端已有 `error` 样式（`StepRail.tsx:97` `border-tomato/35`）可直接用。
**修复方向**：失败分支改写 `status:"error"`（或新增 `warning` 态，同时更新 `types/agent.ts:5` 的 `ProgressStatus` 与 `StepRail.tsx:67-80` 的 `NodeIcon`）。
**风险**：低。前端已支持 `error` 态。改完后「校验SQL」红、「校正SQL」绿，语义才对得上。

### D4（中）· 「校正SQL」永远 pending
**现象**：流程图上「校正SQL」永远是灰色空心圈，从不点亮。
**代码位置**：`shopkeeper-agent-frontend/src/components/StepRail.tsx:29`（`{ step: "校正SQL", x: 670, y: 630 }`，硬编码在 12 节点列表 `:18-31` 内）；`StepRail.tsx:63-64`：

`function statusFor(step, map): FlowStatus { return map[step]?.status ?? "pending"; }`

**根因（两层）**：① **前端**：12 节点是**静态画布**，不按实际执行动态渲染；分支标签「有误」（`StepRail.tsx:52`）也是写死的 SVG 文字。只要 `correct_sql` 没跑，`map` 里就没这个 step → 永久 `pending`。② **后端（真正的因）**：`correct_sql` 不跑是因为 D1 —— `EXPLAIN` 放行了几乎所有真实错误，**10/10 实测 0 次触发**。
**用户可见影响**：流程图上那个「有误」分支箭头指向一个永不点亮的节点，等于**给用户一个恒定的假信号**。
**修复方向**：① 后端修好 D1/D2 后该节点自然点亮；② 无论后端如何，前端应把"未触发的可选分支"渲染成**灰色虚线 / 标注"未触发"**，而不是与"待执行"共用 `pending`。
**风险**：低。

### D5（中）· `state["error"]` 残留
**现象**：校正分支跑完后，state 里仍留着**已失效的旧错误**。
**代码位置**：`app/agent/nodes/correct_sql.py:74` → `return {"sql": result}` —— **只写 `sql`，不写 `error`**。
**根因**：节点只声明自己要写的字段，没人负责清理别人的字段。
**实测**：失败路径最终 state = `{'sql':'SELECT 1','error':'boom: unknown column'}` —— 校正明明成功了，`error` 还在。
**用户可见影响**：**当前无直接影响**（`error` 写进 state 后没人读，前端也收不到 —— SSE 只透传 `writer()` 的进度事件，`query_service.py:61-66`）。但这是 **D2 修复方案的前置地雷**：加回校验环时，残留 `error` 会让条件边**立刻**再次导向 `correct_sql`，形成空转。
**修复方向**：`correct_sql` 成功时 `return {"sql": result, "error": None}`。
**风险**：低。

### D6（高·安全）· 多语句载荷绕过校验，第二句照常执行；`EXPLAIN` 也不拦写语句
**代码位置**：`app/repositories/mysql/dw/dw_mysql_repository.py:48`（`f"explain {sql}"`）、`:51-54`（`run()`）；`generate_sql.prompt:20`、`correct_sql.prompt:35`。
**现象 A（多语句）**：`validate()` 做的是 `f"explain {sql}"` —— 字符串拼接，**不检查语句条数**。只给**第一句**加 `EXPLAIN` 前缀，**后面的语句按原样执行**：

`payload = "SELECT 1 AS a FROM fact_order LIMIT 1; DROP TABLE _probe_esc;"` → `validate()` **无异常抛出（校验通过！）**；另一连接查 `information_schema` 得 `_probe_esc exists = 0` —— **DROP 真执行了**。

MySQL 对 DDL **自动提交**，所以即使应用全程不 `commit()`，表也真没了（`fact_order` 未受影响，已复核仍 115 行）。
`run()` 路径同理：`text("SELECT 1 ...; DROP TABLE _probe_run;")` → **DROP 执行且已提交**。

**现象 B（写语句不被拦）**：`DELETE`/`UPDATE`/`INSERT` 全部**通过校验**（实测 `[VALIDATE-PASS] DELETE/UPDATE/INSERT via explain`）—— MySQL 8.0.18+ 支持 `EXPLAIN DELETE/UPDATE/INSERT`，实测服务端版本 **8.0.46**。（`explain DROP TABLE` 反而报 1064 语法错 —— DDL 不可 EXPLAIN；但现象 A 表明 `explain <select>; DROP TABLE x;` 里的 DROP 照样跑。）

**根因**：`text()` 不做语句分割；驱动连接默认带 `CLIENT_MULTI_STATEMENTS`（实测 asyncmy `_client_flag = 3908109`，`1<<16` 位为 1）。校验层只问"数据库能不能解析"，从不问"这条语句**该不该**跑" —— `generate_sql.prompt:20`/`correct_sql.prompt:35` 的"只能查询"是提示，不是拦截。
**用户可见影响**：用户问一句话 → LLM 生成 SQL → 若含 `;` 且后半句是 DDL/DML，**在"校验"这一步就已经改库了**。校验层不但没拦住，反而成了执行器。提示词注入是最现实的触发路径。
**修复方向**：① **语句白名单**：正则判定单条 `SELECT`（`^\s*(SELECT|WITH)\b` 且**不含 `;`**），否则判错；② 仓储层先用 `sqlparse.split()` 校验只有 1 句；③ **连接层收权**：DW 账号只授 `SELECT`（`docker/mysql/dw.sql:4` 当前是 `GRANT ALL PRIVILEGES ON dw.*`）；④ 连接串去掉 `MULTI_STATEMENTS`。
**风险**：低（纯收紧）。**这是本审计唯一一条"需要立刻处理"的项。**

### D7（中）· 原始 SQL 被丢弃，无回退
**代码位置**：`app/agent/nodes/correct_sql.py:74`（`return {"sql": result}`）；`app/agent/graph.py:88`。
**现象**：`correct_sql` 用新 SQL 覆盖 `state["sql"]`，**原 SQL 不留**。校正若失败（改出更糟的 SQL），连原始那条也回不去。
**根因**：`state` 只有一个 `sql` 字段（`state.py:77`），没有 `sql_original`；`correct_sql` 是覆盖而非追加。
**实测**：`run_sql received: ['SELECT stillbad FROM fact_order']` —— 原始的 `SELECT bad FROM fact_order` **从未被尝试执行**。
**用户可见影响**：本来可能能跑通的题，因一次错误校正而彻底失败。
**修复方向**：`state` 加 `sql_original`；校正后校验仍失败 → 回退执行原 SQL。
**风险**：低。

### D8（低·澄清）· `correct_sql` 不可能无限循环；`recursion_limit` 未显式配置

> 任务书点名要澄清的一条，结论**与直觉相反**。

**现象**：无需实测即可从拓扑判定 —— `correct_sql` 在任何情况下都只执行一次。
**代码位置**：`app/agent/graph.py:83-89`（全部边）、`app/services/query_service.py:61-63`（`astream` 不传 `config`）、`langgraph/_internal/_config.py:31`（默认 `recursion_limit`）。
**结论**：**不会无限循环，也不可能耗尽 `recursion_limit`。**
**根因**：图的拓扑是线性链，`correct_sql` 处于链的末端，之后没有任何一条边能回到它。
**依据 1 —— 图是 DAG，没有任何回边**。`app/agent/graph.py:83-89` 全部边：

`validate_sql --conditional--> run_sql`、`validate_sql --conditional--> correct_sql`、`correct_sql --(无条件边)--> run_sql`、`run_sql --> END`。

`correct_sql` 只有**一条入边**（来自 `validate_sql` 的条件边）和**一条出边**（到 `run_sql`），**没有任何一条边指回 `validate_sql`**。拓扑序 `… → validate_sql → correct_sql → run_sql → END` 是线性链。

**依据 2 —— 实测节点调用次数**。构造"校验**永远失败**"的最坏情况（同构图 + 真实节点函数）：`Q3 node invocation counts: {'generate_sql': 1, 'validate_sql': 1, 'correct_sql': 1, 'run_sql': 1}` —— `correct_sql` **恰好执行 1 次**，无论校验失败多少次。

**依据 3 —— `recursion_limit` 存在但用不上**。LangGraph 1.1.6 的默认值在 `langgraph/_internal/_config.py:31`：
`DEFAULT_RECURSION_LIMIT = int(getenv("LANGGRAPH_DEFAULT_RECURSION_LIMIT", "10007"))`
（实测 `DEFAULT_RECURSION_LIMIT = 10007`，环境变量 `LANGGRAPH_DEFAULT_RECURSION_LIMIT` **未设置**。注意这个默认值与社区常见的 `25` 不同 —— 项目锁定的 `langgraph==1.1.6`（`pyproject.toml:18`）就是 10007，属上游行为，非本地魔改。）
本项目**从未显式设置** `recursion_limit`：`grep -rn "recursion_limit" app/` **零命中**；`query_service.py:61-63` 的 `graph.astream()` 只传 `input`/`context`/`stream_mode`，**不传 `config`**。
但由于图无环，**递归步数有天然上界（约 8–9 步），永远碰不到 10007**。（实测 `recursion_limit=2` 会抛 `GraphRecursionError`，机制本身有效。）

**用户可见影响**：无。**这是"澄清已澄清的误解"**，但它推翻了"自我修正可能死循环"的担心。
**⚠️ 真正的风险在 D2**：把 `correct_sql` 改成**回 `validate_sql`** 修 D2 时，图**才第一次**变成有环。届时**必须**同时：(a) 显式传 `config={"recursion_limit": 25}` 进 `astream`，(b) 修 D5 的 `error` 残留，(c) 加"最多重试 N 次"计数器。**三者缺一，就会造出真正的死循环。**
**修复方向**：修 D2 时一并加显式 `recursion_limit` + 重试计数。**风险**：低（现状无风险；改动时高）。

### D9（低）· 类型标注与实际值不符；`error` 键缺失会 `KeyError`
**代码位置**：`app/agent/state.py:79`（`error: str`）、`app/agent/nodes/validate_sql.py:35`（写入 `None`）、`app/agent/graph.py:85`（`state["error"]`）。
**现象**：`state.py:79` 声明 `error: str`，但 `validate_sql.py:35` 写入 `None`。`TypedDict` 运行期不校验，不报错，但标注是错的。
**根因**：类型标注未跟随实现更新；条件边用下标而非 `.get()` 访问，隐式依赖"上游一定写过这个键"。
**用户可见影响**：当前无（上游总是写该键）；但任何改动 `validate_sql` 返回值的重构都可能让条件边抛 `KeyError`，整图中断。
**实测**：若某节点没写 `error`，条件边 `state["error"]` 直接 **`KeyError: 'error'`**（而非走 `correct_sql`）。当前安全**仅因为** `validate_sql` 无条件写该键 —— 隐式契约，无断言保护。
**修复方向**：`error: str | None`；条件边改用 `state.get("error") is None`。**风险**：低。

---

## 4. 可测试性评估

### 4.1 结论：三个节点现在就能单元测试，且不需要真实 LLM / DB

已实测跑通（真实节点函数 + fake 依赖）：

- **`validate_sql` ✅ 完全可测**：mock `runtime.context["dw_mysql_repository"]` → 带 `async validate(sql)` 的假对象（抛/不抛两种）。实测返回 `{'error': None}` / `{'error':'(1054, ...)'}`，事件序列正确捕获。
- **`generate_sql` ✅ 可测**：mock **模块级 `llm`**（`generate_sql.py:14` 的 import）→ 换成假 Runnable。实测返回 `{'sql':'SELECT 1 AS x FROM fact_order'}`。
- **`correct_sql` ✅ 可测**：同上（`correct_sql.py:14`）。实测返回 `{'sql':...}`，**且 `'error' not in 返回值`** —— 正好用来断言 D5。
- **`run_sql` ✅ 可测**：mock `runtime.context["dw_mysql_repository"]` → 假对象带 `async run(sql)`。

**关键 mock 手法（实测踩坑，已确认）**：

1. `Runtime` 可直接构造：`Runtime(context={...}, stream_writer=fn)` —— 无需真跑图。
2. 假 LLM **必须是 `langchain_core.runnables.Runnable` 子类**，且返回 `AIMessage`：

`class FakeLLM(Runnable)`，实现 `invoke` 与 `ainvoke` 两个方法，均 `return AIMessage(content="SELECT 1")`（`from langchain_core.messages import AIMessage` / `from langchain_core.runnables import Runnable`）。

   duck-typed 的普通类会报 `TypeError: Expected a Runnable, callable or dict`（实测）；返回裸字符串会被 `StrOutputParser` 报 `Generation.text` 类型错误（实测）。
3. 只 patch `app.agent.nodes.generate_sql.llm` 这**一个模块属性**即可，`PromptTemplate | llm | StrOutputParser` 链路能正常拼装（实测通过）。
4. `load_prompt` 读真实 `prompts/*.prompt`（`app/prompt/prompt_loader.py:11-16`），**无需 mock**；要隔离则 patch 它。
5. 事件捕获：`stream_writer` 传 `list.append` 即可拿到全部 progress 事件。

### 4.2 最小可行测试方案

**依赖清单（当前环境全部缺失，需先补）**：`pytest`（❌ 未安装，`ls site-packages | grep pytest` 空）、`pytest-asyncio`（❌ 未安装，`async def` 测试需要）、`pytest-cov`（❌ 可选）；**真实 DB / LLM 在单测层完全不需要**。
> `pyproject.toml:27-31` 的 `dev` 组目前**只有 `pre-commit` 和 `ruff`** —— 项目**零测试基础设施**，`docs/` 下也没有 `tests/` 目录。

- **L1 单元**（`tests/nodes/test_validate_sql.py`）：`validate_sql` 两条分支的事件与返回值。
- **L2 单元**（`tests/nodes/test_sql_nodes.py`）：`generate_sql`/`correct_sql` 的返回值、事件、**`error` 不被清空（D5）**。
- **L3 图级**（`tests/graph/test_sql_loop.py`，自建 `StateGraph` + fake 仓储 + fake LLM）：条件边分叉正确、`correct_sql` **恰好执行一次**（D8 护栏）、校正后不重校验（D2 现状断言）。
- **L4 契约（可选，需 DB）**（`tests/contract/test_explain_baseline.py`，`testcontainers` 或本机 dw）：`EXPLAIN` 行为基线，哪些 SQL 应放行 / 应拦截。
- **L5 E2E（不进气 CI）**：10 题真跑比对结果行，复用 `docs/hotpath_probe.py`。

**L1/L2/L3 必测断言清单**（直接对应本报告缺陷）：

```text
L1  validate_sql 成功 → 返回 {"error": None}，事件含 校验SQL:success
L1  validate_sql 失败 → 返回 {"error": "<含 MySQL 错误码的字符串>"}   # D3 回归护栏
L2  generate_sql  → 返回 {"sql": "<LLM 文本>"}，事件 生成SQL:running/success
L2  correct_sql  → 返回 {"sql": ...} 且 "error" 不在其中（D5 护栏）
L3  校验失败 → 走 correct_sql；校验成功 → 不走
L3  节点调用计数：correct_sql 恰好 1 次、run_sql 恰好 1 次（D8 护栏）
L3  校正后 run_sql 收到的是**校正后**的 SQL（D2/D7 现状断言）
```

**缺口**：无 `tests/` 目录、无 `conftest.py`、无 CI 配置（`.pre-commit-config.yaml` 只跑 ruff + 分层契约检查）。
分层契约检查器 `docs/module_graph.py` 已在 pre-commit 里跑，可作 L3 的**风格参照**（同样是"纯 Python 脚本 + 可执行断言"）。建议把 L1–L3 加进 `pre-commit` 的 `local` hook 或另接 CI。

---

## 5. 回归基线建议

### 5.1 现状：基线数据存在，但放错了地方

- **10 题的真实 SQL + 结果行 + 耗时 + 每步事件** → `/tmp/ux-human-video/catalog.json`（101 KB，10 条）。⚠️ **`/tmp` 会被清空，CI 不可用**。
- **同样数据的可读版** → `../../../ux-examples-catalog.md`（377 行）。⚠️ 在**仓库外**，SQL 列还被 Markdown 表格截断。
- **单题原始 SSE** → `/tmp/ux-human-video/raw/qNN.sse` + `qNN.timed.jsonl`。⚠️ 同上，临时目录。
- **归因说明** → `docs/OPTIMIZATION-BACKLOG.md` §6（`:190-196`）。✅ 在仓库内。

`catalog.json` 每条含 `idx`/`question`/`elapsed`/`stepDetail`（逐节点事件）/`payload`/`rows`/`columns`/`uiState`/`generatedSql`/`sqlRequestId` —— **正是 CI 需要的全套断言素材**，只是需要搬进仓库。

### 5.2 建议的固定数据集

**新建 `tests/fixtures/sql_baseline.json`**（从 `catalog.json` 转换，保留 `idx`、`question`、`generatedSql`、`rows`、`columns`、`rowCount`、`uiState`、`steps`、`elapsed`）。10 道题已覆盖的场景（`ux-examples-catalog.md` 主表，已用 `catalog.json` 核实）：
- **#1** 2025 Q1 各大区 GMV 降序 —— **基线正确题**，5 行，`大区`/`GMV`
- **#2** 2025-03 各品类销量与销售额 —— 类型不一致（`销量` 是字符串），6 行，`商品品类`/`销量`/`销售额`
- **#3** 华东 Q1 销售额 Top5 —— Top-N，5 行，`商品名称`/`销售额`
- **#4** 会员等级订单数与销售额 —— **两指标排序方向不一致**，4 行，`会员等级`/`订单数`/`销售额`
- **#5** GMV by region in Q1 2024 —— **空结果**（库里无 2024 数据），0 行
- **#6** asdf qwer zxcv 12345 —— **error_message 数据行**，1 行，`error_message`
- **#7** 每个用户的支付方式占比 —— **全 NULL 列**（字段召不回来），20 行，`customer_id`/`支付方式`/`支付方式占比`
- **#8** GMV by region in Q1 2025 —— 英文等价问法：**别名漂移 + 排序丢失**，5 行，`地区`/`GMV`
- **#9** top 5 products by sales in 2025 Q1 —— 英文 Top-N：**别名语言不稳定**，5 行，`product_name`/`sales`
- **#10** 每个城市 2025-03 订单量 —— **粒度错位**（列名"城市"、值是省），6 行，`城市`/`订单量`

### 5.3 断言分层（关键：SQL 文本不稳定，只能断言结果与形状）

> `docs/OPTIMIZATION-BACKLOG.md:196` 已记录：「同一问题每次 SQL 文本不同 …… 差异来自提示词约束不足，不是采样随机性」。
> **因此绝不能断言 SQL 字符串相等**，否则 CI 会随机变红。

| 层 | 断言 | 阈值 | 为什么 |
|---|---|---|---|
| **A. 结果等价** | 归一化后**结果行逐行相等**（不是只比行数） | 10/10 | `OPTIMIZATION-BACKLOG.md:143` 已定此标准 |
| **B. 结果形状** | `rowCount` 与 `columns` 与基线一致 | 10/10 | 直接抓 #5 空结果、#6 error_message、#7 全 NULL |
| **C. 语义护栏** | 结果中**不得**出现：单列 `error_message`、整列全 `NULL` | 10/10 必须 0 命中 | #6/#7 的**回归护栏**；当前 2/10 命中 → **修复前这条必然红，是"待修"而非"已修"** |
| **D. 别名归一** | 把别名映射到**规范指标名**后再比对 | 10/10 | #1 `大区` vs #8 `地区`、#3 中文 vs #9 英文 —— 直接比列名必红 |
| **E. 排序** | 问题含"排序/Top"时，结果必须单调 | #1 #3 #4 | #4 实测两指标排序方向不一致，只能断言"被声明的那个指标单调" |
| **F. 步骤事件** | `stepDetail` 的节点集合与状态符合预期（修 D3/D4 后应变化） | 10/10 | 当前 10/10 全 success、0 次校正 —— 正是 D1/D3 的量化证据 |
| **G. 稳定性** | 同一题跑 **≥3 次**，结果行一致 | 3/3 | `OPTIMIZATION-BACKLOG.md:150` 要求 `--repeat 5` 以上看 p50/p95 |
| **H. 性能** | 端到端 **p50** 不退化 | ≥20%（若同期做性能优化） | `OPTIMIZATION-BACKLOG.md:143` |
| **I. 只读护栏** | 生成 SQL 必须**单条 SELECT**、无 `;`、表名 ⊆ 白名单 | 10/10 | D6 的回归护栏 |

**E 类的坑**（已实测的边界）：#1 的 `GMV` 严格降序；#8 **没有** `ORDER BY`（问题也没要求排序，行序是 DB 自然序）；#10 同样未排序且"城市"列装的是省。→ **"问题未要求排序"时不许断言行序**，否则误报。

### 5.4 落地顺序

1. **先搬数据**：`catalog.json` → `tests/fixtures/sql_baseline.json`（进仓库，脱离 `/tmp`）。
2. **先建"红"断言**：C 类（error_message / 全 NULL 护栏）与 I 类（只读护栏）**先写成红的**，作为 D1/D6 的验收标准 —— 修完转绿。
3. **再建"绿"断言**：A / B / D / E / G，进 CI。
4. **补 L1–L3 单测**（§4.2），把 D3/D5/D8 变成**代码级回归护栏**，不再依赖 10 题实测。
5. **F 类断言单独放"观察报告"**，不作门禁 —— 修 D1/D3/D4 前后它会剧烈变化，正是要看的。

---

## 附：审计方法与可复现命令

**只读探针**（全部只跑 `EXPLAIN`/`SELECT`；探针表 `_probe_*` 已全部 `DROP`，`fact_order` 复核仍 115 行，`dw` 库已恢复原始 5 张表）。复现 D1：把 `catalog.json` 每条的 `generatedSql` 喂给 `await session.execute(text(f"explain {sql}"))` → 10/10 全部 PASS；复现 D6：`text("explain SELECT 1 AS a FROM fact_order LIMIT 1; DROP TABLE _probe_esc;")` → 不报错且 DROP 真执行；复现 D3（不碰 DB）：`await validate_sql({"sql": "SELECT bad"}, rt)` → 事件 `[..., {'step':'校验SQL','status':'success'}]`；复现 D5/D8：同构图 + fake 仓储恒失败 → 计数 `{'validate_sql':1,'correct_sql':1,'run_sql':1}` 且最终 `state['error']` 仍是旧错误串。
**未做的事**（遵守任务约束）：未修改任何源码/配置/提示词；未执行 `docker`/`sudo`；未调用 `/api/query`；未 `docker logs`。
