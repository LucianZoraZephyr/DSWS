# HANDOFF — Docker 化部署 shopkeeper-agent

> 交接时间：2026-10-20 09:20  
> 完成时间：2026-10-20 12:56  
> 状态：**已完成**，七个容器运行中，真实问数链路与 nginx SSE 均已验证（见第 9 节）。

---

## 1. 目标

把电商问数智能体（FastAPI + LangGraph 后端 / React 前端）用 Docker 镜像完整跑起来，
替换掉之前那套用户态 shim（MariaDB 二进制 + Qdrant 二进制 + embedding/ES 假服务）。

验收标准：`http://127.0.0.1:8000/api/query` 跑完 11 个节点并返回真实 GMV 数据；
`http://127.0.0.1:5173` 能打开页面并通过 nginx 反代拿到 SSE 流。

---

## 2. 已完成

### 2.1 Docker 运行时
- Docker **29.1.3**、Docker Compose **2.40.3** 已通过 apt 安装并设为开机自启。
- `/etc/docker/daemon.json` 已配置：
  ```json
  {
    "registry-mirrors": ["https://docker.m.daocloud.io", "https://docker.1ms.run"],
    "dns": ["223.5.5.5", "119.29.29.29"]
  }
  ```
  原因：**本机直连 `registry-1.docker.io` 完全不通**（DNS 解析失败），必须走国内镜像。

### 2.2 镜像（11 个，全部已拉取/构建）
```
mysql:8.0                                    1.1GB
elasticsearch:8.19.10                        2.11GB
docker-elasticsearch:latest                  2.14GB   ← 本地构建，已装 IK 分词插件
kibana:8.19.10                               2.1GB
qdrant/qdrant:v1.16                          276MB
ghcr.io/huggingface/text-embeddings-inference:cpu-1.8  938MB
python:3.14-slim                             180MB
node:22-alpine                               238MB
nginx:1.27-alpine                            74.5MB
ghcr.io/astral-sh/uv:latest                  64.5MB
hello-world:latest                           25.9kB  (连通性测试用，可删)
```

### 2.3 Embedding 模型
`docker/embedding/bge-large-zh-v1.5/` 已完整下载 **1.3GB**（`pytorch_model.bin` 1,302,220,525 字节）。
来源是 `HF_ENDPOINT=https://hf-mirror.com`——**huggingface.co 本机不可达**。

### 2.4 已修的两个网络缺陷（关键，别删）

| 缺陷 | 现象 | 修复 |
|---|---|---|
| **MTU 黑洞** | 请求体 > ~1.4KB 被静默丢弃；短 prompt 1 秒回，长 prompt 47 秒后 `APIConnectionError: Connection error` | iptables 把 TCP MSS 压到 1200 |
| **TLS 1.3 握手挂死** | Python 3.14 / OpenSSL 3.5.9 对 `api.deepseek.com` 的 TLS1.3 ClientHello 无响应，TLS1.2 正常 | 镜像内 `sitecustomize.py` 把 `ssl.create_default_context().maximum_version` 钉到 `TLSv1_2` |

iptables 规则（**两条都要**，OUTPUT 只管宿主机自己发的包，容器流量走转发链）：
```bash
sudo iptables -t mangle -A OUTPUT      -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1200
sudo iptables -t mangle -A POSTROUTING -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1200
```
两条规则目前都已生效（`iptables -t mangle -S OUTPUT/POSTROUTING | grep TCPMSS` 可确认）。
**重启后会丢失**，需要重新执行，或用 `iptables-persistent` 固化。

TLS 补丁文件：`docker/sitecustomize.py`，`docker/Dockerfile.backend` 已把它同时拷到
`/app/sitecustomize.py` 和 `.venv/lib/python3.14/site-packages/sitecustomize.py`，并设 `PYTHONPATH=/app`。

### 2.5 容器化资产（已写好）
| 文件 | 作用 |
|---|---|
| `docker/docker-compose.yaml` | 8 个服务：mysql / elasticsearch / kibana / qdrant / embedding / api / meta-build / web |
| `docker/Dockerfile.backend` | python:3.14-slim + uv，`uv sync --frozen --no-dev`，uvicorn `--loop asyncio` |
| `docker/sitecustomize.py` | TLS 1.2 补丁 |
| `docker/app_config.docker.yaml` | 容器内配置，主机名换成服务名（mysql/qdrant/embedding/elasticsearch） |
| `docker/elasticsearch/Dockerfile` | ES 8.19.10 + IK 8.19.10 插件（插件 zip 在 `plugins/`） |
| `shopkeeper-agent-frontend/Dockerfile` | node:22 构建 → nginx:1.27 托管 |
| `shopkeeper-agent-frontend/nginx.conf` | `/api` 反代到 `api:8000`，`proxy_buffering off`（SSE 必须） |
| `docker/README.md` | 部署说明（安装、加速、模型、启动） |

前端 `dist/` 已能正常构建出来（`index.html` + `assets/` 存在）。

---

## 3. 卡点（从这里继续）

### 3.1 当前阻塞：BuildKit 前端镜像拉不到

`docker compose up -d --build` 在构建 `api` / `meta-build` 时停在：
```
#13 [meta-build] resolve image config for docker-image://docker.io/docker/dockerfile:1
#14 sha256:9d2b4f57... 0B / 14.28MB   ← 卡住，最后 CANCELED
```

原因：两个 Dockerfile 首行都有 `# syntax=docker/dockerfile:1`，BuildKit 会先去 Docker Hub 拉
`docker/dockerfile:1` 这个前端镜像，而**直连 Docker Hub 不通**，mirror 也没覆盖这个特殊引用。

### 3.2 推荐修法（二选一）

**A. 直接删掉 syntax 行（最简单）**
两个文件都只用了最基础的指令（COPY / RUN / ENV / CMD），不需要新版语法：
```bash
sed -i '/^# syntax=docker\/dockerfile:1$/d' docker/Dockerfile.backend
sed -i '/^# syntax=docker\/dockerfile:1$/d' ../shopkeeper-agent-frontend/Dockerfile
```

**B. 先把前端镜像拉下来并打上官方 tag**
```bash
sudo docker pull docker.m.daocloud.io/docker/dockerfile:1
sudo docker tag docker.m.daocloud.io/docker/dockerfile:1 docker/dockerfile:1
```

---

## 4. 剩余步骤

```bash
cd "/home/zhensirong/VM-Share/A020-电商问数智能体实战教程/code/shopkeeper-agent/docker"

# 1) 解决 3.1 的卡点

# 2) 构建并启动
sudo docker compose up -d --build
sudo docker compose ps            # 等 mysql / elasticsearch 变 healthy

# 3) 建向量索引（一次性，不是幂等的，重跑前先 TRUNCATE）
sudo docker compose run --rm meta-build

# 4) 验证元数据
sudo docker compose exec mysql mysql -udidilili -pdili123 -e \
  "SELECT (SELECT COUNT(*) FROM meta.column_info) cols, (SELECT COUNT(*) FROM meta.metric_info) metrics"
# 期望 cols=24, metrics=2
curl -s http://127.0.0.1:6333/collections   # 期望两个 collection

# 5) 验证真实查询
curl -N -X POST http://127.0.0.1:8000/api/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"统计2025年第一季度各大区的GMV，并按GMV从高到低排序"}'

# 6) 验证前端
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:5173/
```

### 期望结果（与用户态栈跑出来的完全一致，可直接对答案）
```
11 个进度节点：抽取关键词 → 召回字段信息 → 召回指标信息 → 召回字段取值 →
合并召回信息 → 过滤指标信息 → 过滤表信息 → 添加额外上下文 → 生成SQL → 校验SQL → 执行SQL

result 帧：
  华东 107373.0
  华南 70202.0
  华北 41099.5
  西南 31528.0
  华中 28957.0
```
生成的 SQL 应该是：
```sql
SELECT d.region_name AS 大区, SUM(f.order_amount) AS GMV
FROM fact_order f JOIN dim_region d ON f.region_id = d.region_id
WHERE f.date_id BETWEEN 20250101 AND 20250331
GROUP BY d.region_name ORDER BY GMV DESC;
```

---

## 5. 环境事实（必读）

| 项 | 值 |
|---|---|
| sudo 密码 | `08267`，非交互写法：`printf '%s\n' '08267' \| sudo -S -p '' <cmd>` |
| sudo 与 heredoc | **不能同时用**，heredoc 会吃掉 stdin；先写 /tmp 再 `sudo cp` |
| 直连 Docker Hub | 不通，必须走 mirror |
| 直连 huggingface.co | 不通，用 `HF_ENDPOINT=https://hf-mirror.com` |
| LLM | DeepSeek：`https://api.deepseek.com/v1`，model `deepseek-flash` |
| API Key | 在 `shopkeeper-agent/.env` 的 `LLM_API_KEY` |
| 端口 | 3306 mysql / 6333 qdrant / 8081 TEI / 9200 ES / 8000 api / 5173 web / 5601 kibana |
| 旧用户态栈 | 在 `/home/zhensirong/VM-Share/.backend-run`，**不要删**，可作为回退 |

### 回退方案
如果 Docker 路线继续受阻，用户态栈仍然可用：
```bash
bash /home/zhensirong/VM-Share/.backend-run/start-all.sh
# 然后按 README 跑一次 build_meta_knowledge，API 在 :8010
```
注意它和 Docker 栈抢同样的端口，**两者不能同时起**。

---

## 6. 已知坑

1. `meta-build` **不幂等**。重跑前必须先清表：
   `TRUNCATE meta.table_info, meta.column_info, meta.metric_info, meta.column_metric`，
   否则报 `Duplicate entry 'dim_region.region_id' for key 'PRIMARY'`。
2. `conf/app_config.yaml` 里是 `localhost`，**容器内必须用 `docker/app_config.docker.yaml`**（已通过 volume 覆盖）。
3. api 的启动参数固定 `--loop asyncio`。uvloop 在 C 层建连，会绕过 socket 层的 MSS 补丁，导致长 prompt 47 秒超时。
4. ES 8.x 客户端会校验 `X-Elastic-Product` 响应头；用户态 shim 需要伪造，真 ES 不需要。
5. Qdrant 官方 musl 版二进制在本机会 segfault，用 gnu 版（仅与用户态栈相关）。

---

## 7. 相关文件清单

```
code/shopkeeper-agent/
├── .env                              # LLM_API_KEY
├── conf/app_config.yaml              # 已改为 DeepSeek（宿主/用户态路径用）
├── docker/
│   ├── docker-compose.yaml           # 8 服务编排
│   ├── Dockerfile.backend            # 后端镜像（含 TLS 补丁）
│   ├── sitecustomize.py              # TLS 1.2 补丁
│   ├── app_config.docker.yaml        # 容器内配置
│   ├── README.md                     # 部署说明
│   ├── elasticsearch/{Dockerfile,plugins/*.zip}
│   ├── mysql/{meta.sql,dw.sql}       # 初始化 SQL（自动导入）
│   └── embedding/bge-large-zh-v1.5/  # 1.3GB 模型
└── (app/ 未改动)

code/shopkeeper-agent-frontend/
├── Dockerfile
├── nginx.conf
└── dist/                             # 已构建产物
```

---

## 8. 一句话交接

镜像、模型、网络补丁、编排文件全都齐了；
**只差删掉两个 Dockerfile 里的 `# syntax=` 行，然后 `docker compose up -d --build` + `meta-build` 两把**，
就能在 8000/5173 上跑通真实问数链路。

---

## 9. 完成记录（2026-10-20 12:56）

删掉两个 `# syntax=` 行之后，构建/启动还遇到 7 个阻塞，全部已修复：

| 阻塞 | 修复 |
|---|---|
| 构建容器内 DNS 全挂 | `daemon.json` 里的 `223.5.5.5` / `119.29.29.29` 在本网络不可达；改为 DHCP 下发的 `61.145.231.34`、`222.200.8.2` + `114.114.114.114`，重启 Docker |
| `files.pythonhosted.org` 拉取失败 | `Dockerfile.backend` 固定 `UV_DEFAULT_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple` |
| `asyncmy==0.2.11` 无 cp314 wheel | 镜像内安装 `gcc` + `libc6-dev` 源码编译 |
| npm 拉取不稳 | 前端 Dockerfile 固定 `registry.npmmirror.com` |
| 容器一启动就崩 | `app_config.docker.yaml` 里 `${VAR:-default}` 是 shell 语法，OmegaConf 要写 `${oc.env:VAR,default}` |
| 宿主机访问容器超时 | Wi-Fi 拿到 `172.18.70.185/17`，与 Docker 的 `172.18.0.0/16` 重叠；compose 固定默认网络为 `172.28.0.0/16` |
| nginx 报 `host not found in upstream "api"` | 本机 Docker 未自动注册服务名别名；给 `api` 显式加 `networks.default.aliases: [api]` |

另外两处健壮性调整：

- `meta-build` 移入 `profiles: ["tools"]`，`up -d` 不再自动重跑（非幂等）；仍用 `docker compose run --rm meta-build`。
- `Dockerfile.backend` 增加 `UV_NO_DEV=1`，容器启动时 `uv run` 不再下载 ruff/virtualenv。

验证结果：

- `docker compose ps`：7 个容器全部 Up，重启计数 0。
- 元数据：表 5 / 字段 24 / 指标 2；Qdrant 2 个 collection；ES `value_index` 75 docs。
- `POST /api/query`：11 个节点全部 success（含 `添加额外上下文`），约 15 s。
- 结果：华东 107373.0、华南 70202.0、华北 41099.5、西南 31528.0、华中 28957.0。
- `http://127.0.0.1:5173`：页面可打开，经 nginx 收到增量 SSE（非一次性缓冲），浏览器实测 5 行结果、无 console 报错。

当前栈保持运行。重启：`cd docker && docker compose up -d`（不会重跑 meta-build）。
