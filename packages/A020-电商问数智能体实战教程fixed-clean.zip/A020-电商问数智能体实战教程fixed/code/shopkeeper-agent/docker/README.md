# Docker 部署（完整栈）

8 个服务，全部用镜像，不再依赖本机 Python / MariaDB / shim：

| 服务 | 镜像 | 端口 | 说明 |
|---|---|---|---|
| mysql | mysql:8.0 | 3306 | 首次启动自动导入 `docker/mysql/{meta,dw}.sql` |
| elasticsearch | 本地构建（8.19.10 + IK 分词） | 9200 | `docker/elasticsearch/` |
| kibana | kibana:8.19.10 | 5601 | 可选，调试用 |
| qdrant | qdrant/qdrant:v1.16 | 6333/6334 | 字段与指标向量库 |
| embedding | ghcr.io/huggingface/text-embeddings-inference:cpu-1.8 | 8081 | bge-large-zh-v1.5 |
| api | 本地构建 `Dockerfile.backend` | 8000 | FastAPI + LangGraph |
| meta-build | 同上，一次性任务 | - | 建 Qdrant collection + ES 索引 |
| web | 本地构建（前端 + nginx） | 5173 | 反代 `/api` 到 api，SSE 不缓冲 |

## 1. 安装 Docker（需要 sudo）

```bash
sudo apt-get update
sudo apt-get install -y docker.io docker-compose-v2
sudo usermod -aG docker $USER   # 重新登录生效
```

## 2. 配置镜像加速（本机直连 registry-1.docker.io 不通）

```bash
sudo tee /etc/docker/daemon.json >/dev/null <<EOF
{
  "registry-mirrors": ["https://docker.m.daocloud.io", "https://docker.1ms.run"],
  "dns": ["61.145.231.34", "222.200.8.2", "114.114.114.114"]
}
EOF
sudo systemctl restart docker
```

> `dns` 一定要配成本机**实际可用**的解析器（用 `resolvectl status` 看上游）。
> 配成 `223.5.5.5` / `119.29.29.29` 在办公网里是全超时的，表现为**容器内 DNS 全挂**、
> 构建拉不到任何依赖。详见 `fixed-backend-report.md` #2。

## 3. 准备 .env 和模型

```bash
cd "/home/zhensirong/VM-Share/A020-电商问数智能体实战教程/code/shopkeeper-agent"
printf "LLM_API_KEY=<你的 key>\n" > .env

# 模型走 hf-mirror（huggingface.co 本机不可达）
pip install -U "huggingface_hub[cli]"
HF_ENDPOINT=https://hf-mirror.com hf download BAAI/bge-large-zh-v1.5 \
  --local-dir docker/embedding/bge-large-zh-v1.5
```

## 4. 启动

**推荐：一键冷启动（自带前置检查 + 自检）**

```bash
cd docker
./bootstrap.sh              # 确保在跑 + 补元数据 + 全量自检（幂等，可反复执行）
./bootstrap.sh --fresh      # 删掉数据卷从零重建（会清空数据库）
./bootstrap.sh --verify     # 只自检，不动任何东西
```

它会依次做：前置检查（docker 权限 / `.env` 的 LLM key / 1.3GB embedding 权重 / 磁盘 / 内存 /
**宿主 DNS 可达性** / compose 语法）→ `up -d --build` → 等各服务 healthcheck 变 healthy →
**幂等地**决定要不要跑 `meta-build` → 自检（容器状态与重启次数、元数据行数、Qdrant collection、
ES 索引、前端 200、**真实问数**并与纯 SQL 复算对账）。任何一步失败都会给出可执行的修复命令，
退出码非 0 表示还没就绪。

本机实测（镜像已缓存）：**从删卷重建到全量自检通过 221 秒 ≈ 3.7 分钟**。

**手工等价流程**

```bash
cd docker
docker compose up -d --build
# 等 mysql / elasticsearch healthy 后建索引（只跑一次）
docker compose run --rm meta-build
```

打开 http://localhost:5173 。

## 常用操作

```bash
docker compose ps
docker compose logs -f api
docker compose down          # 保留数据卷
docker compose down -v       # 连数据一起删，下次会重新导入 SQL
```

## 注意事项

- `conf/app_config.yaml` 里是 `localhost`，容器内用 `docker/app_config.docker.yaml`（服务名），已通过 volume 覆盖。
- `meta-build` 不是幂等的：重跑前先
  `docker compose exec mysql mysql -udidilili -pdili123 -e "TRUNCATE meta.table_info, meta.column_info, meta.metric_info, meta.column_metric"`
- `meta-build` 在 `tools` profile 中，`docker compose up -d` 不会自动执行；按第 4 节手动 `docker compose run --rm meta-build`。
- compose 默认网络固定为 `172.28.0.0/16`：本机 Wi-Fi 会拿到 `172.18.0.0/17`，与 Docker 默认挑的 `172.18.0.0/16` 重叠后，宿主机访问容器会被路由到 Wi-Fi。
- `api` 的启动参数固定 `--loop asyncio`：本机网络存在 MTU 黑洞，uvloop 会绕过 socket 层补丁，长 prompt 会 47 秒超时。
- 如果部署在正常网络，可去掉该参数，性能更好。
- **启动顺序由 healthcheck 保证**，不要手工"提前"跑 meta-build：
  `embedding` 要加载 1.3GB 权重（实测 ~90s 才 ready）、`api` 首次启动要同步依赖，
  两者都加了 healthcheck，`meta-build` 等 `embedding` healthy、`web` 等 `api` healthy 才启动。
- **性能优化还没开始**：`../docs/OPTIMIZATION-BACKLOG.md` 记录了实测热点（ES 串行检索 4.5–7.6s、
  LLM 往返抖动导致同题 11s~24s）与 P0/P1/P2 清单，**当前刻意未实施**，等先把项目读懂再动手。
  配套探针：`python3 ../docs/hotpath_probe.py --repeat 5`。
