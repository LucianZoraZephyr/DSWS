import ssl

_orig = ssl.create_default_context


def _patched(*a, **k):
    ctx = _orig(*a, **k)
    ctx.maximum_version = ssl.TLSVersion.TLSv1_2
    return ctx


ssl.create_default_context = _patched
