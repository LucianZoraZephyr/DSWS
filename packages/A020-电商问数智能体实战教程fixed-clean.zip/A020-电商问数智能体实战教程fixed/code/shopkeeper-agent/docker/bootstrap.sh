#!/usr/bin/env bash
# =============================================================================
# bootstrap.sh —— 从零把电商问数 Agent 整套栈拉起来并自检（幂等，可重复执行）
#
#   ./bootstrap.sh              确保栈在跑 + 补齐元数据 + 全量自检（默认）
#   ./bootstrap.sh --fresh      删掉数据卷从零重建（会清空数据库）
#   ./bootstrap.sh --verify     只做自检，不动任何东西
#   ./bootstrap.sh --preflight  只做前置检查
#   ./bootstrap.sh --help       用法说明
#
# 权限（脚本里不写死任何密码）：
#   1) 当前用户在 docker 组 → 直接用 docker（推荐：`sudo usermod -aG docker $USER` 后重登）
#   2) 没有组权限 → 需要 sudo：本机可先 `sudo -v` 缓存凭据，或 `SUDO_PASSWORD=xxx ./bootstrap.sh`
#
# 设计原则（每条都对应一次真实踩过的坑，详见 fixed-backend-report.md）：
#   1. 前置资源先查：.env 的 LLM key、1.3GB embedding 权重、磁盘/内存、宿主 DNS
#   2. 顺序由 healthcheck 决定：mysql/ES/TEI/api 全部 healthy 之后才建元数据
#   3. meta-build 非幂等：已有元数据就跳过，绝不重复跑
#   4. 自检用真实问数（真 LLM + 真 MySQL），并和纯 SQL 复算的结果对账
# =============================================================================
set -uo pipefail

cd "$(dirname "$(readlink -f "$0")")"
ROOT="$(pwd)"
ENV_FILE="../.env"
MODEL_DIR="./embedding/bge-large-zh-v1.5"
COMPOSE="docker compose -f $ROOT/docker-compose.yaml"

# 期望的元数据规模与问数结果（与仓库 dw.sql 数据一致）
EXP_TABLES=5; EXP_COLS=24; EXP_METRICS=2; EXP_ORDERS=115
EXPECT_ROWS='华东 107373.0 华南 70202.0 华北 41099.5 西南 31528.0 华中 28957.0'

MODE=ensure; ASSUME_YES=0
for a in "$@"; do
  case "$a" in
    --fresh) MODE=fresh ;;
    --verify) MODE=verify ;;
    --preflight) MODE=preflight ;;
    -y|--yes) ASSUME_YES=1 ;;
    -h|--help) sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "未知参数: $a（--help 看用法）"; exit 2 ;;
  esac
done

# ---------------------------------------------------------------- 输出helper
if [ -t 1 ]; then R=$'\033[31m'; G=$'\033[32m'; Y=$'\033[33m'; B=$'\033[1m'; N=$'\033[0m'
else R=""; G=""; Y=""; B=""; N=""; fi
ok()   { printf '  %s✔%s %s\n' "$G" "$N" "$1"; }
warn() { printf '  %s⚠%s %s\n' "$Y" "$N" "$1"; }
bad()  { printf '  %s✘%s %s\n' "$R" "$N" "$1"; FAILURES=$((FAILURES+1)); }
info() { printf '  %s·%s %s\n' "$B" "$N" "$1"; }
step() { printf '\n%s[%s]%s %s\n' "$B" "$1" "$N" "$2"; }
FAILURES=0

# ------------------------------------------------------- docker 权限（不写密码）
perm_hint() {
  echo "     需要 docker 权限，三选一：" >&2
  echo "       A) sudo usermod -aG docker \$USER && newgrp docker   # 加组后免 sudo（推荐）" >&2
  echo "       B) sudo -v                                          # 缓存 sudo 凭据后重跑" >&2
  echo "       C) SUDO_PASSWORD='<你的密码>' $0 $*" >&2
}
have_docker() {
  [ "$(id -u)" = "0" ] && return 0
  docker info >/dev/null 2>&1 && return 0
  [ -n "${SUDO_PASSWORD:-}" ] && return 0
  sudo -n true >/dev/null 2>&1 && return 0
  return 1
}
D() {
  if [ "$(id -u)" = "0" ]; then docker "$@"
  elif docker info >/dev/null 2>&1; then docker "$@"
  elif [ -n "${SUDO_PASSWORD:-}" ]; then printf '%s\n' "$SUDO_PASSWORD" | sudo -S -p '' docker "$@"
  elif sudo -n true >/dev/null 2>&1; then sudo docker "$@"
  else perm_hint "${@}"; return 126
  fi
}
DC() {
  if [ "$(id -u)" = "0" ]; then $COMPOSE "$@"
  elif docker info >/dev/null 2>&1; then $COMPOSE "$@"
  elif [ -n "${SUDO_PASSWORD:-}" ]; then printf '%s\n' "$SUDO_PASSWORD" | sudo -S -p '' $COMPOSE "$@"
  elif sudo -n true >/dev/null 2>&1; then sudo $COMPOSE "$@"
  else perm_hint compose "$@"; return 126
  fi
}

# =============================================================================
preflight() {
  step 1 "前置检查（preflight）"

  if have_docker; then
    ok "docker 可用（server $(D version --format '{{.Server.Version}}' 2>/dev/null)）"
  else
    bad "docker 权限不足"; perm_hint "${MODE}"; return 1
  fi

  if [ -f "$ENV_FILE" ] && grep -qE '^LLM_API_KEY=.+' "$ENV_FILE"; then ok ".env 存在且 LLM_API_KEY 已设置"
  else bad ".env 缺失或没有 LLM_API_KEY（问数会 401）—— echo 'LLM_API_KEY=<key>' > $ENV_FILE"; fi

  if [ -f "$MODEL_DIR/config.json" ] && { ls "$MODEL_DIR"/*.bin >/dev/null 2>&1 || ls "$MODEL_DIR"/*.safetensors >/dev/null 2>&1; }; then
    ok "embedding 权重就位（$(du -sh "$MODEL_DIR" 2>/dev/null | cut -f1)）"
  else
    bad "embedding 权重缺失：$MODEL_DIR —— HF_ENDPOINT=https://hf-mirror.com hf download BAAI/bge-large-zh-v1.5 --local-dir $MODEL_DIR"
  fi

  free_gb=$(df -BG --output=avail /var/lib/docker 2>/dev/null | tail -1 | tr -dc '0-9'); free_gb=${free_gb:-0}
  [ "$free_gb" -ge 10 ] && ok "docker 数据目录剩余 ${free_gb}GB" || warn "docker 数据目录只剩 ${free_gb}GB（建议 ≥10GB）"
  mem_gb=$(free -g | awk '/^Mem:/{print $7}')
  [ "${mem_gb:-0}" -ge 5 ] && ok "可用内存 ${mem_gb}GB" || warn "可用内存仅 ${mem_gb}GB（ES+TEI+Kibana 约需 5GB，紧张时先 stop kibana）"

  # 宿主 DNS：daemon.json 里配的 resolver 必须真能回 UDP/53
  # （踩坑：本机 223.5.5.5 / 119.29.29.29 全超时 → 容器内 DNS 全挂）
  if [ -f /etc/docker/daemon.json ]; then
    mapfile -t NS < <(python3 -c "
import json
try: print('\n'.join(json.load(open('/etc/docker/daemon.json')).get('dns',[])))
except Exception: pass" 2>/dev/null)
    if [ "${#NS[@]}" -eq 0 ]; then
      warn "daemon.json 未配 dns（默认走宿主 resolv.conf，容器内可能解析不了镜像源）"
    else
      reachable=""
      for ns in "${NS[@]}"; do
        if python3 - "$ns" <<'PY' >/dev/null 2>&1
import socket,sys
q=bytes.fromhex("123401000001000000000000")+b"\x04pypi\x04tuna\x0btsinghua\x03edu\x03cn\x00"+b"\x00\x01\x00\x01"
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.settimeout(3)
s.sendto(q,(sys.argv[1],53)); s.recvfrom(512)
PY
        then reachable="$reachable $ns"; fi
      done
      if [ -n "$reachable" ]; then ok "容器 DNS 可用（可达 resolver:$reachable）"
      else bad "daemon.json 里的 DNS 全部不可达：${NS[*]} —— 换成 resolvectl status 显示的实际上游，见 fixed-backend-report.md #2"; fi
    fi
    python3 -c "
import json,sys
try: m=json.load(open('/etc/docker/daemon.json')).get('registry-mirrors',[])
except Exception: m=[]
sys.exit(0 if m else 1)" 2>/dev/null \
      && ok "已配置 registry-mirrors" \
      || warn "daemon.json 未配 registry-mirrors（直连 registry-1.docker.io 在本机不通）"
  else
    warn "没有 /etc/docker/daemon.json（镜像源/DNS 走默认，可能拉不动镜像）"
  fi

  if DC config -q >/dev/null 2>&1; then ok "docker-compose.yaml 语法正确"
  else bad "docker-compose.yaml 语法错误：见 docker compose config 的输出"; fi
}

# =============================================================================
bring_up() {
  step 2 "拉起容器（build + up）"
  if [ "$MODE" = "fresh" ]; then
    warn "准备删除数据卷（mysql / es / qdrant）并从零重建"
    if [ "$ASSUME_YES" != "1" ]; then
      read -r -p "  确认删除并重建？输入 yes 继续：" ans
      [ "$ans" = "yes" ] || { echo "已取消"; exit 1; }
    fi
    DC down -v || true
  fi
  info "docker compose up -d --build（首次要几分钟，取决于镜像缓存）"
  DC up -d --build || { bad "compose up 失败"; DC logs --tail 40; return 1; }
  ok "容器已启动"
}

# =============================================================================
wait_ready() {
  step 3 "等待各服务就绪（healthcheck 驱动）"
  local deadline=$((SECONDS + 420)) pending=() c st
  local want=(mysql elasticsearch embedding qdrant shopkeeper-api shopkeeper-web)
  while [ $SECONDS -lt $deadline ]; do
    pending=()
    for c in "${want[@]}"; do
      st=$(D inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$c" 2>/dev/null || echo missing)
      case "$st" in healthy|running) ;; *) pending+=("$c:$st") ;; esac
    done
    if [ ${#pending[@]} -eq 0 ]; then ok "全部服务就绪"; return 0; fi
    printf '\r  等待中: %s   ' "${pending[*]}"; sleep 5
  done
  bad "等待超时，仍未就绪：${pending[*]}"
  DC ps -a
  return 1
}

# =============================================================================
meta_counts() {
  D exec mysql mysql -udidilili -pdili123 -N -e \
    "SELECT (SELECT COUNT(*) FROM meta.table_info),(SELECT COUNT(*) FROM meta.column_info),(SELECT COUNT(*) FROM meta.metric_info);" 2>/dev/null | tr -d '\r'
}
ensure_meta() {
  step 4 "元数据（幂等：已有就跳过）"
  local c tables cols metrics
  c=$(meta_counts); IFS=$'\t' read -r tables cols metrics <<<"${c:-0	0	0}"
  if [ "${cols:-0}" -ge "$EXP_COLS" ] && [ "${metrics:-0}" -ge "$EXP_METRICS" ]; then
    ok "元数据已存在（表 $tables / 字段 $cols / 指标 $metrics），跳过 meta-build（它非幂等）"
    return 0
  fi
  info "元数据缺失（表 ${tables:-0} / 字段 ${cols:-0} / 指标 ${metrics:-0}），执行 meta-build"
  DC run --rm meta-build || { bad "meta-build 失败（检查 embedding 是否已 healthy）"; return 1; }
  c=$(meta_counts); IFS=$'\t' read -r tables cols metrics <<<"${c:-0	0	0}"
  [ "${cols:-0}" -ge "$EXP_COLS" ] && ok "meta-build 完成（表 $tables / 字段 $cols / 指标 $metrics）" || { bad "meta-build 后元数据仍不足"; return 1; }
}

# =============================================================================
verify() {
  step 5 "自检（真实问数 + 对账）"
  local c st rc
  for c in mysql elasticsearch embedding qdrant shopkeeper-api shopkeeper-web kibana; do
    st=$(D inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$c" 2>/dev/null || echo missing)
    rc=$(D inspect --format '{{.RestartCount}}' "$c" 2>/dev/null || echo 0)
    if [ "$st" = "healthy" ] || [ "$st" = "running" ]; then
      [ "$rc" -gt 0 ] && warn "$c 状态 $st，但重启过 $rc 次" || ok "$c 状态 $st（重启 0 次）"
    else bad "$c 状态 $st"; fi
  done

  local tables cols metrics orders
  c=$(D exec mysql mysql -udidilili -pdili123 -N -e \
    "SELECT (SELECT COUNT(*) FROM meta.table_info),(SELECT COUNT(*) FROM meta.column_info),(SELECT COUNT(*) FROM meta.metric_info),(SELECT COUNT(*) FROM dw.fact_order);" 2>/dev/null | tr -d '\r')
  IFS=$'\t' read -r tables cols metrics orders <<<"${c:-0	0	0	0}"
  [ "${tables:-0}" -eq "$EXP_TABLES" ] && ok "表 $tables" || bad "表 ${tables:-0}（期望 $EXP_TABLES）"
  [ "${cols:-0}" -eq "$EXP_COLS" ] && ok "字段 $cols" || bad "字段 ${cols:-0}（期望 $EXP_COLS）"
  [ "${metrics:-0}" -eq "$EXP_METRICS" ] && ok "指标 $metrics" || bad "指标 ${metrics:-0}（期望 $EXP_METRICS）"
  [ "${orders:-0}" -eq "$EXP_ORDERS" ] && ok "订单 $orders" || warn "订单 ${orders:-0}（期望 $EXP_ORDERS）"

  local qcol qn esidx
  qcol=$(curl -s --max-time 8 http://127.0.0.1:6333/collections 2>/dev/null)
  qn=$(printf '%s' "$qcol" | grep -o '"name"' | wc -l)
  [ "${qn:-0}" -ge 2 ] && ok "Qdrant collection ×$qn" || bad "Qdrant collection 数量 ${qn:-0}（期望 ≥2）"
  esidx=$(curl -s --max-time 8 'http://127.0.0.1:9200/_cat/indices/value_index?h=docs.count' 2>/dev/null | tr -d ' ')
  [ -n "$esidx" ] && [ "$esidx" -gt 0 ] 2>/dev/null && ok "ES value_index 文档 $esidx" || bad "ES value_index 为空"

  local code
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 http://127.0.0.1:5173/ 2>/dev/null)
  [ "$code" = "200" ] && ok "前端 5173 返回 200" || bad "前端 5173 返回 $code"

  info "发起一次真实问数（经 nginx，真 LLM，约 15–30s）…"
  local t0 el frames rows got want
  t0=$(date +%s)
  payload=$(timeout 120 curl -sN -X POST http://127.0.0.1:5173/api/query \
      -H 'Content-Type: application/json' \
      -d '{"query":"统计 2025 年第一季度各大区的 GMV，并按 GMV 从高到低排序"}' 2>/dev/null)
  el=$(( $(date +%s) - t0 ))
  frames=$(printf '%s' "$payload" | grep -c '^data:')
  rows=$(printf '%s' "$payload" | grep '^data: {"type": "result"' | tail -1 \
        | sed 's/^data: //' | python3 -c "
import json,sys
try:
    d=json.loads(sys.stdin.read() or '{}')
    print(' '.join(f\"{r.get('大区') or r.get('地区') or ''} {r.get('GMV')}\" for r in d.get('data',[])))
except Exception: print('')")
  [ "${frames:-0}" -ge 10 ] && ok "SSE 帧数 $frames（流式，非一次性）" || bad "SSE 帧数 ${frames:-0} 异常"
  got=$(printf '%s' "$rows" | tr -s ' ' | sed 's/^ //')
  want=$(printf '%s' "$EXPECT_ROWS" | tr -s ' ' | sed 's/^ //')
  if [ "$got" = "$want" ]; then ok "问数结果与基线一致（${el}s）：$got"
  else bad "问数结果不符：得到 [$got] 期望 [$want]"; fi

  local sql sum_got sum_sql
  sql=$(D exec mysql mysql -udidilili -pdili123 -N -e \
    "SELECT CONCAT(dr.region_name,' ',ROUND(SUM(fo.order_amount),1)) FROM dw.fact_order fo
     JOIN dw.dim_region dr ON fo.region_id=dr.region_id
     JOIN dw.dim_date dd ON fo.date_id=dd.date_id
     WHERE dd.year=2025 AND dd.quarter='Q1' GROUP BY dr.region_name ORDER BY 2 DESC;" 2>/dev/null | tr '\n' ' ' | tr -s ' ' | sed 's/^ //')
  if [ -n "$sql" ]; then
    sum_got=$(printf '%s' "$got" | tr ' ' '\n' | grep -E '^[0-9.]+$' | paste -sd+ | bc 2>/dev/null)
    sum_sql=$(printf '%s' "$sql" | tr ' ' '\n' | grep -E '^[0-9.]+$' | paste -sd+ | bc 2>/dev/null)
    if [ -n "$sum_got" ] && [ -n "$sum_sql" ] && [ "$sum_got" = "$sum_sql" ]; then
      ok "与纯 SQL 复算一致（合计 $sum_got）—— 不是假数据"
    else warn "与纯 SQL 复算对不上（应用 $sum_got vs SQL $sum_sql）"; fi
  fi
}

# =============================================================================
case "$MODE" in
  preflight) preflight ;;
  verify)    verify ;;
  fresh)     preflight && bring_up && wait_ready && ensure_meta && verify ;;
  ensure)    preflight && bring_up && wait_ready && ensure_meta && verify ;;
esac

printf '\n%s%s%s\n' "$B" "────────────────────────────────────────────────" "$N"
if [ "$FAILURES" -eq 0 ]; then
  printf '%s全部通过 ✔%s  前端 http://127.0.0.1:5173  接口 http://127.0.0.1:8000/docs\n' "$G" "$N"
else
  printf '%s%d 项检查未通过 ✘%s  详见上方输出与 docker/fixed-backend-report.md\n' "$R" "$FAILURES" "$N"
fi
exit $(( FAILURES > 0 ? 1 : 0 ))
