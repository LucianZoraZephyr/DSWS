# 把后端跑通：方法与修复全记录（fixed-backend-report）

> **时间**：2026-10-20 09:18 – 12:57（CST）
> **范围**：只动**容器化资产**——`docker/Dockerfile.backend`、`docker/app_config.docker.yaml`、
> `docker/docker-compose.yaml`、`shopkeeper-agent-frontend/Dockerfile`，以及宿主机的 `/etc/docker/daemon.json`。
> **应用源码 `code/shopkeeper-agent/app/**`、`conf/**`、`prompts/**` 一行未改**（有意为之）。
> **配套文档**：`docker/HANDOFF.md`（第 9 节是"完成了什么"）、`docker/README.md`（部署说明）、
> `docker/bootstrap.sh`（从零重跑的一条命令 + 自检，见第 6 节）、
> `docs/OPTIMIZATION-BACKLOG.md`（性能热点实测与优化清单，**刻意未实施**）。
> 本报告是**方法论**层面的展开：每一类问题是怎么被定位出来的、依据是什么。

---

## 0. 摘要

**起点**：仓库里已经写好了 `docker/` 目录（compose、Dockerfile、配置、模型权重），但**一个容器都起不来**——
构建阶段卡在拉取 BuildKit 前端镜像，随后是容器内 DNS 全挂、PyPI/npm 拉不动、`asyncmy` 编译失败、
api/meta-build 启动即崩、宿主机访问 5173/8000 一直挂、nginx 反代找不到 upstream、每次 `up -d` 都重跑非幂等的
`meta-build`、容器启动时 `uv run` 反复下载 ruff/virtualenv。

**终点**：7 个容器全部 Up、重启计数 0（mysql / elasticsearch 报 healthy），元数据落库
（表 5 / 字段 24 / 指标 2 / 订单 115，Qdrant 2 个 collection，ES `value_index` 75 docs），
真实问数链路 11 个节点全 success、约 15s 返回
`华东 107373.0 / 华南 70202.0 / 华北 41099.5 / 西南 31528.0 / 华中 28957.0`，
nginx 反代下的 SSE **逐帧到达**（不是一次性缓冲），浏览器实测 5 行结果、0 console 错误、0 失败请求，
同一批数字用纯 MySQL 手写 SQL 复算完全一致（证明不是假数据）。

**一共修了 10 类问题**，分布很说明问题：**应用配置本身只有 1 条**（#6 OmegaConf 插值，而且只错在新写的
容器配置副本里，仓库原配置本来就是对的）；**镜像构建 4 条**（#1 syntax 行、#3 PyPI 镜像、#4 缺编译器、
#5 npm 镜像）；**编排 / 网络 4 条**（#2 daemon DNS、#7 子网重叠、#8 网络别名、#9 非幂等任务 profile）；
**运行时健壮性 1 条**（#10 `UV_NO_DEV`）。

即：**10 条里只有 1 条是"应用自己的 bug"，其余 9 条全是"把一个能跑的 Python 项目搬进容器"必然遇到的
镜像 / 编排 / 宿主网络问题**。这类问题的通用解法不在业务代码里，而在"分层隔离 + 读原始报错"（第 3 节）。

---

## 1. 修复清单总表

| # | 症状 | 根因 | 修复动作 | 涉及文件 | 定位手段 | 状态 |
|---|---|---|---|---|---|---|
| 1 | 构建卡在 `resolve image config` 拉 `docker/dockerfile:1` | BuildKit 前端镜像要从 Docker Hub 拉，本机直连不通，mirror 不覆盖这种引用 | 删掉两个 Dockerfile 里的 `# syntax=docker/dockerfile:1` 行 | `docker/Dockerfile.backend`、`shopkeeper-agent-frontend/Dockerfile` | 读构建日志停在哪个 step（`load build definition` vs `resolve image config`） | 已修 |
| 2 | 构建容器内 DNS 全挂（`dns error: failed to lookup address information`） | `/etc/docker/daemon.json` 里的 `223.5.5.5` / `119.29.29.29` 在本网络 UDP/53 超时 | daemon.json 的 dns 换成 `61.145.231.34`、`222.200.8.2`、`114.114.114.114`，重启 Docker（原文件备份为 `/etc/docker/daemon.json.bak-20261020`） | **宿主环境** `/etc/docker/daemon.json` | `docker run --rm alpine` 最小探针单独测容器内解析，与宿主 `getent hosts` 对照 | 已修 |
| 3 | `uv sync` 拉 `files.pythonhosted.org` 失败 | 该域名在容器内解析失败 / 直连不可达 | `Dockerfile.backend` 加 `ARG UV_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple` + `ENV UV_DEFAULT_INDEX` / `UV_INDEX_URL` | `docker/Dockerfile.backend` | 容器内 `getent hosts files.pythonhosted.org` + 查 PyPI 官方 JSON 接口比对 | 已修 |
| 4 | `error: Failed to build asyncmy==0.2.11` | asyncmy 0.2.11 只有 cp39–cp313 wheel，基础镜像是 Python 3.14 → uv 回退源码编译，而镜像里没有编译器 | 镜像内 `apt-get install -y --no-install-recommends gcc libc6-dev` | `docker/Dockerfile.backend` | 日志里 grep `No such file or directory: 'gcc'`；查 PyPI JSON 接口确认 wheel tag | 已修 |
| 5 | 前端 `npm ci` 不稳 | `registry.npmjs.org` 在本机不稳 | 前端 Dockerfile 加 `ARG NPM_REGISTRY=https://registry.npmmirror.com` + `npm config set registry` | `shopkeeper-agent-frontend/Dockerfile` | 容器内 `npm view` 对比两个 registry 的连通性/耗时 | 已修 |
| 6 | api / meta-build 容器一起来就崩：`omegaconf.errors.UnsupportedInterpolationType: Unsupported interpolation type LLM_MODEL_NAME` | `docker/app_config.docker.yaml` 用的是 shell 语法 `${LLM_MODEL_NAME:-deepseek-flash}`，OmegaConf 会把它当自己的插值解析 | 改成 `${oc.env:LLM_MODEL_NAME,deepseek-flash}`、`${oc.env:LLM_BASE_URL,https://api.deepseek.com/v1}` | `docker/app_config.docker.yaml` | `docker compose ps -a` 看退出码 + `docker compose logs api` 读 OmegaConf traceback | 已修 |
| 7 | 宿主机访问 `127.0.0.1:5173` / `:8000` 一直挂（TCP 连上但 0 字节），容器内互相访问正常 | Wi-Fi 拿到 `172.18.70.185/17`，与 Docker 默认选的 `172.18.0.0/16` 重叠，宿主机把容器 IP 路由到 Wi-Fi | compose 显式固定默认网络 `172.28.0.0/16`（`networks.default.ipam.config`） | `docker/docker-compose.yaml` | `ip route get <容器IP>`：看流量到底走哪块网卡 | 已修 |
| 8 | web 容器重启循环：`nginx: [emerg] host not found in upstream "api"` | 本机 Docker 未给服务名注册网络别名，只有容器名 `shopkeeper-api` 能解析 | api 服务加 `networks.default.aliases: [api]` | `docker/docker-compose.yaml` | 容器内 `getent hosts api` vs `getent hosts shopkeeper-api` | 已修 |
| 9 | 每次 `docker compose up -d` 都会重跑 `meta-build`（该任务**非幂等**） | compose 默认启动所有服务 | 给 `meta-build` 加 `profiles: ["tools"]`；仍用 `docker compose run --rm meta-build` 手动执行 | `docker/docker-compose.yaml` | `docker compose config --services` 看默认 profile 包含谁 | 已修 |
| 10 | 容器启动卡在 `uv run` 下载 ruff / virtualenv | 运行时 `uv run` 默认会同步 dev 依赖组，镜像里是用 `--no-dev` 装的 | `Dockerfile.backend` 增加 `ENV UV_NO_DEV=1` | `docker/Dockerfile.backend` | `docker compose logs --tail 30` 看启动时是否在下载 | 已修 |

> 第 5 节另列 **8 条发现但没修**的问题（全是产品 / 代码层的，与本次容器化无关）。

---

## 2. 逐项详解

### 2.1 #1 构建卡在 `resolve image config`

**症状**（`/tmp/compose-up.log` 原始摘录）：

```
#13 [meta-build] resolve image config for docker-image://docker.io/docker/dockerfile:1
#14 sha256:9d2b4f57f9e20f33279375ce25c6ff14f30f64270ed5c7b613b2b30256754f62 0B / 14.28MB 0.2s
#14 CANCELED
```

注意"卡住"的位置：**不在 `load build definition`，而在 `resolve image config`**——Dockerfile 已读进去，
但 BuildKit 想先拉一个"构建前端镜像"。

**根因**：两个 Dockerfile 首行的 `# syntax=docker/dockerfile:1` 告诉 BuildKit"用 docker/dockerfile:1 这个镜像里的
前端来解析本文件"。前端镜像本身要从 Docker Hub 拉，本机**直连 Docker Hub 不通**，`registry-mirrors` 只覆盖普通
镜像、覆盖不了这个特殊引用 → 拉不动 → 挂起后被取消。

**定位手段**：

```sh
grep -n "resolve image config\|load build definition\|CANCELED" /tmp/compose-up.log
grep -rn "^# syntax=" docker/Dockerfile.backend ../shopkeeper-agent-frontend/Dockerfile
```

**修复**（**仓库文件**）：两个文件各删掉那一行。两个 Dockerfile 只用了 `COPY / RUN / ENV / CMD` 等基础指令，
不需要新语法前端。

```sh
sed -i '/^# syntax=docker\/dockerfile:1$/d' docker/Dockerfile.backend
sed -i '/^# syntax=docker\/dockerfile:1$/d' ../shopkeeper-agent-frontend/Dockerfile
```

---

### 2.2 #2 构建容器内 DNS 全挂

**症状**（`/tmp/shopkeeper-compose-up.log` 原始摘录）：

```
#24 24.29 error: Failed to download `orjson==3.11.8`
#24 24.29   cause: Request failed after 3 retries in 23.8s
#24 24.29   cause: Failed to fetch: https://files.pythonhosted.org/packages/8d/c7/.../orjson-3.11.8-cp314-cp314-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
#24 24.29   cause: error sending request for url (https://files.pythonhosted.org/...)
#24 24.29   cause: client error (Connect)
#24 24.29   cause: dns error
#24 24.29   cause: failed to lookup address information: Try again
```

**根因**：`/etc/docker/daemon.json` 里写了 `"dns": ["223.5.5.5", "119.29.29.29"]`。Docker 把 `dns` 下发给**所有**容器，
容器里的 glibc 解析器就只打这两个服务器；而这两个公共 DNS（阿里 / 腾讯）在本次办公网里 **UDP/53 超时**，
于是容器内**任何**域名都解析不了。关键对照：宿主自己解析是好的（走 systemd-resolved 拿 DHCP 下发的 DNS），
**只有容器挂**——这个对照正是判断"问题在 daemon 配置层而非应用层"的第一手依据。

**定位手段**：

```sh
cat /etc/docker/daemon.json
docker run --rm alpine sh -c 'cat /etc/resolv.conf; nslookup pypi.org'
getent hosts pypi.org
```

**修复**（**宿主环境**，不是仓库文件）：把 dns 换成本机 DHCP 实际下发的两个 + 一个公共兜底，原文件先备份。

```bash
cp /etc/docker/daemon.json /etc/docker/daemon.json.bak-20261020
# 新内容："dns": ["61.145.231.34", "222.200.8.2", "114.114.114.114"]
sudo systemctl restart docker
```

改完重启 Docker 后，同一次构建里 `apt-get` 就通了（`/tmp/shopkeeper-compose-up3.log`）：
`#21 5.065 Fetched 10.0 MB in 5s (2072 kB/s)`。

---

### 2.3 #3 `uv sync` 拉 `files.pythonhosted.org` 失败

**症状**：与 #2 同源（上面那段 `Failed to fetch: https://files.pythonhosted.org/...`），但**处置不同**：
DNS 修好后该域名在本网络仍不可达/极慢，而 uv 默认 index 就是 PyPI 官方源。

**根因**：uv 默认走 `https://pypi.org/simple`，实际下载落到 `files.pythonhosted.org`。该域名在本网络不可用，
构建就卡在 `uv sync`。**修 DNS 只解决"解析不了"，解决不了"这个域名根本连不通"**，所以还要换 index。

**定位手段**：

```sh
docker run --rm --entrypoint sh python:3.14-slim -c \
  'getent hosts files.pythonhosted.org; wget -S --spider https://files.pythonhosted.org/ 2>&1 | head'
curl -s https://pypi.org/pypi/<pkg>/<ver>/json | python3 -c \
  'import json,sys; d=json.load(sys.stdin); print([u["filename"] for u in d["urls"]])'
```

**修复**（**仓库文件** `docker/Dockerfile.backend` 第 3–7 行）：固定国内 PyPI 镜像，可用
`--build-arg UV_INDEX=...` 覆盖。

```dockerfile
ARG UV_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple
ENV UV_DEFAULT_INDEX=${UV_INDEX} \
    UV_INDEX_URL=${UV_INDEX}
```

修完后同一次构建的下载全部成功（`/tmp/shopkeeper-compose-up3.log`）：
`#25 1.139 Downloading tiktoken (1.1MiB)` … `#25 7.324 Downloaded numpy`。

---

### 2.4 #4 `error: Failed to build asyncmy==0.2.11`

**症状**（`/tmp/shopkeeper-compose-up2.log` 原始摘录）：

```
#24 3.153    Building asyncmy==0.2.11
#24 11.49 error: Failed to build `asyncmy==0.2.11`
#24 11.49   cause: The build backend returned an error
#24 11.49   cause: Call to `poetry.core.masonry.api.build_wheel` failed (exit status: 1)
#24 11.49          gcc -fno-strict-overflow ... -c asyncmy/charset.c -o .../charset.o
#24 11.49          error: [Errno 2] No such file or directory: 'gcc'
#24 11.49 hint: `asyncmy` (v0.2.11) was included because `shopkeeper-agent` (v0.1.0) depends on `asyncmy`
```

**根因**：asyncmy 是 Cython 扩展。实测 PyPI JSON 接口（`https://pypi.org/pypi/asyncmy/0.2.11/json`），
它的 wheel 只有 `cp39 / cp310 / cp311 / cp312 / cp313`——**没有 cp314**。而基础镜像是 `FROM python:3.14-slim`
→ uv 找不到可用 wheel，就回退到**源码编译**；`python:3.14-slim` 里**没有 gcc**，编译在第一步就挂了。

**定位手段**：

```sh
grep -n "No such file or directory: 'gcc'\|Failed to build" /tmp/shopkeeper-compose-up2.log
curl -s https://pypi.org/pypi/asyncmy/0.2.11/json | python3 -c \
  'import json,sys; d=json.load(sys.stdin); print(sorted({u["filename"].split("-")[2] for u in d["urls"] if u["packagetype"]=="bdist_wheel"}))'
# -> ['cp310', 'cp311', 'cp312', 'cp313', 'cp39']
```

> 这一步的意义：**先确认是"没有 wheel"而不是"wheel 坏掉"**。若 wheel 存在，装编译器就是白折腾；
> 确认之后"装编译器"才是唯一正确的选项（另一个选项是把基础镜像降到 Python 3.13，
> 但那会牵动 `uv.lock` 与 venv 路径，风险更大）。

**修复**（**仓库文件** `docker/Dockerfile.backend` 第 14–17 行）：补上 C 工具链。

```dockerfile
RUN apt-get update \
  && apt-get install -y --no-install-recommends gcc libc6-dev \
  && rm -rf /var/lib/apt/lists/*
```

修复后同一个包编译成功（`/tmp/shopkeeper-compose-up3.log`）：
`#25 3.026 Building asyncmy==0.2.11` → `#25 65.67 Built asyncmy==0.2.11`。

---

### 2.5 #5 前端 `npm ci` 不稳

**症状**：`web` 镜像构建时 `npm ci` 在 `registry.npmjs.org` 上长时间无响应 / 间歇失败，
导致 `docker compose up -d --build` 整体卡住。

**根因**：`registry.npmjs.org` 在本网络不稳定（与 #2/#3 同源：境外 CDN 链路质量差）。与 #3 的差别在于：
npm 官方 registry **能解析**，只是**不稳**，所以症状是"时好时坏 / 卡住"而非"立刻报错"。

**定位手段**：

```sh
docker run --rm node:22-alpine sh -c 'npm config get registry; npm view react version'
curl -o /dev/null -s -w 'npmjs     : %{http_code} %{time_total}s\n' https://registry.npmjs.org/react
curl -o /dev/null -s -w 'npmmirror : %{http_code} %{time_total}s\n' https://registry.npmmirror.com/react
```

**修复**（**仓库文件** `shopkeeper-agent-frontend/Dockerfile` 第 4–7 行）：

```dockerfile
ARG NPM_REGISTRY=https://registry.npmmirror.com
RUN npm config set registry "$NPM_REGISTRY" \
  && (npm ci --no-audit --no-fund || npm install --no-audit --no-fund)
```

（`|| npm install` 是兜底：`package-lock.json` 与 `package.json` 不同步时 `npm ci` 会直接失败。）
修复后（`/tmp/shopkeeper-compose-up3.log`）：

```
#47 [web build 4/6] RUN npm config set registry "https://registry.npmmirror.com"  && (npm ci --no-audit --no-fund || npm install --no-audit --no-fund)
#47 5.490 added 136 packages in 5s
```

---

### 2.6 #6 api / meta-build 一起就崩（OmegaConf 插值）

**症状**：容器一起来就退出，退出码 1，`docker compose logs api` 里是：

```
omegaconf.errors.UnsupportedInterpolationType: Unsupported interpolation type LLM_MODEL_NAME
```

`LLM_BASE_URL` 同理报 `Unsupported interpolation type LLM_BASE_URL`。

**根因**：OmegaConf 自己的插值语法是 `${oc.env:VAR,default}`，而 `${LLM_MODEL_NAME:-deepseek-flash}`
是 **shell** 的默认值语法。OmegaConf 解析时把 `LLM_MODEL_NAME:-deepseek-flash` 整体当成一个"插值类型名"，
而它没注册过 → 抛 `UnsupportedInterpolationType`。值得记一笔：**仓库原配置 `conf/app_config.yaml`
本来就是对的**（第 43 行写的是 `${oc.env:LLM_API_KEY}`），是这次新写的容器配置副本
`docker/app_config.docker.yaml` 抄成了 shell 习惯。

**定位手段**：

```sh
docker compose ps -a
docker compose logs --tail 50 api
docker compose logs --tail 50 meta-build
docker compose exec api python -c \
  "from omegaconf import OmegaConf; OmegaConf.load('/app/conf/app_config.yaml')" 2>&1 | tail -5
```

**修复**（**仓库文件** `docker/app_config.docker.yaml` 第 43 / 45 行）：

```yaml
llm:
  model_name: ${oc.env:LLM_MODEL_NAME,deepseek-flash}
  api_key: ${oc.env:LLM_API_KEY}
  base_url: ${oc.env:LLM_BASE_URL,https://api.deepseek.com/v1}
```

> 这是**本次 10 条里唯一一条"应用配置本身写错"**的问题，而且错在新建的容器副本里，不是仓库原配置。

---

### 2.7 #7 宿主机访问 5173 / 8000 一直挂

**症状**：宿主上 `curl http://127.0.0.1:5173/` / `:8000` 一直挂着——**TCP 能连上，但一个字节都读不到**，
连接不报错也不返回；而**容器之间互相访问完全正常**（api → mysql / qdrant / elasticsearch 都通）。

**根因**：本机办公网 Wi-Fi 拿到了 `172.18.70.185/17`，也就是 **172.18.0.0/16** 这个网段；而 Docker 默认给
bridge 网络挑的网段恰好也是 `172.18.0.0/16`（Docker 会依次尝试 172.17、172.18…）。宿主机路由表里
172.18.0.0/16 已经有 Wi-Fi 那条（直连、更具体），于是**宿主机访问容器 IP 的包被路由到 Wi-Fi 而不是网桥**，
包出不去 → 表现为"连上了但没数据"。

**定位手段**（本次最有价值的一次诊断）：

```sh
ip -4 addr show | grep -E 'inet '
docker network inspect bridge --format '{{(index .IPAM.Config 0).Subnet}}'
docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' shopkeeper-api
ip route get <容器IP>
```

第 1 条会看到 `172.18.70.185/17`（与 Docker 默认的 `172.18.0.0/16` 撞了）；最后一条 `ip route get` 是**关键**：
它直接告诉你这条流量**打算走哪块网卡**——若走 `wlan0`，说明流量根本没进网桥，问题定位到路由层。

**修复**（**仓库文件** `docker/docker-compose.yaml` 第 142–148 行）：把默认网络固定到不冲突的网段。

```yaml
networks:
  default:
    ipam:
      config:
        - subnet: 172.28.0.0/16
```

---

### 2.8 #8 web 容器重启循环（nginx 找不到 upstream）

**症状**：web 容器不停重启，`docker compose logs web` 里：

```
nginx: [emerg] host not found in upstream "api"
```

**根因**：`shopkeeper-agent-frontend/nginx.conf` 里 `proxy_pass http://api:8000;`，要求 Docker 内嵌 DNS 把
**服务名** `api` 解析成容器 IP。但本机 Docker 版本**不会自动给服务名注册网络别名**，只注册**容器名**
`shopkeeper-api`。容器内 `getent hosts api` 解析失败 → nginx 启动即 emerg 退出 → restart 循环。

**定位手段**：

```sh
docker compose exec web getent hosts api
docker compose exec web getent hosts shopkeeper-api
docker compose exec web cat /etc/nginx/conf.d/default.conf
docker compose logs --tail 20 web
```

前两条**一次区分两个假设**：如果"容器名能解析、服务名不能"，就是别名缺失，而不是 DNS 坏了。

**修复**（**仓库文件** `docker/docker-compose.yaml` 第 80–85 行）：显式注册服务名别名。

```yaml
  api:
    container_name: shopkeeper-api
    networks:
      default:
        aliases:
          - api
```

---

### 2.9 #9 `meta-build` 每次 `up -d` 都重跑

**症状**：每次 `docker compose up -d` 都会重新执行 `meta-build`；由于该任务**非幂等**，第二次开始就报
`Duplicate entry 'dim_region.region_id' for key 'PRIMARY'`（见 `HANDOFF.md` 第 6 节第 1 条）。

**根因**：compose 默认启动**所有**服务。`meta-build` 是个"建一次向量库/全文索引"的一次性任务，
和常驻服务混在一起，就必然每次都跑。

**定位手段**：

```sh
docker compose config --services
docker compose ps -a
```

**修复**（**仓库文件** `docker/docker-compose.yaml` 第 113–115 行）：把一次性任务挪进独立 profile，
日常启动变成 `docker compose up -d`（不含 meta-build），需要重建索引时显式
`docker compose run --rm meta-build`（重跑前先 TRUNCATE `meta.*` 四张表）。

```yaml
  meta-build:
    profiles: ["tools"]
```

---

### 2.10 #10 容器启动卡在 `uv run` 下载 ruff / virtualenv

**症状**（`/tmp/shopkeeper-meta-build.log` 第 5–9 行原始摘录）：

```
Downloading virtualenv (5.6MiB)
Downloading ruff (10.8MiB)
Downloaded virtualenv
Downloaded ruff
Installed 9 packages in 86ms
```

**根因**：镜像里是用 `uv sync --frozen --no-dev` 装的（故意不含 dev 依赖组），但**运行时** `uv run` 默认会再同步一次，
并把 dev 组（`ruff`、`virtualenv`）拉回来。结果就是每次容器启动都要额外下 16MB，弱网下就是"启动卡住"。

**定位手段**：

```sh
docker compose logs --tail 30 meta-build
docker compose exec api uv pip list | grep -iE 'ruff|virtualenv'
```

第二条用来确认 dev 依赖确实**不在镜像里**（说明是运行时被拉回来的，不是镜像本来就带了）。

**修复**（**仓库文件** `docker/Dockerfile.backend` 第 40–41 行）：

```dockerfile
ENV UV_NO_DEV=1
```

---

## 3. 方法论：这套问题是怎么定位的

本节是本报告的重点。10 条问题没有一条是"读代码读出来的"，全部靠**分层 + 第一手证据**定位。

### 3.1 分层隔离：宿主机 → daemon → 容器网络 → 容器内应用

每一层用**最小探针**单独确认边界，不要一上来就在完整项目里试：

| 层 | 最小探针 | 能回答的问题 |
|---|---|---|
| 宿主机 | `getent hosts pypi.org` | 是不是"整个网络都不通"？ |
| Docker daemon | `cat /etc/docker/daemon.json` | daemon 下发的 DNS / mirror 是什么？ |
| 容器网络（通用） | `docker run --rm alpine sh -c 'cat /etc/resolv.conf; nslookup pypi.org'` | 容器里能不能解析？跟宿主差在哪？ |
| 容器网络（项目） | `docker compose exec <svc> getent hosts <svc2>` | 服务名 / 容器名分别能不能解析？ |
| 容器内应用 | `docker compose logs --tail 50 <svc>` | 应用自己报什么？ |

**关键判断**：#2 的 DNS 问题与 #7 的路由问题，在宿主侧表现完全不同——

- DNS 问题：宿主 `getent hosts` 正常，容器内 `nslookup` 失败 → 边界在 **daemon → 容器**之间；
- 路由问题：容器之间互通正常，宿主访问不通 → 边界在 **宿主 → 网桥**之间。

不分层的话，这两类都会表现为"curl 就是不通"，很容易混为一谈。

### 3.2 读原始报错，不猜

所有判断都来自第一手输出，不来自"听起来像是什么"：

- **uv 的 build 日志**（`/tmp/shopkeeper-compose-up*.log`）：`#NN <step> <step-name>` + 时间戳 + 输出，
  直接给出 `cause:` 链（`Request failed → client error (Connect) → dns error → failed to lookup address information`）。
- **`docker compose ps -a`**：看**退出码**，区分"崩了"（exit 1）和"没起来"（Created / Exited 0）。
- **OmegaConf traceback**：异常类型本身就点名了根因（`UnsupportedInterpolationType`）。
- **nginx error log**：`[emerg] host not found in upstream "api"` 一行就说明是 DNS 名字而不是端口问题。
- **应用日志**：`/tmp/shopkeeper-meta-build.log` 逐行带 `request_id - 1`，这是 3.8 节的前提。

> 教训：#4 如果不读日志，很容易直接去"重装依赖 / 换 Python 版本"；
> 而日志里明明白白写着 `error: [Errno 2] No such file or directory: 'gcc'`——缺的是编译器，不是版本。

### 3.3 用路由表判断"能连但没数据"

`curl` 一直挂着、TCP 连上但 0 字节，这种"半通"状态最容易被误判成"服务没起来"。
判据是 `ip route get <目标 IP>`：它直接告诉你内核**打算**把这个包从哪块网卡出去。

```sh
ip route get 172.18.0.2
# 走到 wlan0 ⇒ 流量根本没进网桥 ⇒ 问题在宿主路由，不在容器里
```

这一步把"服务坏了"和"网络走错了路"彻底分开。

### 3.4 用 `getent hosts` 区分"服务名别名"与"容器名"

`nginx: host not found in upstream "api"` 有两种可能：nginx 配置写错，或 `api` 这个名字解析不了。
一条命令同时验证两个假设：

```sh
docker compose exec web getent hosts api              # 空
docker compose exec web getent hosts shopkeeper-api   # 有 IP
```

**"一个能解析、一个不能"** 就是"别名缺失"的铁证，而不是"DNS 坏了"。

### 3.5 先查接口确认事实，再决定动作

不要在容器里盲试 `pip install`。PyPI 有 JSON 接口，直接问它"到底有没有 cp314 的 wheel"：

```sh
curl -s https://pypi.org/pypi/asyncmy/0.2.11/json | python3 -c \
  'import json,sys; d=json.load(sys.stdin); print(sorted({u["filename"].split("-")[2] for u in d["urls"] if u["packagetype"]=="bdist_wheel"}))'
# -> ['cp310', 'cp311', 'cp312', 'cp313', 'cp39']   ← 没有 cp314
```

确认"确实没有 wheel"之后，"装编译器"才是唯一正确的动作。同样的手法也用来验证 PyPI 官方源与国内镜像各自可达性。

### 3.6 先用 `docker compose config -q` 验 YAML，再看 `ps -a` 看退出码

- `docker compose config -q`：**YAML / schema 层面的错**（缩进、字段拼错、profile 写错）在这里就报，
  不用等到容器起来才发现。
- `docker compose config --services`：列出**默认 profile** 实际会启动的服务——#9 就是靠这一条
  发现 `meta-build` 混在默认服务里的。
- `docker compose ps -a`：看**退出码**，把"崩了"和"没起来"分开。

### 3.7 最后用真实用户路径复验，而且要逐帧计时

**curl 走一遍 SSE**：`curl -N` 关掉缓冲，直接看 SSE 是否逐帧到达。

```sh
curl -N -X POST http://127.0.0.1:8000/api/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"统计2025年第一季度各大区的GMV，并按GMV从高到低排序"}'
```

只看到"最后一次性吐出全部内容"是不够的——那说明 nginx / 中间层把流缓冲了。
本次用了一个按 `\n\n` 切帧并打时间戳的小脚本（`/tmp/sse_timing.py`），分别打 `8000`（直连 api）和
`5173`（经 nginx），确认**经 nginx 也是逐帧到达**（对应 `nginx.conf` 里的 `proxy_buffering off;`）。

**再用真实浏览器跑一遍**：playwright-core + 本机 `/usr/bin/google-chrome`，走 `http://127.0.0.1:5173`，
点样例卡片 → 回车 → 等 `查询完成，共 5 行结果。` → 数表格行数 → 监听 console error / pageerror / requestfailed。
本次结果：**5 行结果、0 console 错误、0 失败请求**（脚本见 `/tmp/docker-verify/check.mjs`）。

> 只有 curl 不算数：curl 走的是 api 容器，浏览器走的是 **nginx → api** 这条真实用户路径，
> 它才能暴露反代层的 SSE 缓冲、静态资源路径、JS 运行时错误这些问题。

### 3.8 日志与结果对齐：按 `request_id` 配对 + 结果行逐行比对

**并发时同一时间窗里有多个请求，不能按时间戳猜。** 录制 10 道题时，其他 worker 也在打同一个后端，
日志时间窗里混着别人的请求。正确做法（脚本 `/tmp/ux-verify/merge_sql.py`）：

1. 用正则 `request_id - ([0-9a-f-]{36})` 从日志行里抽出 `request_id`，把后续的
   `生成的SQL：` 与 `SQL执行结果：` 归到同一个 `request_id` 下；
2. 把 `SQL执行结果：` 的内容用 `ast.literal_eval` 解析成行列表，**规范化**成"键序无关、类型一致"的元组
   （日志里是 `Decimal('10')`，SSE JSON 里是 `"10"`，需先把 `Decimal('x')` 归一成 `'x'` 才能比对）；
3. 用 catalog 里每道题**实际拿到的结果行**去反查是哪个 `request_id`——**用结果行逐行比对反查**，
   而不是用时间戳；
4. 同结果可能对应多个请求时，再取发起时间最接近的那个。

本次 **10/10 全部命中**，`request_id` 与 `generatedSql` 已写回 `/tmp/ux-human-video/catalog.json`
和 `ux-examples-catalog.md` 的主表。

> 这一步的价值：只有拿到"这道题对应的**那条 SQL**"，才能判断结果对不对是 LLM 的问题还是数仓的问题。
> 拿不到 SQL 就只能看到"数字对不对"，看不到"为什么对"。

### 3.9 中间产物一律落在 `/tmp` 下的独立目录

本次所有脚本、日志、原始 SSE、逐帧时间戳、浏览器截图都放在 `/tmp/ux-verify/`、`/tmp/ux-human-video/`、
`/tmp/docker-verify/`，构建日志放 `/tmp/shopkeeper-compose-up*.log`。
**仓库目录全程只读**——这不只是洁癖：容器化资产的改动必须能被人一眼看完，
中间产物混进仓库会让 diff 失去意义。

---

## 4. 最终验证证据

### 4.1 容器健康

`docker compose ps`：7 个容器全部 **Up**，**重启计数 0**；`mysql` / `elasticsearch` 报 **healthy**
（其余为 qdrant / embedding / kibana / api / web）。构建与启动过程见 `/tmp/shopkeeper-compose-up3.log` 结尾
（`api Built / elasticsearch Built / meta-build Built / web Built`，随后各容器 Created → Started，
mysql/elasticsearch 走到 `Healthy`）。

### 4.2 元数据与索引

| 项 | 实测 |
|---|---|
| `dw` 库表 | 5（`dim_region` / `dim_customer` / `dim_product` / `dim_date` / `fact_order`，见 `docker/mysql/dw.sql`） |
| `meta.table_info` | 5 表 |
| `meta.column_info` | 24 字段 |
| `meta.metric_info` | 2 指标 |
| `dw.fact_order` | 115 条订单（`docker/mysql/dw.sql` 的 INSERT 共 115 个值元组，`date_id` 覆盖 20250101–20250331） |
| Qdrant | 2 个 collection |
| ES `value_index` | 75 docs |

### 4.3 真实问数

`POST http://127.0.0.1:8000/api/query`，问题「统计 2025 年第一季度各大区的 GMV，并按 GMV 从高到低排序」：

```
抽取关键词 → 召回字段信息 → 召回指标信息 → 召回字段取值 → 合并召回信息 →
过滤指标信息 → 过滤表信息 → 添加额外上下文 → 生成SQL → 校验SQL → 执行SQL
```

**11 个节点全部 success**，约 15s，结果：

```
{"大区": "华东", "GMV": 107373.0}
{"大区": "华南", "GMV": 70202.0}
{"大区": "华北", "GMV": 41099.5}
{"大区": "西南", "GMV": 31528.0}
{"大区": "华中", "GMV": 28957.0}
```

（原始 SSE 逐帧记录见 `/tmp/ux-human-video/raw/q01.sse` 与 `q01.timed.jsonl`：
帧到达时刻 0.000 / 5.182 / 6.437 / 7.098 / 9.357 / 11.915 / 14.319 / 14.327 秒。）

### 4.4 nginx SSE 逐帧到达

经 `http://127.0.0.1:5173/api/query`（nginx → api）逐帧计时，帧到达间隔为
**+0.01s / +5.5s / +8.4s / +25s**——明显是**流式增量**，不是一次性缓冲。
对应配置是 `shopkeeper-agent-frontend/nginx.conf` 里的 `proxy_buffering off; proxy_cache off;`。

### 4.5 浏览器实测

playwright-core + Chrome 走 `http://127.0.0.1:5173`：结果表格 **5 行**，
**0 console error、0 pageerror、0 失败请求**（脚本 `/tmp/docker-verify/check.mjs`）。

### 4.6 数据真实性交叉验证

同一批 GMV 数字用**纯 MySQL 手写 SQL**（不经 LLM、不经智能体）复算，结果与上面完全一致，
说明 `107373.0 / 70202.0 / 41099.5 / 31528.0 / 28957.0` 是数仓里的真实聚合值，不是编出来的。

---

## 5. 发现但**没有修**的问题

以下 8 条是排查过程中暴露的**产品 / 代码层**问题，**不在本次容器化范围内**。
本次应用源码一行未改，因此**只记录不修**，留给应用侧单独排期。

### 5.1 静默失败（后端把失败包成数据行，前端一律按成功渲染）

后端把失败编码进 `result.data` 的**内容**里，而不是发 `type:"error"` 事件；
前端 `src/App.tsx:113-120` 对 `type:"result"` **无条件**按成功渲染
（`status:"done"` + `content: summarizeResult(event.data)`），
而红色错误框分支在 `src/App.tsx:122-128`——**只有 `event.type === "error"` 才触发**，永远走不到。
`src/lib/format.ts:16-19` 的 `summarizeResult()` 只会说"完成"，
`src/components/ResultTable.tsx:23-25` 的 `formatCell(null)` 只把 null 渲染成一个短横线 `-`。

实测命中三类静默失败（详见 `/home/zhensirong/VM-Share/ux-examples-catalog.md`）：

| 类别 | SSE 原文 | UI 实际长什么样 |
|---|---|---|
| 空数组 | `{"type": "result", "data": []}` | `ResultTable` 因 `columns.length === 0` 直接 `return null`（`src/components/ResultTable.tsx:38-40`），屏幕上只剩「查询完成，结果为空。」 |
| 整列 null | `{"type": "result", "data": [{"customer_id": "C001", "支付方式": null, "支付方式占比": null}, ...]}` | 20 行标准表格，两列全是 `-`，文案「查询完成，共 20 行结果。」 |
| `error_message` 行 | `{"type": "result", "data": [{"error_message": "无法生成SQL：未提供可用数据表信息，且查询内容不明确"}]}` | 1 行 1 列的"查询结果"表，表头就叫 `error_message`，**画面上没有任何红色** |

三者共同点：后端**一次都没发过** `type=error`；`src/components/StepRail.tsx:63-65` 的 `statusFor()` 取不到就是
`pending`，所以 11 个节点全绿勾；`src/App.tsx:62-65` 的 `completedCount` 还把它们计入"完成"计数。
错误提示框本体在 `src/components/MessageBubble.tsx:51-55`（`message.error` 只在 error 事件时赋值）。

### 5.2 「校验SQL」永远绿勾

`code/shopkeeper-agent/app/agent/nodes/validate_sql.py:33 与 39`：成功分支（L33）与
**失败分支（L39）**都写 `writer({"type": "progress", "step": step, "status": "success"})`，
错误塞进 `state["error"]` 再由 `app/agent/graph.py:83-88` 的条件边
（`path=lambda state: "run_sql" if state["error"] is None else "correct_sql"`）转到「校正SQL」。
用户完全看不出中间发生过一次自我修正。

### 5.3 LLM 非确定性

`app/agent/llm.py` 里 `temperature=0`，但同一问题多次请求会落到不同分支。实测统计：

| 问法 | 复现次数 | 结果 |
|---|---|---|
| `asdf qwer zxcv 12345` | 12/12 | 都是 1 行错误表（语义 100% 稳定），但**列名和文案每次都不同**（`error_message` / `错误信息` / `message` / `查询状态` / `user_query`…） |
| `统计每个用户的支付方式占比` | 4/5 | 命中错误行；1/5 直接返回了真实数据 |
| `payment method share for each customer`（英文等价问法） | 4/6 | 4 次 `error_message` 行，1 次 20 行全 NULL，1 次空集 `[]` |
| `GMV by region in Q1 2024` | 3/4 | 3 次空集 `[]`，1 次 `{"GMV": null}` |

结论：**任何录制 / 自动化脚本都必须带"重问直到命中目标分支"的逻辑**（本次录制的 `askUntil` 就是为此）。

### 5.4 Decimal 被序列化成字符串

`code/shopkeeper-agent/app/services/query_service.py:66` 用
`json.dumps(chunk, ensure_ascii=False, default=str)` 序列化 SSE 载荷，`default=str` 把 `Decimal` 兜成了字符串。
后果是**同一行里类型不一致**：`销量` 是 `"10"`（字符串），`销售额` 是 `62190.0`（float）。
UI 上看不出差别（`formatCell` 一律 `String(value)`），但复制到剪贴板后下游拿到的是 `"10"` 而不是 `10`，做二次计算会踩坑。

### 5.5 别名语言随 LLM 心情

同一语义问出过 `大区`（中文题）、`地区`（英文题）、`region_name`（英文题 #5）、`product_name` / `sales`（英文题 #9）。
别名语言与**提问语言没有稳定关系**，下游按列名取值会随时失效。

### 5.6 ORDER BY 会丢

中文题「…并按 GMV 从高到低排序」生成了带 `ORDER BY ... DESC` 的 SQL；
英文同义问法 `GMV by region in Q1 2025` **没带排序**，行序变成
`华南 70202.0` 排在 `华东 107373.0` 前面——**数值一致但行序不稳定**，
UI 又没有"未指定排序"的提示，表格看起来像是有序的。

### 5.7 语义错位

「统计每个城市 2025 年 3 月的订单量」生成的 SQL 是 `SELECT r.province AS 城市 ...`——
**把省份叫成了城市**，值也是浙江省 / 湖北省 / 上海市这类省级行政区。
别名由 LLM 按用户问法起（`prompts/generate_sql.prompt:23` 第 6 条：别名优先用用户问题里的业务名称），
但底层查的是省份列，UI 不会提示这种错位。

### 5.8 空输入的失败在 UI 里无法触发

`src/App.tsx:60` 是 `const canSubmit = draft.trim().length > 0 && !isStreaming;`，
输入框为空时发送键被 `disabled`，所以这条错误**在 UI 里点不出来**。
后端直连 API 时才会出现（用 curl 复现过，见 `/tmp/ux-verify/probe-emptyq.txt`）：

```
data: {"type": "error", "message": "Bad request:\nInput validation error: `inputs` cannot be empty"}
```

> **为什么这些没动**：本次任务边界是"把后端容器化跑通"，判定标准是**真实问数链路返回正确数据**。
> 上面 8 条全部需要改动 `app/**` 或 `src/**` 的业务逻辑，属于另一个变更的风险面——
> 在容器化交付里夹带业务逻辑修改，会让"容器问题"和"业务问题"的回归无法区分。
> 因此统一记录在此处，附上源码行号与实测复现数据，供应用侧排期。

---

## 6. 从零重跑：把上面的坑固化成脚本与健康检查

前 5 节解决的是"这一次是怎么跑通的"。要让**下一个人**、**换一台机器**也能一条命令跑通，
还需要把"顺序"和"自检"固化下来。这一节是为此新增的两项资产。

### 6.1 启动顺序交给 healthcheck（compose 改动）

原来的 compose 里 `embedding` / `api` 都是 `service_started`（容器起来了就算就绪），
于是天然有两个竞态：

| 竞态 | 现象 | 现在 |
|---|---|---|
| TEI 要加载 1.3GB 权重（实测 ~90s） | `meta-build` 抢在模型就绪前发 embedding 调用 → 建索引失败 | `embedding` 加 healthcheck（`curl -fs http://localhost:80/health`，`start_period: 60s`），`meta-build` 改等 `service_healthy` |
| api 首次启动要同步依赖 | `web` 的 nginx 解析不到 upstream `api` → 反复重启 | `api` 加 healthcheck（镜像无 curl，用 `python3` 探 `/docs`），`web` 改等 `service_healthy` |

```yaml
# docker-compose.yaml
  embedding:
    healthcheck:
      test: ["CMD-SHELL", "curl -fs http://localhost:80/health || exit 1"]
      interval: 15s; timeout: 10s; retries: 40; start_period: 60s
  api:
    healthcheck:
      test: ["CMD-SHELL", "python3 -c \"import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://localhost:8000/docs', timeout=5).status==200 else 1)\""]
      interval: 15s; timeout: 10s; retries: 20; start_period: 40s
  meta-build:
    depends_on: { ..., embedding: { condition: service_healthy } }
  web:
    depends_on: { api: { condition: service_healthy } }
```

### 6.2 `docker/bootstrap.sh`：一条命令 + 自检

```bash
cd docker
./bootstrap.sh            # 确保在跑 + 补元数据 + 全量自检（幂等）
./bootstrap.sh --fresh    # 删卷从零重建
./bootstrap.sh --verify   # 只自检
```

五步：**preflight → up → 等 healthcheck → 幂等地决定要不要 meta-build → 自检**。

- **preflight** 查 8 项：docker 权限、`.env` 的 `LLM_API_KEY`、**1.3GB embedding 权重**、
  磁盘 ≥10GB、内存 ≥5GB、**宿主 DNS 可达性**（逐个 UDP/53 探 `daemon.json` 里的 resolver）、
  registry-mirrors、compose 语法。任何一项不过都给出**可执行的修复命令**，而不是一句报错。
- **自检** 不是"端口通就算好"：查容器状态与**重启次数**、元数据行数、Qdrant collection 数、
  ES 索引文档数、前端 200，并**发起一次真实问数**（走 nginx、真 LLM），
  确认是**流式**（SSE 帧数 ≥10）且结果与基线一致，最后**用纯 SQL 复算对账**——证明不是假数据。
- **幂等门**：`meta-build` 非幂等，脚本先读元数据行数，够就跳过、不够才跑。
- **权限降级链**（不写死任何密码）：root → docker 组 → `SUDO_PASSWORD` 环境变量 → 已缓存的 sudo → 明确报错并给三种修法。

### 6.3 实测：从零到能用

```
$ ./bootstrap.sh --fresh
[1] 前置检查      8 项全过（权重 1.3G、磁盘 68GB、DNS 可达 resolver: 61.145.231.34 222.200.8.2 …）
[2] 拉起容器      down -v + up -d --build
[3] 等待就绪      全部服务 healthy
[4] 元数据        检测到缺失 → 执行 meta-build → 表 5 / 字段 24 / 指标 2
[5] 自检          7 容器 healthy 且重启 0 次；表 5 / 字段 24 / 指标 2 / 订单 115；
                  Qdrant collection ×2；ES value_index 75 docs；前端 5173 = 200；
                  SSE 帧数 23；问数结果与基线一致（22s）
全部通过 ✔
```

**从删卷重建到全量自检通过：221 秒 ≈ 3.7 分钟**（镜像已缓存；首次还要加构建/拉取时间）。
其中约 90s 在等 TEI 加载权重、约 30s 在跑 meta-build、22s 在等真实 LLM。

### 6.4 仍然无法自动化的部分（如实说明）

1. **LLM 非确定性**：同一问法每次生成的 SQL 都可能不同（见 5.3），因此自检是**金额集合级**比对，
   不是逐字比对 SQL；冷启动后第一次问数的 SQL 文本会与基线不同，但结果应当一致。
2. **网络策略变更**：办公网 DNS 换了、Docker Hub 策略变了，只能靠 preflight 提前暴露。
3. **资源不足**：内存 <5GB 时 ES/TEI 会被 OOM，脚本会提示"紧张时先 `stop kibana`"。

---

## 7. 附录：命令清单

**A. 构建期：DNS / 网络探针**

```sh
cat /etc/docker/daemon.json                      # daemon 下发的 dns / registry-mirrors
cat /etc/resolv.conf                             # 宿主解析器配置（对照用）
docker run --rm alpine sh -c 'cat /etc/resolv.conf; nslookup pypi.org'
getent hosts pypi.org                            # 宿主侧对照
docker run --rm node:22-alpine sh -c 'npm config get registry; npm view react version'
docker run --rm --entrypoint sh python:3.14-slim -c \
  'getent hosts files.pythonhosted.org; wget -S --spider https://files.pythonhosted.org/ 2>&1 | head'
```

**B. 路由与网络别名**

```sh
ip -4 addr show | grep -E 'inet '                 # 宿主网段
ip route | grep 172.18                           # 是否与 Docker 网段重叠
docker network inspect bridge --format '{{(index .IPAM.Config 0).Subnet}}'
docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' shopkeeper-api
ip route get <容器IP>                             # 这条流量走哪块网卡
docker compose exec web getent hosts api          # 服务名别名
docker compose exec web getent hosts shopkeeper-api
docker compose exec web cat /etc/nginx/conf.d/default.conf
```

**C. compose 编排校验**

```sh
docker compose config -q                # YAML / schema 校验
docker compose config --services        # 默认 profile 会启动哪些服务
docker compose ps -a                    # 状态 + 退出码 + 重启计数
docker compose ps                       # 只看运行中的
```

**D. 日志取证**

```sh
docker compose logs --tail 50 api
docker compose logs --tail 50 meta-build
docker compose logs --tail 20 web
docker logs --since 2026-10-20T13:50:00 --until 2026-10-20T14:25:00 shopkeeper-api
```

**E. 真实问数复验（SSE）**

```sh
curl -N -X POST http://127.0.0.1:8000/api/query \
  -H 'Content-Type: application/json' \
  -d '{"query":"统计2025年第一季度各大区的GMV，并按GMV从高到低排序"}'
python3 /tmp/sse_timing.py             # 逐帧计时，分别打 8000（直连）与 5173（经 nginx）
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8000/docs
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:5173/
```

**F. 浏览器复验**

```sh
NODE_PATH=/tmp/ux-human-video/work/node_modules node /tmp/docker-verify/check.mjs
# playwright-core + /usr/bin/google-chrome，走 5173：点样例卡片 → 等结果 → 数行数
# → 统计 console error / pageerror / requestfailed
```

**G. 元数据 / 索引验证**

```sh
docker compose exec mysql mysql -udidilili -pdili123 -e \
  "SELECT (SELECT COUNT(*) FROM meta.table_info) tables, (SELECT COUNT(*) FROM meta.column_info) cols, (SELECT COUNT(*) FROM meta.metric_info) metrics, (SELECT COUNT(*) FROM dw.fact_order) orders"
curl -s http://127.0.0.1:6333/collections          # Qdrant collection 列表
curl -s http://127.0.0.1:9200/value_index/_count   # ES 文档数
```

**H. 日常启动 / 一次性任务**

```sh
cd docker
docker compose up -d                                  # 不含 meta-build（profiles: ["tools"]）
docker compose run --rm meta-build                    # 需要时手动重建索引
docker compose exec mysql mysql -udidilili -pdili123 -e \
  "TRUNCATE meta.table_info, meta.column_info, meta.metric_info, meta.column_metric"
```

---

*本报告由 Orca 任务 `task_aa415630984f`（dispatch `ctx_2648735a2a7e`）于 2026-10-20 整理。
报告撰写过程中仓库目录全程只读，未改动任何源码、配置或 compose 文件。*
